--
-- PostgreSQL database dump
--

\restrict DKVYTabtnyQVUYsAARfV0cRInehgqxKwClILbPStts271smPQzLnuhyI9JtAkZj

-- Dumped from database version 16.15 (Ubuntu 16.15-0ubuntu0.24.04.1)
-- Dumped by pg_dump version 16.15 (Ubuntu 16.15-0ubuntu0.24.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: estado_tipo; Type: TYPE; Schema: public; Owner: carroya_user
--

CREATE TYPE public.estado_tipo AS ENUM (
    'sin intentar',
    'descargado',
    'fallido',
    'no_encontrado'
);


ALTER TYPE public.estado_tipo OWNER TO carroya_user;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: anuncio; Type: TABLE; Schema: public; Owner: carroya_user
--

CREATE TABLE public.anuncio (
    id integer NOT NULL,
    url text NOT NULL,
    marca character varying(50),
    linea character varying(50),
    "año" smallint,
    ciudad character varying(100),
    vendedor_id integer,
    primera_vista date NOT NULL,
    ultima_vista date NOT NULL,
    CONSTRAINT chk_vistas CHECK ((ultima_vista >= primera_vista))
);


ALTER TABLE public.anuncio OWNER TO carroya_user;

--
-- Name: anuncio_id_seq; Type: SEQUENCE; Schema: public; Owner: carroya_user
--

CREATE SEQUENCE public.anuncio_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.anuncio_id_seq OWNER TO carroya_user;

--
-- Name: anuncio_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: carroya_user
--

ALTER SEQUENCE public.anuncio_id_seq OWNED BY public.anuncio.id;


--
-- Name: cambio; Type: TABLE; Schema: public; Owner: carroya_user
--

CREATE TABLE public.cambio (
    id integer NOT NULL,
    anuncio_id integer NOT NULL,
    fecha date NOT NULL,
    campo character varying(50) NOT NULL,
    valor_anterior text,
    valor_nuevo text
);


ALTER TABLE public.cambio OWNER TO carroya_user;

--
-- Name: cambio_id_seq; Type: SEQUENCE; Schema: public; Owner: carroya_user
--

CREATE SEQUENCE public.cambio_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.cambio_id_seq OWNER TO carroya_user;

--
-- Name: cambio_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: carroya_user
--

ALTER SEQUENCE public.cambio_id_seq OWNED BY public.cambio.id;


--
-- Name: log_ejecucion; Type: TABLE; Schema: public; Owner: carroya_user
--

CREATE TABLE public.log_ejecucion (
    id integer NOT NULL,
    run_id character varying(50) NOT NULL,
    etapa character varying(50) NOT NULL,
    fecha_inicio timestamp with time zone NOT NULL,
    fecha_fin timestamp with time zone,
    duracion_seg numeric(10,2),
    estado character varying(20) DEFAULT 'iniciado'::character varying NOT NULL,
    enlaces_encontrados integer,
    descargas_ok integer,
    descargas_fallidas integer,
    descargas_pendientes integer,
    anuncios_nuevos integer,
    registros_actualizados integer,
    registros_sin_cambio integer,
    no_encontrados integer,
    anuncios_unicos_total integer,
    tamanio_bd_mb numeric(10,2),
    correo_estado character varying(50),
    mensaje text,
    detalle_error text
);


ALTER TABLE public.log_ejecucion OWNER TO carroya_user;

--
-- Name: log_ejecucion_id_seq; Type: SEQUENCE; Schema: public; Owner: carroya_user
--

CREATE SEQUENCE public.log_ejecucion_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.log_ejecucion_id_seq OWNER TO carroya_user;

--
-- Name: log_ejecucion_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: carroya_user
--

ALTER SEQUENCE public.log_ejecucion_id_seq OWNED BY public.log_ejecucion.id;


--
-- Name: observacion; Type: TABLE; Schema: public; Owner: carroya_user
--

CREATE TABLE public.observacion (
    id integer NOT NULL,
    anuncio_id integer NOT NULL,
    fecha date NOT NULL,
    hora time without time zone,
    estado public.estado_tipo NOT NULL,
    version character varying(200),
    precio bigint,
    moneda character(3),
    kilometraje integer,
    transmision character varying(100),
    color character varying(50),
    sunroof boolean,
    error character varying(500),
    combustible character varying(50),
    comentarios text
);


ALTER TABLE public.observacion OWNER TO carroya_user;

--
-- Name: observacion_id_seq; Type: SEQUENCE; Schema: public; Owner: carroya_user
--

CREATE SEQUENCE public.observacion_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.observacion_id_seq OWNER TO carroya_user;

--
-- Name: observacion_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: carroya_user
--

ALTER SEQUENCE public.observacion_id_seq OWNED BY public.observacion.id;


--
-- Name: vendedor; Type: TABLE; Schema: public; Owner: carroya_user
--

CREATE TABLE public.vendedor (
    id integer NOT NULL,
    nombre character varying(200) NOT NULL,
    departamento character varying(100)
);


ALTER TABLE public.vendedor OWNER TO carroya_user;

--
-- Name: vendedor_id_seq; Type: SEQUENCE; Schema: public; Owner: carroya_user
--

CREATE SEQUENCE public.vendedor_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.vendedor_id_seq OWNER TO carroya_user;

--
-- Name: vendedor_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: carroya_user
--

ALTER SEQUENCE public.vendedor_id_seq OWNED BY public.vendedor.id;


--
-- Name: anuncio id; Type: DEFAULT; Schema: public; Owner: carroya_user
--

ALTER TABLE ONLY public.anuncio ALTER COLUMN id SET DEFAULT nextval('public.anuncio_id_seq'::regclass);


--
-- Name: cambio id; Type: DEFAULT; Schema: public; Owner: carroya_user
--

ALTER TABLE ONLY public.cambio ALTER COLUMN id SET DEFAULT nextval('public.cambio_id_seq'::regclass);


--
-- Name: log_ejecucion id; Type: DEFAULT; Schema: public; Owner: carroya_user
--

ALTER TABLE ONLY public.log_ejecucion ALTER COLUMN id SET DEFAULT nextval('public.log_ejecucion_id_seq'::regclass);


--
-- Name: observacion id; Type: DEFAULT; Schema: public; Owner: carroya_user
--

ALTER TABLE ONLY public.observacion ALTER COLUMN id SET DEFAULT nextval('public.observacion_id_seq'::regclass);


--
-- Name: vendedor id; Type: DEFAULT; Schema: public; Owner: carroya_user
--

ALTER TABLE ONLY public.vendedor ALTER COLUMN id SET DEFAULT nextval('public.vendedor_id_seq'::regclass);


--
-- Data for Name: anuncio; Type: TABLE DATA; Schema: public; Owner: carroya_user
--

COPY public.anuncio (id, url, marca, linea, "año", ciudad, vendedor_id, primera_vista, ultima_vista) FROM stdin;
3	https://www.carroya.com/detalle/usado/toyota/corolla/2022/bogota/3a9bd4a3-73eb-4e3f-9aad-0870cf9cbf4c	Toyota	Corolla	2022	Bogota	3	2026-11-11	2026-11-15
12	https://www.carroya.com/detalle/usado/toyota/corolla/2022/medellin/0dd6cbba-d0f6-4b18-bf83-e499a52c62d7	Toyota	Corolla	2022	Medellin	12	2026-11-11	2026-11-15
13	https://www.carroya.com/detalle/usado/toyota/corolla/2022/medellin/52ed48be-c55b-4ec4-92e0-355650da22cb	Toyota	Corolla	2022	Medellin	12	2026-11-11	2026-11-15
17	https://www.carroya.com/detalle/usado/toyota/corolla/2023/bello/1e6fb3a5-7462-484d-a70a-976ae9722eb9	Toyota	Corolla	2023	Bello	17	2026-11-11	2026-11-15
27	https://www.carroya.com/detalle/usado/toyota/corolla/2023/bogota/c6245bd1-3989-4d88-ad94-83889ac79168	Toyota	Corolla	2023	Bogota	27	2026-11-11	2026-11-15
30	https://www.carroya.com/detalle/usado/toyota/corolla/2023/cucuta/0130d3ab-61e1-4734-adcf-88ca8306b8e7	Toyota	Corolla	2023	Cucuta	30	2026-11-11	2026-11-15
31	https://www.carroya.com/detalle/usado/toyota/corolla/2023/cucuta/1b75da25-57a0-4e58-87ca-bc2d86bb76eb	Toyota	Corolla	2023	Cucuta	31	2026-11-11	2026-11-15
32	https://www.carroya.com/detalle/usado/toyota/corolla/2023/ibague/453991fd-06d3-4579-bedc-8d7c66036242	Toyota	Corolla	2023	Ibague	32	2026-11-11	2026-11-15
33	https://www.carroya.com/detalle/usado/toyota/corolla/2023/medellin/0141e624-be5a-4634-a6a7-c98066fe48b0	Toyota	Corolla	2023	Medellin	12	2026-11-11	2026-11-15
34	https://www.carroya.com/detalle/usado/toyota/corolla/2023/medellin/4def931a-817d-4261-8c3a-2af7936d1c18	Toyota	Corolla	2023	Medellin	34	2026-11-11	2026-11-15
35	https://www.carroya.com/detalle/usado/toyota/corolla/2023/medellin/53f370b3-0d3a-4ce2-ae04-6438daa7e25b	Toyota	Corolla	2023	Medellin	35	2026-11-11	2026-11-15
36	https://www.carroya.com/detalle/usado/toyota/corolla/2023/medellin/5b670144-eb1b-4da4-89af-502fcfabc230	Toyota	Corolla	2023	Medellin	36	2026-11-11	2026-11-15
37	https://www.carroya.com/detalle/usado/toyota/corolla/2023/medellin/ac2a946d-48cc-4cd7-9414-ef914a66c590	Toyota	Corolla	2023	Medellin	37	2026-11-11	2026-11-15
38	https://www.carroya.com/detalle/usado/toyota/corolla/2023/medellin/ae957bf0-5948-4eaf-8d6e-1cc430d803ce	Toyota	Corolla	2023	Medellin	38	2026-11-11	2026-11-15
39	https://www.carroya.com/detalle/usado/toyota/corolla/2023/medellin/cad4c5ed-a78f-4830-88f5-932d07300dfb	Toyota	Corolla	2023	Medellin	39	2026-11-11	2026-11-15
40	https://www.carroya.com/detalle/usado/toyota/corolla/2023/medellin/f4f8fae0-5d3f-4a6a-9fdb-7935115337cf	Toyota	Corolla	2023	Medellin	12	2026-11-11	2026-11-15
41	https://www.carroya.com/detalle/usado/toyota/corolla/2023/pasto/58c02917-93f3-4ea8-86c4-e69beb1df4e4	Toyota	Corolla	2023	Pasto	41	2026-11-11	2026-11-15
43	https://www.carroya.com/detalle/usado/toyota/corolla/2024/bogota/262ad6cb-7331-43df-aa0b-6ca8e3ada138	Toyota	Corolla	2024	Bogota	43	2026-11-11	2026-11-15
1	https://www.carroya.com/detalle/usado/toyota/corolla/2022/bogota/1461ca6c-e4fe-4755-ad43-3c3fd0c5767b	Toyota	Corolla	2022	Bogota	1	2026-11-11	2026-11-15
2	https://www.carroya.com/detalle/usado/toyota/corolla/2022/bogota/1da3f26f-493c-4333-a5d1-5f1c60bb0c71	Toyota	Corolla	2022	Bogota	2	2026-11-11	2026-11-15
4	https://www.carroya.com/detalle/usado/toyota/corolla/2022/bogota/5a526c41-6c90-4ca6-9c87-7559ae1f1487	Toyota	Corolla	2022	Bogota	4	2026-11-11	2026-11-15
5	https://www.carroya.com/detalle/usado/toyota/corolla/2022/bogota/5c7d6de2-b4ba-4d4d-957d-4e2c74eb20ea	Toyota	Corolla	2022	Bogota	5	2026-11-11	2026-11-15
6	https://www.carroya.com/detalle/usado/toyota/corolla/2022/bogota/86549bd8-c429-4e97-9148-3471bd6d2dd4	Toyota	Corolla	2022	Bogota	6	2026-11-11	2026-11-15
7	https://www.carroya.com/detalle/usado/toyota/corolla/2022/bogota/a221c1a0-0524-421b-9909-9cfdd33cff72	Toyota	Corolla	2022	Bogota	7	2026-11-11	2026-11-15
8	https://www.carroya.com/detalle/usado/toyota/corolla/2022/bogota/a7b14618-6fb9-4468-a7af-338a3ce4a1d8	Toyota	Corolla	2022	Bogota	8	2026-11-11	2026-11-15
9	https://www.carroya.com/detalle/usado/toyota/corolla/2022/bogota/b2390638-5012-4780-ab68-e1042a8cb21c	Toyota	Corolla	2022	Bogota	9	2026-11-11	2026-11-15
10	https://www.carroya.com/detalle/usado/toyota/corolla/2022/bogota/d0444b8b-5a5a-4dbd-b41f-0a7a9a8535d4	Toyota	Corolla	2022	Bogota	10	2026-11-11	2026-11-15
11	https://www.carroya.com/detalle/usado/toyota/corolla/2022/envigado/a2ee3a3d-ff63-46fb-95db-4d4e97ad13d1	Toyota	Corolla	2022	Envigado	11	2026-11-11	2026-11-15
14	https://www.carroya.com/detalle/usado/toyota/corolla/2022/medellin/ab582ec2-55aa-46d3-b746-761b17b061ce	Toyota	Corolla	2022	Medellin	12	2026-11-11	2026-11-15
253	https://www.carroya.com/detalle/usado/toyota/corolla/2023/bogota/b177a2ee-8b5a-429f-9cff-1895067df51c	Toyota	Corolla	2023	Bogota	253	2026-11-15	2026-11-15
42	https://www.carroya.com/detalle/usado/toyota/corolla/2023/villavicencio/8a254de4-9bd0-471a-91e0-2a000ceca247	Toyota	Corolla	2023	Villavicencio	42	2026-11-11	2026-11-15
44	https://www.carroya.com/detalle/usado/toyota/corolla/2024/bogota/687a1665-7e7a-4fff-97c9-41ddcfd0161b	Toyota	Corolla	2024	Bogota	44	2026-11-11	2026-11-15
45	https://www.carroya.com/detalle/usado/toyota/corolla/2024/bogota/eb667dfd-9f08-48c3-afc1-9545291be6d3	Toyota	Corolla	2024	Bogota	45	2026-11-11	2026-11-15
46	https://www.carroya.com/detalle/usado/toyota/corolla/2024/medellin/889d2f0f-661b-4462-aad1-4515bf7891a7	Toyota	Corolla	2024	Medellin	35	2026-11-11	2026-11-15
47	https://www.carroya.com/detalle/usado/toyota/corolla/2024/medellin/f3c47407-556b-436c-a134-a4c1f059e4e6	Toyota	Corolla	2024	Medellin	12	2026-11-11	2026-11-15
48	https://www.carroya.com/detalle/usado/toyota/corolla/2025/bogota/0634dca5-40ca-42d5-9bd7-8e3e25cf0f7e	Toyota	Corolla	2025	Bogota	48	2026-11-11	2026-11-15
49	https://www.carroya.com/detalle/usado/toyota/corolla/2025/bogota/a4c60092-f782-486f-98cb-5e7e5b22b847	Toyota	Corolla	2025	Bogota	49	2026-11-11	2026-11-15
50	https://www.carroya.com/detalle/usado/toyota/corolla/2025/medellin/05c982ce-4072-40e8-8c2f-c9a679820e78	Toyota	Corolla	2025	Medellin	12	2026-11-11	2026-11-15
51	https://www.carroya.com/detalle/usado/toyota/corolla/2025/medellin/15a5278c-d3c2-4d4a-b8f5-7a108fc05d21	Toyota	Corolla	2025	Medellin	12	2026-11-11	2026-11-15
52	https://www.carroya.com/detalle/usado/toyota/corolla/2025/medellin/78810763-bc26-46ec-b5f0-f1261a415460	Toyota	Corolla	2025	Medellin	12	2026-11-11	2026-11-15
121	https://www.carroya.com/detalle/usado/toyota/corolla/2022/medellin/d368e25e-dde2-4ea1-8566-33c66d39995f	Toyota	Corolla	2022	Medellin	12	2026-11-13	2026-11-15
15	https://www.carroya.com/detalle/usado/toyota/corolla/2022/medellin/df0e4b7c-a81b-41d2-993f-41d93c28578d	Toyota	Corolla	2022	Medellin	12	2026-11-11	2026-11-15
16	https://www.carroya.com/detalle/usado/toyota/corolla/2022/villavicencio/d1bf9d95-155f-4610-ab51-e93207c59ff7	Toyota	Corolla	2022	Villavicencio	16	2026-11-11	2026-11-15
18	https://www.carroya.com/detalle/usado/toyota/corolla/2023/bogota/02f40a46-bcc5-4be3-aa80-829171fed051	Toyota	Corolla	2023	Bogota	18	2026-11-11	2026-11-15
19	https://www.carroya.com/detalle/usado/toyota/corolla/2023/bogota/2052530	Toyota	Corolla	2023	Bogota	19	2026-11-11	2026-11-15
20	https://www.carroya.com/detalle/usado/toyota/corolla/2023/bogota/2bafe1ea-7132-471b-bbe4-442eeeed8d4f	Toyota	Corolla	2023	Bogota	20	2026-11-11	2026-11-15
21	https://www.carroya.com/detalle/usado/toyota/corolla/2023/bogota/307925c3-bf14-4821-8444-71e986578727	Toyota	Corolla	2023	Bogota	21	2026-11-11	2026-11-15
22	https://www.carroya.com/detalle/usado/toyota/corolla/2023/bogota/3b4f3f24-b0aa-485c-8d24-4185bc8632e5	Toyota	Corolla	2023	Bogota	22	2026-11-11	2026-11-15
23	https://www.carroya.com/detalle/usado/toyota/corolla/2023/bogota/481862b9-ac91-487f-8610-9d7a38bbe404	Toyota	Corolla	2023	Bogota	6	2026-11-11	2026-11-15
24	https://www.carroya.com/detalle/usado/toyota/corolla/2023/bogota/8f6a5497-902a-4fe7-ba03-6a4eec3f8eac	Toyota	Corolla	2023	Bogota	24	2026-11-11	2026-11-15
25	https://www.carroya.com/detalle/usado/toyota/corolla/2023/bogota/a4df1180-e1dd-4f68-8970-b728279b8727	Toyota	Corolla	2023	Bogota	25	2026-11-11	2026-11-15
26	https://www.carroya.com/detalle/usado/toyota/corolla/2023/bogota/b2019d5c-93c3-4b48-9c50-2fe84e67fc4e	Toyota	Corolla	2023	Bogota	26	2026-11-11	2026-11-15
28	https://www.carroya.com/detalle/usado/toyota/corolla/2023/bucaramanga/2d84cf8e-88c8-4c63-9e37-e6b08fc65a53	Toyota	Corolla	2023	Bucaramanga	28	2026-11-11	2026-11-15
29	https://www.carroya.com/detalle/usado/toyota/corolla/2023/cali/14805f43-bdb0-4eaf-a097-48c3c52552e6	Toyota	Corolla	2023	Cali	29	2026-11-11	2026-11-15
53	https://www.carroya.com/detalle/usado/toyota/corolla/2025/medellin/bf713f5c-91fb-4d07-b30b-85b805ef8621	Toyota	Corolla	2025	Medellin	12	2026-11-11	2026-11-15
54	https://www.carroya.com/detalle/usado/toyota/corolla/2025/medellin/bfbadc33-f663-4001-96a4-fbf57851f800	Toyota	Corolla	2025	Medellin	12	2026-11-11	2026-11-15
55	https://www.carroya.com/detalle/usado/toyota/corolla/2026/bogota/a3b6c8b4-299b-409c-8e69-1f5df600e9cb	Toyota	Corolla	2026	Bogota	55	2026-11-11	2026-11-15
56	https://www.carroya.com/detalle/usado/toyota/corolla/2026/bogota/c2fce922-3287-48e1-9825-fd2eaca87be9	Toyota	Corolla	2026	Bogota	56	2026-11-11	2026-11-15
57	https://www.carroya.com/detalle/usado/toyota/corolla/2026/manizales/9e1a58d5-aab2-43c3-b75f-3dedbafc1e2a	Toyota	Corolla	2026	Manizales	57	2026-11-11	2026-11-15
58	https://www.carroya.com/detalle/usado/toyota/corolla/2026/medellin/51cc66ef-19cc-476a-a536-8f0a76b9730d	Toyota	Corolla	2026	Medellin	12	2026-11-11	2026-11-15
59	https://www.carroya.com/detalle/usado/toyota/corolla/2026/medellin/549fc674-53ee-45e4-81f6-eb7de5f42b2f	Toyota	Corolla	2026	Medellin	59	2026-11-11	2026-11-15
\.


--
-- Data for Name: cambio; Type: TABLE DATA; Schema: public; Owner: carroya_user
--

COPY public.cambio (id, anuncio_id, fecha, campo, valor_anterior, valor_nuevo) FROM stdin;
1	1	2026-11-12	precio	precio	84900000
2	1	2026-11-12	kilometraje	kilometraje	54984
3	1	2026-11-12	version	version	1.8 XE-i Automatico
4	2	2026-11-12	precio	precio	85000000
5	2	2026-11-12	kilometraje	kilometraje	35000
6	2	2026-11-12	version	version	1.3 Mecanico
7	4	2026-11-12	precio	precio	98500000
8	4	2026-11-12	kilometraje	kilometraje	40000
9	4	2026-11-12	version	version	1.8 XE-i Automatico
10	5	2026-11-12	precio	precio	115000000
11	5	2026-11-12	kilometraje	kilometraje	20000
12	5	2026-11-12	version	version	\N
13	6	2026-11-12	precio	precio	84990000
14	6	2026-11-12	kilometraje	kilometraje	84392
15	6	2026-11-12	version	version	1.8 XE-i Hybrid Automatico
16	7	2026-11-12	precio	precio	95000000
17	7	2026-11-12	kilometraje	kilometraje	31800
18	7	2026-11-12	version	version	1.8 XE-i Automatico
19	8	2026-11-12	precio	precio	95000000
20	8	2026-11-12	kilometraje	kilometraje	29000
21	8	2026-11-12	version	version	1.8 CVT XEI
22	9	2026-11-12	precio	precio	89000000
23	9	2026-11-12	kilometraje	kilometraje	82000
24	9	2026-11-12	version	version	1.8 XE-i Automatico
25	10	2026-11-12	precio	precio	83990000
26	10	2026-11-12	kilometraje	kilometraje	27952
27	10	2026-11-12	version	version	XEI 2.0 Sedan Manual
28	11	2026-11-12	precio	precio	87000000
29	11	2026-11-12	kilometraje	kilometraje	44000
30	11	2026-11-12	version	version	1.8 XE-i Automatico
31	14	2026-11-12	precio	precio	89900000
32	14	2026-11-12	kilometraje	kilometraje	52050
33	14	2026-11-12	version	version	1.8 XEi-L Automatico
34	15	2026-11-12	precio	precio	107900000
35	15	2026-11-12	kilometraje	kilometraje	72300
36	15	2026-11-12	version	version	1.8 CVT XEI
37	16	2026-11-12	precio	precio	111700000
38	16	2026-11-12	kilometraje	kilometraje	85000
39	16	2026-11-12	version	version	1.8 CVT SEG
40	18	2026-11-12	precio	precio	110000000
41	18	2026-11-12	kilometraje	kilometraje	23000
42	18	2026-11-12	version	version	SE-G Automatico
43	19	2026-11-12	precio	precio	101000000
44	19	2026-11-12	kilometraje	kilometraje	1000
45	19	2026-11-12	version	version	1.8 XL-i Automatico
46	20	2026-11-12	precio	precio	100000000
47	20	2026-11-12	kilometraje	kilometraje	43000
48	20	2026-11-12	version	version	SE-G Automatico
49	21	2026-11-12	precio	precio	114000000
50	21	2026-11-12	kilometraje	kilometraje	36000
51	21	2026-11-12	version	version	1.8 Aut
52	22	2026-11-12	precio	precio	89900000
53	22	2026-11-12	kilometraje	kilometraje	22550
54	22	2026-11-12	version	version	1.8 XL-i Automatico
55	23	2026-11-12	precio	precio	99990000
56	23	2026-11-12	kilometraje	kilometraje	45800
57	23	2026-11-12	version	version	SE-G Automatico
58	24	2026-11-12	precio	precio	108000000
59	24	2026-11-12	kilometraje	kilometraje	34083
60	24	2026-11-12	version	version	1.8 XL-i Automatico
61	25	2026-11-12	precio	precio	145000000
62	25	2026-11-12	kilometraje	kilometraje	30000
63	25	2026-11-12	version	version	SE-G Automatico
64	26	2026-11-12	precio	precio	99900000
65	26	2026-11-12	kilometraje	kilometraje	42000
66	26	2026-11-12	version	version	1.8 XEi-L Automatico
67	28	2026-11-12	precio	precio	115000000
68	28	2026-11-12	kilometraje	kilometraje	20000
69	28	2026-11-12	version	version	1.8 CVT SEG
70	29	2026-11-12	precio	precio	118990000
71	29	2026-11-12	kilometraje	kilometraje	30000
72	29	2026-11-12	version	version	SE-G Automatico
73	30	2026-11-12	precio	precio	95900000
74	30	2026-11-12	kilometraje	kilometraje	37000
75	30	2026-11-12	version	version	GR-S 2.0 Deportivo Manual Gasolina
76	31	2026-11-12	precio	precio	90000000
77	31	2026-11-12	kilometraje	kilometraje	36000
78	31	2026-11-12	version	version	GR-S 2.0 Deportivo Manual Gasolina
79	32	2026-11-12	precio	precio	104900000
80	32	2026-11-12	kilometraje	kilometraje	39000
81	32	2026-11-12	version	version	SE-G Automatico
82	34	2026-11-12	precio	precio	112900000
83	34	2026-11-12	kilometraje	kilometraje	34000
84	34	2026-11-12	version	version	SE-G Automatico
85	36	2026-11-12	precio	precio	97000000
86	36	2026-11-12	kilometraje	kilometraje	59000
87	36	2026-11-12	version	version	XEI 2.0 Sedan Automatico CVT
88	38	2026-11-12	precio	precio	85000000
89	38	2026-11-12	kilometraje	kilometraje	56879
90	38	2026-11-12	version	version	1.8 XE-i Automatico
91	39	2026-11-12	precio	precio	102000000
92	39	2026-11-12	kilometraje	kilometraje	53400
93	39	2026-11-12	version	version	1.8 XE-i Automatico
94	41	2026-11-12	precio	precio	115000000
95	41	2026-11-12	kilometraje	kilometraje	25700
96	41	2026-11-12	version	version	1.8
97	42	2026-11-12	precio	precio	108000000
98	42	2026-11-12	kilometraje	kilometraje	63000
99	42	2026-11-12	version	version	1.8 CVT SEG
100	43	2026-11-12	precio	precio	113000000
101	43	2026-11-12	kilometraje	kilometraje	32000
102	43	2026-11-12	version	version	1.8 XE-i Automatico
103	44	2026-11-12	precio	precio	123000000
104	44	2026-11-12	kilometraje	kilometraje	5000
105	44	2026-11-12	version	version	1.8 XE-i Automatico
106	45	2026-11-12	precio	precio	115000000
107	45	2026-11-12	kilometraje	kilometraje	29000
108	45	2026-11-12	version	version	1.8 CVT XEI
109	48	2026-11-12	precio	precio	145500000
110	48	2026-11-12	kilometraje	kilometraje	10000
111	48	2026-11-12	version	version	\N
112	49	2026-11-12	precio	precio	118000000
113	49	2026-11-12	kilometraje	kilometraje	4151
114	49	2026-11-12	version	version	1.8 XE-i Automatico
115	50	2026-11-12	precio	precio	116900000
116	50	2026-11-12	kilometraje	kilometraje	14000
117	50	2026-11-12	version	version	1.8 CVT SEG
118	51	2026-11-12	precio	precio	144000000
119	51	2026-11-12	kilometraje	kilometraje	15109
120	51	2026-11-12	version	version	1.8 XEi-L Automatico
121	52	2026-11-12	precio	precio	132900000
122	52	2026-11-12	kilometraje	kilometraje	29149
123	52	2026-11-12	version	version	SE-G Automatico
124	54	2026-11-12	precio	precio	141900000
125	54	2026-11-12	kilometraje	kilometraje	25543
126	54	2026-11-12	version	version	1.8 CVT SEG
127	55	2026-11-12	precio	precio	152000000
128	55	2026-11-12	kilometraje	kilometraje	10200
129	55	2026-11-12	version	version	1.8 CVT SEG
130	56	2026-11-12	precio	precio	129900000
131	56	2026-11-12	kilometraje	kilometraje	9000
132	56	2026-11-12	version	version	1.8 CVT SEG
133	57	2026-11-12	precio	precio	122000000
134	57	2026-11-12	kilometraje	kilometraje	26000
135	57	2026-11-12	version	version	1.8 CVT SEG
136	58	2026-11-12	precio	precio	105900000
137	58	2026-11-12	kilometraje	kilometraje	20000
138	58	2026-11-12	version	version	1.8 XL-i Automatico
139	59	2026-11-12	precio	precio	134000000
140	59	2026-11-12	kilometraje	kilometraje	1600
141	59	2026-11-12	version	version	1.8
142	1	2026-11-13	precio	precio	84900000
143	1	2026-11-13	kilometraje	kilometraje	54984
144	1	2026-11-13	version	version	1.8 XE-i Automatico
145	2	2026-11-13	precio	precio	85000000
146	2	2026-11-13	kilometraje	kilometraje	35000
147	2	2026-11-13	version	version	1.3 Mecanico
148	3	2026-11-13	precio	precio	94000000
149	3	2026-11-13	kilometraje	kilometraje	63000
150	3	2026-11-13	version	version	1.8 CVT SEG
151	4	2026-11-13	precio	precio	98500000
152	4	2026-11-13	kilometraje	kilometraje	40000
153	4	2026-11-13	version	version	1.8 XE-i Automatico
154	5	2026-11-13	precio	precio	115000000
155	5	2026-11-13	kilometraje	kilometraje	20000
156	5	2026-11-13	version	version	\N
157	6	2026-11-13	precio	precio	84990000
158	6	2026-11-13	kilometraje	kilometraje	84392
159	6	2026-11-13	version	version	1.8 XE-i Hybrid Automatico
160	7	2026-11-13	precio	precio	95000000
161	7	2026-11-13	kilometraje	kilometraje	31800
162	7	2026-11-13	version	version	1.8 XE-i Automatico
163	8	2026-11-13	precio	precio	95000000
164	8	2026-11-13	kilometraje	kilometraje	29000
165	8	2026-11-13	version	version	1.8 CVT XEI
166	9	2026-11-13	precio	precio	89000000
167	9	2026-11-13	kilometraje	kilometraje	82000
168	9	2026-11-13	version	version	1.8 XE-i Automatico
169	10	2026-11-13	precio	precio	83990000
170	10	2026-11-13	kilometraje	kilometraje	27952
171	10	2026-11-13	version	version	XEI 2.0 Sedan Manual
172	11	2026-11-13	precio	precio	87000000
173	11	2026-11-13	kilometraje	kilometraje	44000
174	11	2026-11-13	version	version	1.8 XE-i Automatico
175	12	2026-11-13	precio	precio	119900000
176	12	2026-11-13	kilometraje	kilometraje	55000
177	12	2026-11-13	version	version	1.8
178	13	2026-11-13	precio	precio	91900000
179	13	2026-11-13	kilometraje	kilometraje	68000
180	13	2026-11-13	version	version	1.8 CVT SEG
181	14	2026-11-13	precio	precio	89900000
182	14	2026-11-13	kilometraje	kilometraje	52050
183	14	2026-11-13	version	version	1.8 XEi-L Automatico
184	15	2026-11-13	precio	precio	107900000
185	15	2026-11-13	kilometraje	kilometraje	72300
186	15	2026-11-13	version	version	1.8 CVT XEI
187	16	2026-11-13	precio	precio	111700000
188	16	2026-11-13	kilometraje	kilometraje	85000
189	16	2026-11-13	version	version	1.8 CVT SEG
190	17	2026-11-13	precio	precio	99900000
191	17	2026-11-13	kilometraje	kilometraje	46000
192	17	2026-11-13	version	version	1.8 XL-i Automatico
193	18	2026-11-13	precio	precio	110000000
194	18	2026-11-13	kilometraje	kilometraje	23000
195	18	2026-11-13	version	version	SE-G Automatico
196	19	2026-11-13	precio	precio	101000000
197	19	2026-11-13	kilometraje	kilometraje	1000
198	19	2026-11-13	version	version	1.8 XL-i Automatico
199	20	2026-11-13	precio	precio	100000000
200	20	2026-11-13	kilometraje	kilometraje	43000
201	20	2026-11-13	version	version	SE-G Automatico
202	21	2026-11-13	precio	precio	114000000
203	21	2026-11-13	kilometraje	kilometraje	36000
204	21	2026-11-13	version	version	1.8 Aut
205	22	2026-11-13	precio	precio	89900000
206	22	2026-11-13	kilometraje	kilometraje	22550
207	22	2026-11-13	version	version	1.8 XL-i Automatico
208	23	2026-11-13	precio	precio	99990000
209	23	2026-11-13	kilometraje	kilometraje	45800
210	23	2026-11-13	version	version	SE-G Automatico
211	24	2026-11-13	precio	precio	108000000
212	24	2026-11-13	kilometraje	kilometraje	34083
213	24	2026-11-13	version	version	1.8 XL-i Automatico
214	25	2026-11-13	precio	precio	145000000
215	25	2026-11-13	kilometraje	kilometraje	30000
216	25	2026-11-13	version	version	SE-G Automatico
217	26	2026-11-13	precio	precio	99900000
218	26	2026-11-13	kilometraje	kilometraje	42000
219	26	2026-11-13	version	version	1.8 XEi-L Automatico
220	27	2026-11-13	precio	precio	102000000
221	27	2026-11-13	kilometraje	kilometraje	21000
222	27	2026-11-13	version	version	1.8 XE-i Automatico
223	28	2026-11-13	precio	precio	115000000
224	28	2026-11-13	kilometraje	kilometraje	20000
225	28	2026-11-13	version	version	1.8 CVT SEG
226	29	2026-11-13	precio	precio	118990000
227	29	2026-11-13	kilometraje	kilometraje	30000
228	29	2026-11-13	version	version	SE-G Automatico
229	30	2026-11-13	precio	precio	95900000
230	30	2026-11-13	kilometraje	kilometraje	37000
231	30	2026-11-13	version	version	GR-S 2.0 Deportivo Manual Gasolina
232	31	2026-11-13	precio	precio	90000000
233	31	2026-11-13	kilometraje	kilometraje	36000
234	31	2026-11-13	version	version	GR-S 2.0 Deportivo Manual Gasolina
235	32	2026-11-13	precio	precio	104900000
236	32	2026-11-13	kilometraje	kilometraje	39000
237	32	2026-11-13	version	version	SE-G Automatico
238	33	2026-11-13	precio	precio	88900000
239	33	2026-11-13	kilometraje	kilometraje	56000
240	33	2026-11-13	version	version	1.8 CVT SEG
241	34	2026-11-13	precio	precio	112900000
242	34	2026-11-13	kilometraje	kilometraje	34000
243	34	2026-11-13	version	version	SE-G Automatico
244	35	2026-11-13	precio	precio	92900000
245	35	2026-11-13	kilometraje	kilometraje	53000
246	35	2026-11-13	version	version	1.8 XE-i Automatico
247	36	2026-11-13	precio	precio	97000000
248	36	2026-11-13	kilometraje	kilometraje	59000
249	36	2026-11-13	version	version	XEI 2.0 Sedan Automatico CVT
250	37	2026-11-13	precio	precio	127900000
251	37	2026-11-13	kilometraje	kilometraje	25400
252	37	2026-11-13	version	version	GR-S 2.0 Deportivo Manual Gasolina
253	38	2026-11-13	precio	precio	85000000
254	38	2026-11-13	kilometraje	kilometraje	56879
255	38	2026-11-13	version	version	1.8 XE-i Automatico
256	39	2026-11-13	precio	precio	102000000
257	39	2026-11-13	kilometraje	kilometraje	53400
258	39	2026-11-13	version	version	1.8 XE-i Automatico
259	40	2026-11-13	precio	precio	106900000
260	40	2026-11-13	kilometraje	kilometraje	48000
261	40	2026-11-13	version	version	1.8 CVT SEG
262	41	2026-11-13	precio	precio	115000000
263	41	2026-11-13	kilometraje	kilometraje	25700
264	41	2026-11-13	version	version	1.8
265	42	2026-11-13	precio	precio	108000000
266	42	2026-11-13	kilometraje	kilometraje	63000
267	42	2026-11-13	version	version	1.8 CVT SEG
268	43	2026-11-13	precio	precio	113000000
269	43	2026-11-13	kilometraje	kilometraje	32000
270	43	2026-11-13	version	version	1.8 XE-i Automatico
271	44	2026-11-13	precio	precio	123000000
272	44	2026-11-13	kilometraje	kilometraje	5000
273	44	2026-11-13	version	version	1.8 XE-i Automatico
274	45	2026-11-13	precio	precio	115000000
275	45	2026-11-13	kilometraje	kilometraje	29000
276	45	2026-11-13	version	version	1.8 CVT XEI
277	46	2026-11-13	precio	precio	106900000
278	46	2026-11-13	kilometraje	kilometraje	30000
279	46	2026-11-13	version	version	1.8 CVT XEI
280	47	2026-11-13	precio	precio	95900000
281	47	2026-11-13	kilometraje	kilometraje	33000
282	47	2026-11-13	version	version	\N
283	48	2026-11-13	precio	precio	145500000
284	48	2026-11-13	kilometraje	kilometraje	10000
285	48	2026-11-13	version	version	\N
286	49	2026-11-13	precio	precio	118000000
287	49	2026-11-13	kilometraje	kilometraje	4151
288	49	2026-11-13	version	version	1.8 XE-i Automatico
289	50	2026-11-13	precio	precio	116900000
290	50	2026-11-13	kilometraje	kilometraje	14000
291	50	2026-11-13	version	version	1.8 CVT SEG
292	51	2026-11-13	precio	precio	144000000
293	51	2026-11-13	kilometraje	kilometraje	15109
294	51	2026-11-13	version	version	1.8 XEi-L Automatico
295	52	2026-11-13	precio	precio	132900000
296	52	2026-11-13	kilometraje	kilometraje	29149
297	52	2026-11-13	version	version	SE-G Automatico
298	53	2026-11-13	precio	precio	116900000
299	53	2026-11-13	kilometraje	kilometraje	14000
300	53	2026-11-13	version	version	1.8 CVT SEG
301	54	2026-11-13	precio	precio	141900000
302	54	2026-11-13	kilometraje	kilometraje	25543
303	54	2026-11-13	version	version	1.8 CVT SEG
304	55	2026-11-13	precio	precio	152000000
305	55	2026-11-13	kilometraje	kilometraje	10200
306	55	2026-11-13	version	version	1.8 CVT SEG
307	56	2026-11-13	precio	precio	129900000
308	56	2026-11-13	kilometraje	kilometraje	9000
309	56	2026-11-13	version	version	1.8 CVT SEG
310	57	2026-11-13	precio	precio	122000000
311	57	2026-11-13	kilometraje	kilometraje	26000
312	57	2026-11-13	version	version	1.8 CVT SEG
313	58	2026-11-13	precio	precio	105900000
314	58	2026-11-13	kilometraje	kilometraje	20000
315	58	2026-11-13	version	version	1.8 XL-i Automatico
316	59	2026-11-13	precio	precio	134000000
317	59	2026-11-13	kilometraje	kilometraje	1600
318	59	2026-11-13	version	version	1.8
319	1	2026-11-14	precio	precio	84900000
320	1	2026-11-14	kilometraje	kilometraje	54984
321	1	2026-11-14	version	version	1.8 XE-i Automatico
322	2	2026-11-14	precio	precio	85000000
323	2	2026-11-14	kilometraje	kilometraje	35000
324	2	2026-11-14	version	version	1.3 Mecanico
325	3	2026-11-14	precio	precio	94000000
326	3	2026-11-14	kilometraje	kilometraje	63000
327	3	2026-11-14	version	version	1.8 CVT SEG
328	4	2026-11-14	precio	precio	98500000
329	4	2026-11-14	kilometraje	kilometraje	40000
330	4	2026-11-14	version	version	1.8 XE-i Automatico
331	5	2026-11-14	precio	precio	115000000
332	5	2026-11-14	kilometraje	kilometraje	20000
333	5	2026-11-14	version	version	\N
334	6	2026-11-14	precio	precio	84990000
335	6	2026-11-14	kilometraje	kilometraje	84392
336	6	2026-11-14	version	version	1.8 XE-i Hybrid Automatico
337	7	2026-11-14	precio	precio	95000000
338	7	2026-11-14	kilometraje	kilometraje	31800
339	7	2026-11-14	version	version	1.8 XE-i Automatico
340	8	2026-11-14	precio	precio	95000000
341	8	2026-11-14	kilometraje	kilometraje	29000
342	8	2026-11-14	version	version	1.8 CVT XEI
343	9	2026-11-14	precio	precio	89000000
344	9	2026-11-14	kilometraje	kilometraje	82000
345	9	2026-11-14	version	version	1.8 XE-i Automatico
346	10	2026-11-14	precio	precio	83990000
347	10	2026-11-14	kilometraje	kilometraje	27952
348	10	2026-11-14	version	version	XEI 2.0 Sedan Manual
349	11	2026-11-14	precio	precio	87000000
350	11	2026-11-14	kilometraje	kilometraje	44000
351	11	2026-11-14	version	version	1.8 XE-i Automatico
352	12	2026-11-14	precio	precio	119900000
353	12	2026-11-14	kilometraje	kilometraje	55000
354	12	2026-11-14	version	version	1.8
355	13	2026-11-14	precio	precio	91900000
356	13	2026-11-14	kilometraje	kilometraje	68000
357	13	2026-11-14	version	version	1.8 CVT SEG
358	14	2026-11-14	precio	precio	89900000
359	14	2026-11-14	kilometraje	kilometraje	52050
360	14	2026-11-14	version	version	1.8 XEi-L Automatico
361	121	2026-11-14	precio	precio	89900000
362	121	2026-11-14	kilometraje	kilometraje	52050
363	121	2026-11-14	version	version	1.8 XEi-L Automatico
364	15	2026-11-14	precio	precio	107900000
365	15	2026-11-14	kilometraje	kilometraje	72300
366	15	2026-11-14	version	version	1.8 CVT XEI
367	16	2026-11-14	precio	precio	111700000
368	16	2026-11-14	kilometraje	kilometraje	85000
369	16	2026-11-14	version	version	1.8 CVT SEG
370	17	2026-11-14	precio	precio	99900000
371	17	2026-11-14	kilometraje	kilometraje	46000
372	17	2026-11-14	version	version	1.8 XL-i Automatico
373	18	2026-11-14	precio	precio	110000000
374	18	2026-11-14	kilometraje	kilometraje	23000
375	18	2026-11-14	version	version	SE-G Automatico
376	19	2026-11-14	precio	precio	101000000
377	19	2026-11-14	kilometraje	kilometraje	1000
378	19	2026-11-14	version	version	1.8 XL-i Automatico
379	20	2026-11-14	precio	precio	100000000
380	20	2026-11-14	kilometraje	kilometraje	43000
381	20	2026-11-14	version	version	SE-G Automatico
382	21	2026-11-14	precio	precio	114000000
383	21	2026-11-14	kilometraje	kilometraje	36000
384	21	2026-11-14	version	version	1.8 Aut
385	22	2026-11-14	precio	precio	89900000
386	22	2026-11-14	kilometraje	kilometraje	22550
387	22	2026-11-14	version	version	1.8 XL-i Automatico
388	23	2026-11-14	precio	precio	99990000
389	23	2026-11-14	kilometraje	kilometraje	45800
390	23	2026-11-14	version	version	SE-G Automatico
391	24	2026-11-14	precio	precio	108000000
392	24	2026-11-14	kilometraje	kilometraje	34083
393	24	2026-11-14	version	version	1.8 XL-i Automatico
394	25	2026-11-14	precio	precio	145000000
395	25	2026-11-14	kilometraje	kilometraje	30000
396	25	2026-11-14	version	version	SE-G Automatico
397	26	2026-11-14	precio	precio	99900000
398	26	2026-11-14	kilometraje	kilometraje	42000
399	26	2026-11-14	version	version	1.8 XEi-L Automatico
400	27	2026-11-14	precio	precio	102000000
401	27	2026-11-14	kilometraje	kilometraje	21000
402	27	2026-11-14	version	version	1.8 XE-i Automatico
403	28	2026-11-14	precio	precio	115000000
404	28	2026-11-14	kilometraje	kilometraje	20000
405	28	2026-11-14	version	version	1.8 CVT SEG
406	29	2026-11-14	precio	precio	118990000
407	29	2026-11-14	kilometraje	kilometraje	30000
408	29	2026-11-14	version	version	SE-G Automatico
409	30	2026-11-14	precio	precio	95900000
410	30	2026-11-14	kilometraje	kilometraje	37000
411	30	2026-11-14	version	version	GR-S 2.0 Deportivo Manual Gasolina
412	31	2026-11-14	precio	precio	90000000
413	31	2026-11-14	kilometraje	kilometraje	36000
414	31	2026-11-14	version	version	GR-S 2.0 Deportivo Manual Gasolina
415	32	2026-11-14	precio	precio	104900000
416	32	2026-11-14	kilometraje	kilometraje	39000
417	32	2026-11-14	version	version	SE-G Automatico
418	33	2026-11-14	precio	precio	88900000
419	33	2026-11-14	kilometraje	kilometraje	56000
420	33	2026-11-14	version	version	1.8 CVT SEG
421	34	2026-11-14	precio	precio	112900000
422	34	2026-11-14	kilometraje	kilometraje	34000
423	34	2026-11-14	version	version	SE-G Automatico
424	35	2026-11-14	precio	precio	92900000
425	35	2026-11-14	kilometraje	kilometraje	53000
426	35	2026-11-14	version	version	1.8 XE-i Automatico
427	36	2026-11-14	precio	precio	97000000
428	36	2026-11-14	kilometraje	kilometraje	59000
429	36	2026-11-14	version	version	XEI 2.0 Sedan Automatico CVT
430	37	2026-11-14	precio	precio	127900000
431	37	2026-11-14	kilometraje	kilometraje	25400
432	37	2026-11-14	version	version	GR-S 2.0 Deportivo Manual Gasolina
433	38	2026-11-14	precio	precio	85000000
434	38	2026-11-14	kilometraje	kilometraje	56879
435	38	2026-11-14	version	version	1.8 XE-i Automatico
436	39	2026-11-14	precio	precio	102000000
437	39	2026-11-14	kilometraje	kilometraje	53400
438	39	2026-11-14	version	version	1.8 XE-i Automatico
439	40	2026-11-14	precio	precio	106900000
440	40	2026-11-14	kilometraje	kilometraje	48000
441	40	2026-11-14	version	version	1.8 CVT SEG
442	41	2026-11-14	precio	precio	115000000
443	41	2026-11-14	kilometraje	kilometraje	25700
444	41	2026-11-14	version	version	1.8
445	42	2026-11-14	precio	precio	108000000
446	42	2026-11-14	kilometraje	kilometraje	63000
447	42	2026-11-14	version	version	1.8 CVT SEG
448	43	2026-11-14	precio	precio	113000000
449	43	2026-11-14	kilometraje	kilometraje	32000
450	43	2026-11-14	version	version	1.8 XE-i Automatico
451	44	2026-11-14	precio	precio	123000000
452	44	2026-11-14	kilometraje	kilometraje	5000
453	44	2026-11-14	version	version	1.8 XE-i Automatico
454	45	2026-11-14	precio	precio	115000000
455	45	2026-11-14	kilometraje	kilometraje	29000
456	45	2026-11-14	version	version	1.8 CVT XEI
457	46	2026-11-14	precio	precio	106900000
458	46	2026-11-14	kilometraje	kilometraje	30000
459	46	2026-11-14	version	version	1.8 CVT XEI
460	47	2026-11-14	precio	precio	95900000
461	47	2026-11-14	kilometraje	kilometraje	33000
462	47	2026-11-14	version	version	\N
463	48	2026-11-14	precio	precio	145500000
464	48	2026-11-14	kilometraje	kilometraje	10000
465	48	2026-11-14	version	version	\N
466	49	2026-11-14	precio	precio	118000000
467	49	2026-11-14	kilometraje	kilometraje	4151
468	49	2026-11-14	version	version	1.8 XE-i Automatico
469	50	2026-11-14	precio	precio	116900000
470	50	2026-11-14	kilometraje	kilometraje	14000
471	50	2026-11-14	version	version	1.8 CVT SEG
472	51	2026-11-14	precio	precio	144000000
473	51	2026-11-14	kilometraje	kilometraje	15109
474	51	2026-11-14	version	version	1.8 XEi-L Automatico
475	52	2026-11-14	precio	precio	132900000
476	52	2026-11-14	kilometraje	kilometraje	29149
477	52	2026-11-14	version	version	SE-G Automatico
478	53	2026-11-14	precio	precio	116900000
479	53	2026-11-14	kilometraje	kilometraje	14000
480	53	2026-11-14	version	version	1.8 CVT SEG
481	54	2026-11-14	precio	precio	141900000
482	54	2026-11-14	kilometraje	kilometraje	25543
483	54	2026-11-14	version	version	1.8 CVT SEG
484	55	2026-11-14	precio	precio	152000000
485	55	2026-11-14	kilometraje	kilometraje	10200
486	55	2026-11-14	version	version	1.8 CVT SEG
487	56	2026-11-14	precio	precio	129900000
488	56	2026-11-14	kilometraje	kilometraje	9000
489	56	2026-11-14	version	version	1.8 CVT SEG
490	57	2026-11-14	precio	precio	122000000
491	57	2026-11-14	kilometraje	kilometraje	26000
492	57	2026-11-14	version	version	1.8 CVT SEG
493	58	2026-11-14	precio	precio	105900000
494	58	2026-11-14	kilometraje	kilometraje	20000
495	58	2026-11-14	version	version	1.8 XL-i Automatico
496	59	2026-11-14	precio	precio	134000000
497	59	2026-11-14	kilometraje	kilometraje	1600
498	59	2026-11-14	version	version	1.8
499	1	2026-11-15	precio	precio	84900000
500	1	2026-11-15	kilometraje	kilometraje	54984
501	1	2026-11-15	version	version	1.8 XE-i Automatico
502	2	2026-11-15	precio	precio	85000000
503	2	2026-11-15	kilometraje	kilometraje	35000
504	2	2026-11-15	version	version	1.3 Mecanico
505	3	2026-11-15	precio	precio	94000000
506	3	2026-11-15	kilometraje	kilometraje	63000
507	3	2026-11-15	version	version	1.8 CVT SEG
508	4	2026-11-15	precio	precio	98500000
509	4	2026-11-15	kilometraje	kilometraje	40000
510	4	2026-11-15	version	version	1.8 XE-i Automatico
511	5	2026-11-15	precio	precio	115000000
512	5	2026-11-15	kilometraje	kilometraje	20000
513	5	2026-11-15	version	version	\N
514	6	2026-11-15	precio	precio	84990000
515	6	2026-11-15	kilometraje	kilometraje	84392
516	6	2026-11-15	version	version	1.8 XE-i Hybrid Automatico
517	7	2026-11-15	precio	precio	95000000
518	7	2026-11-15	kilometraje	kilometraje	31800
519	7	2026-11-15	version	version	1.8 XE-i Automatico
520	8	2026-11-15	precio	precio	95000000
521	8	2026-11-15	kilometraje	kilometraje	29000
522	8	2026-11-15	version	version	1.8 CVT XEI
523	9	2026-11-15	precio	precio	89000000
524	9	2026-11-15	kilometraje	kilometraje	82000
525	9	2026-11-15	version	version	1.8 XE-i Automatico
526	10	2026-11-15	precio	precio	83990000
527	10	2026-11-15	kilometraje	kilometraje	27952
528	10	2026-11-15	version	version	XEI 2.0 Sedan Manual
529	11	2026-11-15	precio	precio	87000000
530	11	2026-11-15	kilometraje	kilometraje	44000
531	11	2026-11-15	version	version	1.8 XE-i Automatico
532	12	2026-11-15	precio	precio	119900000
533	12	2026-11-15	kilometraje	kilometraje	55000
534	12	2026-11-15	version	version	1.8
535	13	2026-11-15	precio	precio	91900000
536	13	2026-11-15	kilometraje	kilometraje	68000
537	13	2026-11-15	version	version	1.8 CVT SEG
538	14	2026-11-15	precio	precio	89900000
539	14	2026-11-15	kilometraje	kilometraje	52050
540	14	2026-11-15	version	version	1.8 XEi-L Automatico
541	121	2026-11-15	precio	precio	89900000
542	121	2026-11-15	kilometraje	kilometraje	52050
543	121	2026-11-15	version	version	1.8 XEi-L Automatico
544	15	2026-11-15	precio	precio	107900000
545	15	2026-11-15	kilometraje	kilometraje	72300
546	15	2026-11-15	version	version	1.8 CVT XEI
547	16	2026-11-15	precio	precio	111700000
548	16	2026-11-15	kilometraje	kilometraje	85000
549	16	2026-11-15	version	version	1.8 CVT SEG
550	17	2026-11-15	precio	precio	99900000
551	17	2026-11-15	kilometraje	kilometraje	46000
552	17	2026-11-15	version	version	1.8 XL-i Automatico
553	18	2026-11-15	precio	precio	110000000
554	18	2026-11-15	kilometraje	kilometraje	23000
555	18	2026-11-15	version	version	SE-G Automatico
556	19	2026-11-15	precio	precio	101000000
557	19	2026-11-15	kilometraje	kilometraje	1000
558	19	2026-11-15	version	version	1.8 XL-i Automatico
559	20	2026-11-15	precio	precio	100000000
560	20	2026-11-15	kilometraje	kilometraje	43000
561	20	2026-11-15	version	version	SE-G Automatico
562	21	2026-11-15	precio	precio	114000000
563	21	2026-11-15	kilometraje	kilometraje	36000
564	21	2026-11-15	version	version	1.8 Aut
565	22	2026-11-15	precio	precio	89900000
566	22	2026-11-15	kilometraje	kilometraje	22550
567	22	2026-11-15	version	version	1.8 XL-i Automatico
568	23	2026-11-15	precio	precio	99990000
569	23	2026-11-15	kilometraje	kilometraje	45800
570	23	2026-11-15	version	version	SE-G Automatico
571	24	2026-11-15	precio	precio	108000000
572	24	2026-11-15	kilometraje	kilometraje	34083
573	24	2026-11-15	version	version	1.8 XL-i Automatico
574	25	2026-11-15	precio	precio	145000000
575	25	2026-11-15	kilometraje	kilometraje	30000
576	25	2026-11-15	version	version	SE-G Automatico
577	26	2026-11-15	precio	precio	99900000
578	26	2026-11-15	kilometraje	kilometraje	42000
579	26	2026-11-15	version	version	1.8 XEi-L Automatico
580	27	2026-11-15	precio	precio	102000000
581	27	2026-11-15	kilometraje	kilometraje	21000
582	27	2026-11-15	version	version	1.8 XE-i Automatico
583	28	2026-11-15	precio	precio	115000000
584	28	2026-11-15	kilometraje	kilometraje	20000
585	28	2026-11-15	version	version	1.8 CVT SEG
586	29	2026-11-15	precio	precio	118990000
587	29	2026-11-15	kilometraje	kilometraje	30000
588	29	2026-11-15	version	version	SE-G Automatico
589	30	2026-11-15	precio	precio	95900000
590	30	2026-11-15	kilometraje	kilometraje	37000
591	30	2026-11-15	version	version	GR-S 2.0 Deportivo Manual Gasolina
592	31	2026-11-15	precio	precio	90000000
593	31	2026-11-15	kilometraje	kilometraje	36000
594	31	2026-11-15	version	version	GR-S 2.0 Deportivo Manual Gasolina
595	32	2026-11-15	precio	precio	104900000
596	32	2026-11-15	kilometraje	kilometraje	39000
597	32	2026-11-15	version	version	SE-G Automatico
598	33	2026-11-15	precio	precio	88900000
599	33	2026-11-15	kilometraje	kilometraje	56000
600	33	2026-11-15	version	version	1.8 CVT SEG
601	34	2026-11-15	precio	precio	112900000
602	34	2026-11-15	kilometraje	kilometraje	34000
603	34	2026-11-15	version	version	SE-G Automatico
604	35	2026-11-15	precio	precio	92900000
605	35	2026-11-15	kilometraje	kilometraje	53000
606	35	2026-11-15	version	version	1.8 XE-i Automatico
607	36	2026-11-15	precio	precio	97000000
608	36	2026-11-15	kilometraje	kilometraje	59000
609	36	2026-11-15	version	version	XEI 2.0 Sedan Automatico CVT
610	37	2026-11-15	precio	precio	127900000
611	37	2026-11-15	kilometraje	kilometraje	25400
612	37	2026-11-15	version	version	GR-S 2.0 Deportivo Manual Gasolina
613	38	2026-11-15	precio	precio	85000000
614	38	2026-11-15	kilometraje	kilometraje	56879
615	38	2026-11-15	version	version	1.8 XE-i Automatico
616	39	2026-11-15	precio	precio	102000000
617	39	2026-11-15	kilometraje	kilometraje	53400
618	39	2026-11-15	version	version	1.8 XE-i Automatico
619	40	2026-11-15	precio	precio	106900000
620	40	2026-11-15	kilometraje	kilometraje	48000
621	40	2026-11-15	version	version	1.8 CVT SEG
622	41	2026-11-15	precio	precio	115000000
623	41	2026-11-15	kilometraje	kilometraje	25700
624	41	2026-11-15	version	version	1.8
625	42	2026-11-15	precio	precio	108000000
626	42	2026-11-15	kilometraje	kilometraje	63000
627	42	2026-11-15	version	version	1.8 CVT SEG
628	43	2026-11-15	precio	precio	113000000
629	43	2026-11-15	kilometraje	kilometraje	32000
630	43	2026-11-15	version	version	1.8 XE-i Automatico
631	44	2026-11-15	precio	precio	123000000
632	44	2026-11-15	kilometraje	kilometraje	5000
633	44	2026-11-15	version	version	1.8 XE-i Automatico
634	45	2026-11-15	precio	precio	115000000
635	45	2026-11-15	kilometraje	kilometraje	29000
636	45	2026-11-15	version	version	1.8 CVT XEI
637	46	2026-11-15	precio	precio	106900000
638	46	2026-11-15	kilometraje	kilometraje	30000
639	46	2026-11-15	version	version	1.8 CVT XEI
640	47	2026-11-15	precio	precio	95900000
641	47	2026-11-15	kilometraje	kilometraje	33000
642	47	2026-11-15	version	version	\N
643	48	2026-11-15	precio	precio	145500000
644	48	2026-11-15	kilometraje	kilometraje	10000
645	48	2026-11-15	version	version	\N
646	49	2026-11-15	precio	precio	118000000
647	49	2026-11-15	kilometraje	kilometraje	4151
648	49	2026-11-15	version	version	1.8 XE-i Automatico
649	50	2026-11-15	precio	precio	116900000
650	50	2026-11-15	kilometraje	kilometraje	14000
651	50	2026-11-15	version	version	1.8 CVT SEG
652	51	2026-11-15	precio	precio	144000000
653	51	2026-11-15	kilometraje	kilometraje	15109
654	51	2026-11-15	version	version	1.8 XEi-L Automatico
655	52	2026-11-15	precio	precio	132900000
656	52	2026-11-15	kilometraje	kilometraje	29149
657	52	2026-11-15	version	version	SE-G Automatico
658	53	2026-11-15	precio	precio	116900000
659	53	2026-11-15	kilometraje	kilometraje	14000
660	53	2026-11-15	version	version	1.8 CVT SEG
661	54	2026-11-15	precio	precio	141900000
662	54	2026-11-15	kilometraje	kilometraje	25543
663	54	2026-11-15	version	version	1.8 CVT SEG
664	55	2026-11-15	precio	precio	152000000
665	55	2026-11-15	kilometraje	kilometraje	10200
666	55	2026-11-15	version	version	1.8 CVT SEG
667	56	2026-11-15	precio	precio	129900000
668	56	2026-11-15	kilometraje	kilometraje	9000
669	56	2026-11-15	version	version	1.8 CVT SEG
670	57	2026-11-15	precio	precio	122000000
671	57	2026-11-15	kilometraje	kilometraje	26000
672	57	2026-11-15	version	version	1.8 CVT SEG
673	58	2026-11-15	precio	precio	105900000
674	58	2026-11-15	kilometraje	kilometraje	20000
675	58	2026-11-15	version	version	1.8 XL-i Automatico
676	59	2026-11-15	precio	precio	134000000
677	59	2026-11-15	kilometraje	kilometraje	1600
678	59	2026-11-15	version	version	1.8
\.


--
-- Data for Name: log_ejecucion; Type: TABLE DATA; Schema: public; Owner: carroya_user
--

COPY public.log_ejecucion (id, run_id, etapa, fecha_inicio, fecha_fin, duracion_seg, estado, enlaces_encontrados, descargas_ok, descargas_fallidas, descargas_pendientes, anuncios_nuevos, registros_actualizados, registros_sin_cambio, no_encontrados, anuncios_unicos_total, tamanio_bd_mb, correo_estado, mensaje, detalle_error) FROM stdin;
1	2026-11-11	scraper	2026-11-11 23:38:08.776827-05	2026-11-11 23:45:36.286363-05	447.51	ok	59	59	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N
2	2026-11-11	loader	2026-11-11 23:45:36.427475-05	2026-11-11 23:45:36.492365-05	0.06	ok	\N	\N	\N	\N	59	0	0	0	59	8.02	\N	\N	\N
3	2026-11-11	analisis	2026-11-11 23:45:37.141338-05	2026-11-11 23:45:37.52052-05	0.38	ok	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	fecha=2026-11-11 n_dia=59 evaluados=52 gangas=5 gangas_nuevas=5 insuficientes=7	\N
4	2026-11-11	correo	2026-11-11 23:45:57.9476-05	2026-11-11 23:45:57.949398-05	0.00	ok	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	enviado	PRUEBA · [PRUEBA] Corolla 11/11/2026 · Proceso completo · 5 posible(s) ganga(s) nueva(s)	\N
5	2026-11-12	scraper	2026-11-12 08:00:01.447184-05	2026-11-12 08:06:25.220228-05	383.77	ok	47	47	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N
6	2026-11-12	loader	2026-11-12 08:06:25.344527-05	2026-11-12 08:06:25.430893-05	0.09	ok	\N	\N	\N	\N	0	47	0	12	59	8.12	\N	\N	\N
7	2026-11-12	analisis	2026-11-12 08:06:26.061019-05	2026-11-12 08:06:26.420514-05	0.36	ok	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	fecha=2026-11-12 n_dia=47 evaluados=42 gangas=4 gangas_nuevas=0 insuficientes=5	\N
8	2026-11-12	correo	2026-11-12 11:00:05.759783-05	2026-11-12 11:00:05.762059-05	0.00	ok	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	enviado	PRUEBA · [PRUEBA] Corolla 12/11/2026 · Proceso completo · 0 posible(s) ganga(s) nueva(s)	\N
9	2026-11-13	scraper	2026-11-13 08:00:01.91734-05	2026-11-13 08:07:09.462463-05	427.55	ok	60	60	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N
10	2026-11-13	loader	2026-11-13 08:07:09.605169-05	2026-11-13 08:07:09.741438-05	0.14	ok	\N	\N	\N	\N	1	59	0	0	60	8.18	\N	\N	\N
11	2026-11-13	analisis	2026-11-13 08:07:10.380046-05	2026-11-13 08:07:10.768764-05	0.39	ok	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	fecha=2026-11-13 n_dia=60 evaluados=53 gangas=6 gangas_nuevas=0 insuficientes=7	\N
12	2026-11-13	correo	2026-11-13 11:00:06.143616-05	2026-11-13 11:00:06.145219-05	0.00	ok	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	enviado	PRUEBA · [PRUEBA] Corolla 13/11/2026 · Proceso completo · 0 posible(s) ganga(s) nueva(s)	\N
13	2026-11-14	scraper	2026-11-14 08:00:01.169669-05	2026-11-14 08:06:59.426748-05	418.26	ok	60	60	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N
14	2026-11-14	loader	2026-11-14 08:06:59.569199-05	2026-11-14 08:06:59.668006-05	0.10	ok	\N	\N	\N	\N	0	60	0	0	60	8.25	\N	\N	\N
15	2026-11-14	analisis	2026-11-14 08:07:00.128464-05	2026-11-14 08:07:00.506929-05	0.38	ok	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	fecha=2026-11-14 n_dia=60 evaluados=53 gangas=6 gangas_nuevas=0 insuficientes=7	\N
16	2026-11-14	correo	2026-11-14 11:00:05.587078-05	2026-11-14 11:00:05.588797-05	0.00	ok	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	enviado	PRUEBA · [PRUEBA] Corolla 14/11/2026 · Proceso completo · 0 posible(s) ganga(s) nueva(s)	\N
17	2026-11-15	scraper	2026-11-15 08:00:01.610119-05	2026-11-15 08:07:31.045919-05	449.44	ok	61	61	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N
18	2026-11-15	loader	2026-11-15 08:07:31.167642-05	2026-11-15 08:07:31.267829-05	0.10	ok	\N	\N	\N	\N	1	60	0	0	61	8.31	\N	\N	\N
19	2026-11-15	analisis	2026-11-15 08:07:31.731517-05	2026-11-15 08:07:32.114751-05	0.38	ok	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	fecha=2026-11-15 n_dia=61 evaluados=54 gangas=5 gangas_nuevas=0 insuficientes=7	\N
20	2026-11-15	correo	2026-11-15 11:00:07.132889-05	2026-11-15 11:00:07.134637-05	0.00	ok	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	enviado	PRUEBA · [PRUEBA] Corolla 15/11/2026 · Proceso completo · 0 posible(s) ganga(s) nueva(s)	\N
\.


--
-- Data for Name: observacion; Type: TABLE DATA; Schema: public; Owner: carroya_user
--

COPY public.observacion (id, anuncio_id, fecha, hora, estado, version, precio, moneda, kilometraje, transmision, color, sunroof, error, combustible, comentarios) FROM stdin;
1	1	2026-11-11	23:39:28	descargado	1.8 XE-i Automatico	84900000	COP	54984	Automática	Plateado	f	\N	Híbrido	🚗 ¡OPORTUNIDAD! Toyota Corolla Híbrido XEI 2022, en excelente estado, nunca siniestrado según historial. Elegante, cómodo y económico en combustible. Tecnología híbrida, ideal para ciudad y carretera. Placa terminada en 8. 💰 $84.900.000 negociables. ¡Un Toyota que combina confort, ahorro y confiabilidad! Agenda tu visita y conócelo.
2	2	2026-11-11	23:39:34	descargado	1.3 Mecanico	85000000	COP	35000	Mecánica	Gris	f	\N	Gasolina	Vehiculo en perfecto estado, A/C, direccionales habatibles, pernos de seguridad, seguro de direccionales, ventanas contrarobo, mantenimientos en cosecionario, único dueño, placa par.
3	3	2026-11-11	23:39:58	descargado	1.8 CVT SEG	94000000	COP	63000	Automática	Gris	t	\N	Híbrido	VEHICULO EN EXCELENTES CONDICIONES LISTO PARA TRASPASO VERSION FULL SEG 2022 63.000 SUN ROOF TAPICERIA EN CUERO APPLE CAR PLAY
4	4	2026-11-11	23:40:04	descargado	1.8 XE-i Automatico	98500000	COP	40000	Automática	Negro	f	\N	Híbrido	Toyota Corolla Hybrid Black Edition 2022, todos sus mantenimientos en ToyoNorte, al día de impuestos, perfecto estado, tapetes todo tiempo toyota, sin pico y placa, no enchufable, consumo muy bajo, silencioso y potente. Negociable. Soat y técnico hasta 2027. CarPlay, cámara trasera, sensores delanteros y traseros, Venta directa.
5	5	2026-11-11	23:40:09	descargado	\N	115000000	COP	20000	Automática	Blanco	t	\N	Híbrido	SEG Hybrid, full equipo, cuenta con siete airbags, película polarizada, cojinería en cuero, sunroof, no tiene pico y placa, se entrega con la revisión de los 20000 Km, venta directa, único dueño
6	6	2026-11-11	23:40:15	descargado	1.8 XE-i Hybrid Automatico	84990000	COP	84392	Automática	Blanco	f	\N	Híbrido	N/A
7	7	2026-11-11	23:40:21	descargado	1.8 XE-i Automatico	95000000	COP	31800	Automática	Gris	f	\N	Híbrido	Excelente estado como nuevo, sin pico y placa , mtto de 30.000 km recien hecho, unico dueño, todos los mantenimientos realizados en carco, libre de papeles, no tiene pignoraciones.
8	8	2026-11-11	23:40:27	descargado	1.8 CVT XEI	95000000	COP	29000	Secuencial	Blanco	f	\N	Híbrido	Único dueño, perfecto estado, mantenimientos al día
9	9	2026-11-11	23:40:33	descargado	1.8 XE-i Automatico	89000000	COP	82000	Automática	Blanco	f	\N	Híbrido	Toyota Corolla 2022, 100% hibrido 82,000 km. Último mantenimiento realizado el de 80.000 km, llantas nuevas y con todos los mantenimientos directamente con Toyota conforme al libro de la marca. Motor de 1.8 litros y 136 hp, transmisión automática, dirección electroasistida y tracción delantera Autonomía hasta 90Km por galón. Control de estabilidad, sensores de estacionamiento, cámara de revers...
10	10	2026-11-11	23:40:39	descargado	XEI 2.0 Sedan Manual	83990000	COP	27952	Mecánica	Rojo	f	\N	Gasolina	2 llaves manules
11	11	2026-11-11	23:40:45	descargado	1.8 XE-i Automatico	87000000	COP	44000	Automática	Blanco	f	\N	Híbrido	Toyota Corolla híbrido modelo Chery 2022, llantas al 99%, SOAT recién comprado, papeles al día, listo para traspaso inmediato, puede hacerse revisión en CDA sin ningún problema, pasa sin problema, mantenimientos con Toyota Motor y único dueño, perfecto estado del carro.
12	12	2026-11-11	23:40:50	descargado	1.8	119900000	COP	55000	Automática	Blanco	f	\N	Híbrido	Corolla Seg blindaje2 híbrido
13	13	2026-11-11	23:40:56	descargado	1.8 CVT SEG	91900000	COP	68000	Automática	Blanco	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
14	14	2026-11-11	23:41:02	descargado	1.8 XEi-L Automatico	89900000	COP	52050	Automática	Blanco	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
15	15	2026-11-11	23:41:08	descargado	1.8 CVT XEI	107900000	COP	72300	Automática	Blanco	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
16	16	2026-11-11	23:41:15	descargado	1.8 CVT SEG	111700000	COP	85000	Automática	Plateado	f	\N	Híbrido	Llantas y Soat comprados en septiembre 2026, excelente estado, unico dueño
17	17	2026-11-11	23:41:21	descargado	1.8 XL-i Automatico	99900000	COP	46000	Automática	Gris	f	\N	Híbrido	Toyota Corolla XLI Hybrid 2023 | Único dueño | 46.000 km | Equipado con accesorios originales de agencia. ⭐ *Equipamiento y extras* * Sistema híbrido 1.8L Toyota, automático E * Llantas y rines originales *de la versión SEG*, instalados de agencia * Polarizado premium. * Tapetes termoformado * Protectores *originales* de retrovisores. * Estribos *originales* de agencia * Interior y exterior en ex...
18	18	2026-11-11	23:41:27	descargado	SE-G Automatico	110000000	COP	23000	Automática	Gris	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
19	19	2026-11-11	23:41:33	descargado	1.8 XL-i Automatico	101000000	COP	1000	Automática	Blanco	f	\N	Híbrido	2023 Toyota Corolla XLI 1.8 Hibrido. KILOMETRAJE es 14
20	20	2026-11-11	23:41:39	descargado	SE-G Automatico	100000000	COP	43000	Automática	Blanco	t	\N	Híbrido	🇨🇴🏁🇯🇵 Toyota Corolla SE-G Hybrid 2.023 ✅️ Listo para Traspaso. ✅ Único Dueño. ✅ 43.000 Km. ✅ Motor 1.8cc Híbrido. ️✅️ Automático. ️✅️ Full Equipo. ✅️ 7 Airbags. ✅️ Sunroof. ✅ Tapicería Cuero. ✅ Polarizado. ✅ Apple CarPlay/ Android Auto. ✅ Mantenimientos en Concesionario. ✅️ Matrícula Bogotá.
21	21	2026-11-11	23:41:45	descargado	1.8 Aut	114000000	COP	36000	Automática	Blanco	f	\N	Híbrido	Toyota Corolla Hibrido Seg Full equipo Modelo 2023 36.000 km Todo el mantenimiento certificado en concesionario
22	22	2026-11-11	23:41:51	descargado	1.8 XL-i Automatico	89900000	COP	22550	Automática	Blanco	f	\N	Híbrido	Híbrido full poco kilometraje, único conductor desde nuevo en trayectos urbanos, pintura con tratamiento porcelanizado, vidrios con película de seguridad, batería de 12v nueva para arranque, libro de mantenimientos original toyota con historial completo, solo en concesionario sus mantenimientos, excelente estado motor, exterior e interior, tapicería en tela, vidrios eléctricos, llave inteligente, ...
23	23	2026-11-11	23:41:57	descargado	SE-G Automatico	99990000	COP	45800	Automática	Gris	f	\N	Gasolina	N/A
24	24	2026-11-11	23:42:03	descargado	1.8 XL-i Automatico	108000000	COP	34083	Automática	Gris	t	\N	Híbrido	Único dueño, accesorios originales.
25	25	2026-11-11	23:42:08	descargado	SE-G Automatico	145000000	COP	30000	Automática	Gris	t	\N	Híbrido	El vendedor no incluyó una descripción del producto.
26	26	2026-11-11	23:42:14	descargado	1.8 XEi-L Automatico	99900000	COP	42000	Automática	Gris	f	\N	Híbrido	TOYOTA COROLLA XE-I HYBRID TP 1800CC 7AB ABS MOD 2023 🚙 Recorrido: 42.000km 🚙 Soat: 24/02/2026 🚙 Tecno: N/A 🚙 Placa: 1️⃣ 🚙 ABS 🚙 Airbags: 7 🚙 Mandos en el timón 🚙 Cámara de reversa 🚙 Sensores 🚙 Dirección: Eléctrica 🚙 Frenos: Disco/Disco 🚙 Faros: LED 🚙 Espejos eléctricos 2 🚙 Tracción: Delantera 🚙 Vidrios eléctricos: 4 🚙 Tapicería: Tela 🚙 Caja: Triptonica 🚙 Color: GRIS CELESTE ...
27	27	2026-11-11	23:42:20	descargado	1.8 XE-i Automatico	102000000	COP	21000	Automática	Blanco	f	\N	Híbrido	Vehículo en excelente estado, peritaje donde desee, recibo vehículo de menor valor
28	28	2026-11-11	23:42:26	descargado	1.8 CVT SEG	115000000	COP	20000	Automática	Plateado	t	\N	Híbrido	El vendedor no incluyó una descripción del producto.
29	29	2026-11-11	23:42:32	descargado	SE-G Automatico	118990000	COP	30000	Automática	Blanco	t	\N	Híbrido	Hermoso Toyota Corolla Sedan Blanco perlado Version mas equipada SEG. Cogineria en cuero, sunroof, todas las ayudas de conduccion, camara trasera y sensores de colision. Hibridacion Full (Consumo combustible promedio en ciudad 70 km/galon) Modelo 2023 con apenas 30.000 km Llantas nuevas (menos de 6 meses)
30	30	2026-11-11	23:42:38	descargado	GR-S 2.0 Deportivo Manual Gasolina	95900000	COP	37000	Automática	Rojo	f	\N	Gasolina	El vendedor no incluyó una descripción del producto.
31	31	2026-11-11	23:42:45	descargado	GR-S 2.0 Deportivo Manual Gasolina	90000000	COP	36000	Automática	Rojo	f	\N	Gasolina	excelente precio poco kilometraje, unico dueño, nunca chocado, seguro todo riesgo AXA, soat hasta agosto 2027, perfecto estado, mod 2023.
32	32	2026-11-11	23:42:50	descargado	SE-G Automatico	104900000	COP	39000	Automática	Rojo	f	\N	Híbrido	Toyota Corolla Híbrido 2023 SEG - Versión full equipo 39.900 km Mantenimientos en concesionario Sin reclamaciones Dos llaves Soat vigente Pasa peritaje Ubicado en ibague
33	33	2026-11-11	23:42:56	descargado	1.8 CVT SEG	88900000	COP	56000	Automática	Gris	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
34	34	2026-11-11	23:43:02	descargado	SE-G Automatico	112900000	COP	34000	Automática	Gris	f	\N	Híbrido	🚙 🚗Toyota Corolla SEG Modelo 2023 Híbrido 34.000km Automático Conineria de cuero #venta #Medellin #autos
35	35	2026-11-11	23:43:08	descargado	1.8 XE-i Automatico	92900000	COP	53000	Automática	Gris	f	\N	Híbrido	Medellin
36	36	2026-11-11	23:43:14	descargado	XEI 2.0 Sedan Automatico CVT	97000000	COP	59000	0	Gris	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
37	37	2026-11-11	23:43:20	descargado	GR-S 2.0 Deportivo Manual Gasolina	127900000	COP	25400	Automática	Blanco	f	\N	Gasolina	Toyota Corolla Cross GR-S 2.0cc - Modelo: 2023 - Kilometraje: 25.400kms - Transmisión: Automática - Tracción: 4x2 - Combustible: Gasolina - Soat: 26/03/2027 - Tecno: 20/02/2028 - Placa Finaliza: 9
38	38	2026-11-11	23:43:25	descargado	1.8 XE-i Automatico	85000000	COP	56879	Automática	Gris	f	\N	Híbrido	Toyota Corolla XEI HIBRIDO 2023 56.879km 1.8cc Automatico Cojineria cuero Vidrios y espejos electricos Mandos en el timon Pantalla tactil Camara reversa Rines de lujo Llantas 70% Soat 24-junio-2027 Tecno 24-junio-2028
39	39	2026-11-11	23:43:31	descargado	1.8 XE-i Automatico	102000000	COP	53400	Automática	Otro	f	\N	Híbrido	¿Buscas confort, tecnología y ahorro? Vendo mi Toyota Corolla XEI Híbrido modelo 2023, una joya de la ingeniería japonesa. Con solo 53.400 km de recorrido. Motor 1.800cc- Automatico - sistema hibrido (Autorecargable) - 7 airbags - frenos ABS - silleteria de cuero - con asistencia y ayudas para la conducción - mandos en el timon - espejos electricos, vidrios electricos - color gris celeste - Pantal...
40	40	2026-11-11	23:43:37	descargado	1.8 CVT SEG	106900000	COP	48000	Automática	Gris	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
41	41	2026-11-11	23:43:43	descargado	1.8	115000000	COP	25700	Automática	Blanco	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
42	42	2026-11-11	23:43:49	descargado	1.8 CVT SEG	108000000	COP	63000	Automática	Plateado	f	\N	Híbrido	Toyota Corolla Seg Hibrido
43	43	2026-11-11	23:43:55	descargado	1.8 XE-i Automatico	113000000	COP	32000	Automática	Gris	f	\N	Híbrido	Toyota Corolla 2024 32.000 Km Perfecto estado 113.000.000 Negociables
44	44	2026-11-11	23:44:00	descargado	1.8 XE-i Automatico	123000000	COP	5000	Automática	Rojo	f	\N	Híbrido	Esperctacular bien cuidado con cojineria en cuero, UNICO DUEÑO full equipo HIBRIDO vendo directamente negociable
45	45	2026-11-11	23:44:06	descargado	1.8 CVT XEI	115000000	COP	29000	Automática	Plateado	f	\N	Híbrido	Pelicula de Seguridad en los vidrios Pernos de seguridad en las llantas
46	46	2026-11-11	23:44:12	descargado	1.8 CVT XEI	106900000	COP	30000	Automática	Blanco	f	\N	Híbrido	Único dueño. Medellín hibrido todo en cocesiy
47	47	2026-11-11	23:44:18	descargado	\N	95900000	COP	33000	Automática	Blanco	f	\N	Híbrido	Toyota Corolla XLI híbrido
48	48	2026-11-11	23:44:23	descargado	\N	145500000	COP	10000	Automática	Gris	f	\N	Híbrido	Camioneta prácticamente nueva. Precio negociable. Es la versión básica aunque lo suficientemente equipada.
49	49	2026-11-11	23:44:29	descargado	1.8 XE-i Automatico	118000000	COP	4151	Automática	Lila	f	\N	Híbrido	Equipado con dirección electroasistida, aire acondicionado, cámara de reversa y sistema de audio con Bluetooth, este Corolla también incluye características de seguridad como airbags y frenos ABS. Su diseño y tecnología lo hacen adecuado para la ciudad y viajes cortos, pelicula de vidrios y turecas de seguridad en las llantas
50	50	2026-11-11	23:44:35	descargado	1.8 CVT SEG	116900000	COP	14000	Automática	Gris	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
51	51	2026-11-11	23:44:41	descargado	1.8 XEi-L Automatico	144000000	COP	15109	Automática	Gris	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
52	52	2026-11-11	23:44:47	descargado	SE-G Automatico	132900000	COP	29149	Automática	Blanco	f	\N	Gasolina	El vendedor no incluyó una descripción del producto.
53	53	2026-11-11	23:44:54	descargado	1.8 CVT SEG	116900000	COP	14000	Automática	Gris	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
54	54	2026-11-11	23:45:00	descargado	1.8 CVT SEG	141900000	COP	25543	Automática	Blanco	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
55	55	2026-11-11	23:45:06	descargado	1.8 CVT SEG	152000000	COP	10200	Automática	Plateado	f	\N	Híbrido	Perfecto estado
56	56	2026-11-11	23:45:12	descargado	1.8 CVT SEG	129900000	COP	9000	Automática	Blanco	f	\N	Híbrido	Vehículo en Excelente estado, documentos al día, impuestos al día. Vendo o permuto por vehículo o motocicleta de menor valor.
57	57	2026-11-11	23:45:17	descargado	1.8 CVT SEG	122000000	COP	26000	Automática	Blanco	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
58	58	2026-11-11	23:45:23	descargado	1.8 XL-i Automatico	105900000	COP	20000	Automática	Blanco	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
59	59	2026-11-11	23:45:29	descargado	1.8	134000000	COP	1600	Automática	Gris	f	\N	Híbrido	Carro casi nuevo Toyota Corolla 1.8 Hev Seg kilometraje 1.600 modelo 2026
60	1	2026-11-12	08:01:50	descargado	1.8 XE-i Automatico	84900000	COP	54984	Automática	Plateado	f	\N	Híbrido	🚗 ¡OPORTUNIDAD! Toyota Corolla Híbrido XEI 2022, en excelente estado, nunca siniestrado según historial. Elegante, cómodo y económico en combustible. Tecnología híbrida, ideal para ciudad y carretera. Placa terminada en 8. 💰 $84.900.000 negociables. ¡Un Toyota que combina confort, ahorro y confiabilidad! Agenda tu visita y conócelo.
61	2	2026-11-12	08:01:57	descargado	1.3 Mecanico	85000000	COP	35000	Mecánica	Gris	f	\N	Gasolina	Vehiculo en perfecto estado, A/C, direccionales habatibles, pernos de seguridad, seguro de direccionales, ventanas contrarobo, mantenimientos en cosecionario, único dueño, placa par.
62	4	2026-11-12	08:02:03	descargado	1.8 XE-i Automatico	98500000	COP	40000	Automática	Negro	f	\N	Híbrido	Toyota Corolla Hybrid Black Edition 2022, todos sus mantenimientos en ToyoNorte, al día de impuestos, perfecto estado, tapetes todo tiempo toyota, sin pico y placa, no enchufable, consumo muy bajo, silencioso y potente. Negociable. Soat y técnico hasta 2027. CarPlay, cámara trasera, sensores delanteros y traseros, Venta directa.
63	5	2026-11-12	08:02:09	descargado	\N	115000000	COP	20000	Automática	Blanco	t	\N	Híbrido	SEG Hybrid, full equipo, cuenta con siete airbags, película polarizada, cojinería en cuero, sunroof, no tiene pico y placa, se entrega con la revisión de los 20000 Km, venta directa, único dueño
64	6	2026-11-12	08:02:15	descargado	1.8 XE-i Hybrid Automatico	84990000	COP	84392	Automática	Blanco	f	\N	Híbrido	N/A
65	7	2026-11-12	08:02:21	descargado	1.8 XE-i Automatico	95000000	COP	31800	Automática	Gris	f	\N	Híbrido	Excelente estado como nuevo, sin pico y placa , mtto de 30.000 km recien hecho, unico dueño, todos los mantenimientos realizados en carco, libre de papeles, no tiene pignoraciones.
66	8	2026-11-12	08:02:26	descargado	1.8 CVT XEI	95000000	COP	29000	Secuencial	Blanco	f	\N	Híbrido	Único dueño, perfecto estado, mantenimientos al día
67	9	2026-11-12	08:02:32	descargado	1.8 XE-i Automatico	89000000	COP	82000	Automática	Blanco	f	\N	Híbrido	Toyota Corolla 2022, 100% hibrido 82,000 km. Último mantenimiento realizado el de 80.000 km, llantas nuevas y con todos los mantenimientos directamente con Toyota conforme al libro de la marca. Motor de 1.8 litros y 136 hp, transmisión automática, dirección electroasistida y tracción delantera Autonomía hasta 90Km por galón. Control de estabilidad, sensores de estacionamiento, cámara de revers...
68	10	2026-11-12	08:02:38	descargado	XEI 2.0 Sedan Manual	83990000	COP	27952	Mecánica	Rojo	f	\N	Gasolina	2 llaves manules
69	11	2026-11-12	08:02:44	descargado	1.8 XE-i Automatico	87000000	COP	44000	Automática	Blanco	f	\N	Híbrido	Toyota Corolla híbrido modelo Chery 2022, llantas al 99%, SOAT recién comprado, papeles al día, listo para traspaso inmediato, puede hacerse revisión en CDA sin ningún problema, pasa sin problema, mantenimientos con Toyota Motor y único dueño, perfecto estado del carro.
70	14	2026-11-12	08:02:50	descargado	1.8 XEi-L Automatico	89900000	COP	52050	Automática	Blanco	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
71	15	2026-11-12	08:02:56	descargado	1.8 CVT XEI	107900000	COP	72300	Automática	Blanco	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
72	16	2026-11-12	08:03:01	descargado	1.8 CVT SEG	111700000	COP	85000	Automática	Plateado	f	\N	Híbrido	Llantas y Soat comprados en septiembre 2026, excelente estado, unico dueño
73	18	2026-11-12	08:03:07	descargado	SE-G Automatico	110000000	COP	23000	Automática	Gris	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
74	19	2026-11-12	08:03:13	descargado	1.8 XL-i Automatico	101000000	COP	1000	Automática	Blanco	f	\N	Híbrido	2023 Toyota Corolla XLI 1.8 Hibrido. KILOMETRAJE es 14
75	20	2026-11-12	08:03:19	descargado	SE-G Automatico	100000000	COP	43000	Automática	Blanco	t	\N	Híbrido	🇨🇴🏁🇯🇵 Toyota Corolla SE-G Hybrid 2.023 ✅️ Listo para Traspaso. ✅ Único Dueño. ✅ 43.000 Km. ✅ Motor 1.8cc Híbrido. ️✅️ Automático. ️✅️ Full Equipo. ✅️ 7 Airbags. ✅️ Sunroof. ✅ Tapicería Cuero. ✅ Polarizado. ✅ Apple CarPlay/ Android Auto. ✅ Mantenimientos en Concesionario. ✅️ Matrícula Bogotá.
76	21	2026-11-12	08:03:25	descargado	1.8 Aut	114000000	COP	36000	Automática	Blanco	f	\N	Híbrido	Toyota Corolla Hibrido Seg Full equipo Modelo 2023 36.000 km Todo el mantenimiento certificado en concesionario
77	22	2026-11-12	08:03:30	descargado	1.8 XL-i Automatico	89900000	COP	22550	Automática	Blanco	f	\N	Híbrido	Híbrido full poco kilometraje, único conductor desde nuevo en trayectos urbanos, pintura con tratamiento porcelanizado, vidrios con película de seguridad, batería de 12v nueva para arranque, libro de mantenimientos original toyota con historial completo, solo en concesionario sus mantenimientos, excelente estado motor, exterior e interior, tapicería en tela, vidrios eléctricos, llave inteligente, ...
78	23	2026-11-12	08:03:36	descargado	SE-G Automatico	99990000	COP	45800	Automática	Gris	f	\N	Gasolina	N/A
79	24	2026-11-12	08:03:42	descargado	1.8 XL-i Automatico	108000000	COP	34083	Automática	Gris	t	\N	Híbrido	Único dueño, accesorios originales.
80	25	2026-11-12	08:03:48	descargado	SE-G Automatico	145000000	COP	30000	Automática	Gris	t	\N	Híbrido	El vendedor no incluyó una descripción del producto.
81	26	2026-11-12	08:03:54	descargado	1.8 XEi-L Automatico	99900000	COP	42000	Automática	Gris	f	\N	Híbrido	TOYOTA COROLLA XE-I HYBRID TP 1800CC 7AB ABS MOD 2023 🚙 Recorrido: 42.000km 🚙 Soat: 24/02/2026 🚙 Tecno: N/A 🚙 Placa: 1️⃣ 🚙 ABS 🚙 Airbags: 7 🚙 Mandos en el timón 🚙 Cámara de reversa 🚙 Sensores 🚙 Dirección: Eléctrica 🚙 Frenos: Disco/Disco 🚙 Faros: LED 🚙 Espejos eléctricos 2 🚙 Tracción: Delantera 🚙 Vidrios eléctricos: 4 🚙 Tapicería: Tela 🚙 Caja: Triptonica 🚙 Color: GRIS CELESTE ...
82	28	2026-11-12	08:04:00	descargado	1.8 CVT SEG	115000000	COP	20000	Automática	Plateado	t	\N	Híbrido	El vendedor no incluyó una descripción del producto.
83	29	2026-11-12	08:04:05	descargado	SE-G Automatico	118990000	COP	30000	Automática	Blanco	t	\N	Híbrido	Hermoso Toyota Corolla Sedan Blanco perlado Version mas equipada SEG. Cogineria en cuero, sunroof, todas las ayudas de conduccion, camara trasera y sensores de colision. Hibridacion Full (Consumo combustible promedio en ciudad 70 km/galon) Modelo 2023 con apenas 30.000 km Llantas nuevas (menos de 6 meses)
84	30	2026-11-12	08:04:11	descargado	GR-S 2.0 Deportivo Manual Gasolina	95900000	COP	37000	Automática	Rojo	f	\N	Gasolina	El vendedor no incluyó una descripción del producto.
85	31	2026-11-12	08:04:17	descargado	GR-S 2.0 Deportivo Manual Gasolina	90000000	COP	36000	Automática	Rojo	f	\N	Gasolina	excelente precio poco kilometraje, unico dueño, nunca chocado, seguro todo riesgo AXA, soat hasta agosto 2027, perfecto estado, mod 2023.
86	32	2026-11-12	08:04:22	descargado	SE-G Automatico	104900000	COP	39000	Automática	Rojo	f	\N	Híbrido	Toyota Corolla Híbrido 2023 SEG - Versión full equipo 39.900 km Mantenimientos en concesionario Sin reclamaciones Dos llaves Soat vigente Pasa peritaje Ubicado en ibague
87	34	2026-11-12	08:04:28	descargado	SE-G Automatico	112900000	COP	34000	Automática	Gris	f	\N	Híbrido	🚙 🚗Toyota Corolla SEG Modelo 2023 Híbrido 34.000km Automático Conineria de cuero #venta #Medellin #autos
88	36	2026-11-12	08:04:34	descargado	XEI 2.0 Sedan Automatico CVT	97000000	COP	59000	0	Gris	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
89	38	2026-11-12	08:04:40	descargado	1.8 XE-i Automatico	85000000	COP	56879	Automática	Gris	f	\N	Híbrido	Toyota Corolla XEI HIBRIDO 2023 56.879km 1.8cc Automatico Cojineria cuero Vidrios y espejos electricos Mandos en el timon Pantalla tactil Camara reversa Rines de lujo Llantas 70% Soat 24-junio-2027 Tecno 24-junio-2028
90	39	2026-11-12	08:04:46	descargado	1.8 XE-i Automatico	102000000	COP	53400	Automática	Otro	f	\N	Híbrido	¿Buscas confort, tecnología y ahorro? Vendo mi Toyota Corolla XEI Híbrido modelo 2023, una joya de la ingeniería japonesa. Con solo 53.400 km de recorrido. Motor 1.800cc- Automatico - sistema hibrido (Autorecargable) - 7 airbags - frenos ABS - silleteria de cuero - con asistencia y ayudas para la conducción - mandos en el timon - espejos electricos, vidrios electricos - color gris celeste - Pantal...
91	41	2026-11-12	08:04:52	descargado	1.8	115000000	COP	25700	Automática	Blanco	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
92	42	2026-11-12	08:04:57	descargado	1.8 CVT SEG	108000000	COP	63000	Automática	Plateado	f	\N	Híbrido	Toyota Corolla Seg Hibrido
93	43	2026-11-12	08:05:03	descargado	1.8 XE-i Automatico	113000000	COP	32000	Automática	Gris	f	\N	Híbrido	Toyota Corolla 2024 32.000 Km Perfecto estado 113.000.000 Negociables
94	44	2026-11-12	08:05:09	descargado	1.8 XE-i Automatico	123000000	COP	5000	Automática	Rojo	f	\N	Híbrido	Esperctacular bien cuidado con cojineria en cuero, UNICO DUEÑO full equipo HIBRIDO vendo directamente negociable
95	45	2026-11-12	08:05:15	descargado	1.8 CVT XEI	115000000	COP	29000	Automática	Plateado	f	\N	Híbrido	Pelicula de Seguridad en los vidrios Pernos de seguridad en las llantas
96	48	2026-11-12	08:05:20	descargado	\N	145500000	COP	10000	Automática	Gris	f	\N	Híbrido	Camioneta prácticamente nueva. Precio negociable. Es la versión básica aunque lo suficientemente equipada.
97	49	2026-11-12	08:05:26	descargado	1.8 XE-i Automatico	118000000	COP	4151	Automática	Lila	f	\N	Híbrido	Equipado con dirección electroasistida, aire acondicionado, cámara de reversa y sistema de audio con Bluetooth, este Corolla también incluye características de seguridad como airbags y frenos ABS. Su diseño y tecnología lo hacen adecuado para la ciudad y viajes cortos, pelicula de vidrios y turecas de seguridad en las llantas
98	50	2026-11-12	08:05:32	descargado	1.8 CVT SEG	116900000	COP	14000	Automática	Gris	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
99	51	2026-11-12	08:05:38	descargado	1.8 XEi-L Automatico	144000000	COP	15109	Automática	Gris	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
100	52	2026-11-12	08:05:43	descargado	SE-G Automatico	132900000	COP	29149	Automática	Blanco	f	\N	Gasolina	El vendedor no incluyó una descripción del producto.
101	54	2026-11-12	08:05:49	descargado	1.8 CVT SEG	141900000	COP	25543	Automática	Blanco	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
102	55	2026-11-12	08:05:55	descargado	1.8 CVT SEG	152000000	COP	10200	Automática	Plateado	f	\N	Híbrido	Perfecto estado
103	56	2026-11-12	08:06:01	descargado	1.8 CVT SEG	129900000	COP	9000	Automática	Blanco	f	\N	Híbrido	Vehículo en Excelente estado, documentos al día, impuestos al día. Vendo o permuto por vehículo o motocicleta de menor valor.
104	57	2026-11-12	08:06:07	descargado	1.8 CVT SEG	122000000	COP	26000	Automática	Blanco	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
105	58	2026-11-12	08:06:13	descargado	1.8 XL-i Automatico	105900000	COP	20000	Automática	Blanco	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
106	59	2026-11-12	08:06:19	descargado	1.8	134000000	COP	1600	Automática	Gris	f	\N	Híbrido	Carro casi nuevo Toyota Corolla 1.8 Hev Seg kilometraje 1.600 modelo 2026
107	3	2026-11-12	\N	no_encontrado	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
108	12	2026-11-12	\N	no_encontrado	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
109	13	2026-11-12	\N	no_encontrado	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
110	17	2026-11-12	\N	no_encontrado	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
111	27	2026-11-12	\N	no_encontrado	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
112	33	2026-11-12	\N	no_encontrado	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
113	35	2026-11-12	\N	no_encontrado	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
114	37	2026-11-12	\N	no_encontrado	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
115	40	2026-11-12	\N	no_encontrado	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
116	46	2026-11-12	\N	no_encontrado	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
117	47	2026-11-12	\N	no_encontrado	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
118	53	2026-11-12	\N	no_encontrado	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
119	1	2026-11-13	08:00:52	descargado	1.8 XE-i Automatico	84900000	COP	54984	Automática	Plateado	f	\N	Híbrido	🚗 ¡OPORTUNIDAD! Toyota Corolla Híbrido XEI 2022, en excelente estado, nunca siniestrado según historial. Elegante, cómodo y económico en combustible. Tecnología híbrida, ideal para ciudad y carretera. Placa terminada en 8. 💰 $84.900.000 negociables. ¡Un Toyota que combina confort, ahorro y confiabilidad! Agenda tu visita y conócelo.
120	2	2026-11-13	08:00:58	descargado	1.3 Mecanico	85000000	COP	35000	Mecánica	Gris	f	\N	Gasolina	Vehiculo en perfecto estado, A/C, direccionales habatibles, pernos de seguridad, seguro de direccionales, ventanas contrarobo, mantenimientos en cosecionario, único dueño, placa par.
121	3	2026-11-13	08:01:04	descargado	1.8 CVT SEG	94000000	COP	63000	Automática	Gris	t	\N	Híbrido	VEHICULO EN EXCELENTES CONDICIONES LISTO PARA TRASPASO VERSION FULL SEG 2022 63.000 SUN ROOF TAPICERIA EN CUERO APPLE CAR PLAY
122	4	2026-11-13	08:01:10	descargado	1.8 XE-i Automatico	98500000	COP	40000	Automática	Negro	f	\N	Híbrido	Toyota Corolla Hybrid Black Edition 2022, todos sus mantenimientos en ToyoNorte, al día de impuestos, perfecto estado, tapetes todo tiempo toyota, sin pico y placa, no enchufable, consumo muy bajo, silencioso y potente. Negociable. Soat y técnico hasta 2027. CarPlay, cámara trasera, sensores delanteros y traseros, Venta directa.
123	5	2026-11-13	08:01:16	descargado	\N	115000000	COP	20000	Automática	Blanco	t	\N	Híbrido	SEG Hybrid, full equipo, cuenta con siete airbags, película polarizada, cojinería en cuero, sunroof, no tiene pico y placa, se entrega con la revisión de los 20000 Km, venta directa, único dueño
124	6	2026-11-13	08:01:21	descargado	1.8 XE-i Hybrid Automatico	84990000	COP	84392	Automática	Blanco	f	\N	Híbrido	N/A
125	7	2026-11-13	08:01:28	descargado	1.8 XE-i Automatico	95000000	COP	31800	Automática	Gris	f	\N	Híbrido	Excelente estado como nuevo, sin pico y placa , mtto de 30.000 km recien hecho, unico dueño, todos los mantenimientos realizados en carco, libre de papeles, no tiene pignoraciones.
126	8	2026-11-13	08:01:33	descargado	1.8 CVT XEI	95000000	COP	29000	Secuencial	Blanco	f	\N	Híbrido	Único dueño, perfecto estado, mantenimientos al día
127	9	2026-11-13	08:01:39	descargado	1.8 XE-i Automatico	89000000	COP	82000	Automática	Blanco	f	\N	Híbrido	Toyota Corolla 2022, 100% hibrido 82,000 km. Último mantenimiento realizado el de 80.000 km, llantas nuevas y con todos los mantenimientos directamente con Toyota conforme al libro de la marca. Motor de 1.8 litros y 136 hp, transmisión automática, dirección electroasistida y tracción delantera Autonomía hasta 90Km por galón. Control de estabilidad, sensores de estacionamiento, cámara de revers...
128	10	2026-11-13	08:01:45	descargado	XEI 2.0 Sedan Manual	83990000	COP	27952	Mecánica	Rojo	f	\N	Gasolina	2 llaves manules
129	11	2026-11-13	08:01:51	descargado	1.8 XE-i Automatico	87000000	COP	44000	Automática	Blanco	f	\N	Híbrido	Toyota Corolla híbrido modelo Chery 2022, llantas al 99%, SOAT recién comprado, papeles al día, listo para traspaso inmediato, puede hacerse revisión en CDA sin ningún problema, pasa sin problema, mantenimientos con Toyota Motor y único dueño, perfecto estado del carro.
130	12	2026-11-13	08:01:57	descargado	1.8	119900000	COP	55000	Automática	Blanco	f	\N	Híbrido	Corolla Seg blindaje2 híbrido
131	13	2026-11-13	08:02:03	descargado	1.8 CVT SEG	91900000	COP	68000	Automática	Blanco	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
132	14	2026-11-13	08:02:08	descargado	1.8 XEi-L Automatico	89900000	COP	52050	Automática	Blanco	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
133	121	2026-11-13	08:02:14	descargado	1.8 XEi-L Automatico	89900000	COP	52050	Automática	Blanco	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
134	15	2026-11-13	08:02:20	descargado	1.8 CVT XEI	107900000	COP	72300	Automática	Blanco	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
135	16	2026-11-13	08:02:26	descargado	1.8 CVT SEG	111700000	COP	85000	Automática	Plateado	f	\N	Híbrido	Llantas y Soat comprados en septiembre 2026, excelente estado, unico dueño
136	17	2026-11-13	08:02:31	descargado	1.8 XL-i Automatico	99900000	COP	46000	Automática	Gris	f	\N	Híbrido	Toyota Corolla XLI Hybrid 2023 | Único dueño | 46.000 km | Equipado con accesorios originales de agencia. ⭐ *Equipamiento y extras* * Sistema híbrido 1.8L Toyota, automático E * Llantas y rines originales *de la versión SEG*, instalados de agencia * Polarizado premium. * Tapetes termoformado * Protectores *originales* de retrovisores. * Estribos *originales* de agencia * Interior y exterior en ex...
137	18	2026-11-13	08:02:37	descargado	SE-G Automatico	110000000	COP	23000	Automática	Gris	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
138	19	2026-11-13	08:02:43	descargado	1.8 XL-i Automatico	101000000	COP	1000	Automática	Blanco	f	\N	Híbrido	2023 Toyota Corolla XLI 1.8 Hibrido. KILOMETRAJE es 14
139	20	2026-11-13	08:03:07	descargado	SE-G Automatico	100000000	COP	43000	Automática	Blanco	t	\N	Híbrido	🇨🇴🏁🇯🇵 Toyota Corolla SE-G Hybrid 2.023 ✅️ Listo para Traspaso. ✅ Único Dueño. ✅ 43.000 Km. ✅ Motor 1.8cc Híbrido. ️✅️ Automático. ️✅️ Full Equipo. ✅️ 7 Airbags. ✅️ Sunroof. ✅ Tapicería Cuero. ✅ Polarizado. ✅ Apple CarPlay/ Android Auto. ✅ Mantenimientos en Concesionario. ✅️ Matrícula Bogotá.
140	21	2026-11-13	08:03:13	descargado	1.8 Aut	114000000	COP	36000	Automática	Blanco	f	\N	Híbrido	Toyota Corolla Hibrido Seg Full equipo Modelo 2023 36.000 km Todo el mantenimiento certificado en concesionario
141	22	2026-11-13	08:03:18	descargado	1.8 XL-i Automatico	89900000	COP	22550	Automática	Blanco	f	\N	Híbrido	Híbrido full poco kilometraje, único conductor desde nuevo en trayectos urbanos, pintura con tratamiento porcelanizado, vidrios con película de seguridad, batería de 12v nueva para arranque, libro de mantenimientos original toyota con historial completo, solo en concesionario sus mantenimientos, excelente estado motor, exterior e interior, tapicería en tela, vidrios eléctricos, llave inteligente, ...
142	23	2026-11-13	08:03:24	descargado	SE-G Automatico	99990000	COP	45800	Automática	Gris	f	\N	Gasolina	N/A
143	24	2026-11-13	08:03:30	descargado	1.8 XL-i Automatico	108000000	COP	34083	Automática	Gris	t	\N	Híbrido	Único dueño, accesorios originales.
144	25	2026-11-13	08:03:36	descargado	SE-G Automatico	145000000	COP	30000	Automática	Gris	t	\N	Híbrido	El vendedor no incluyó una descripción del producto.
145	26	2026-11-13	08:03:41	descargado	1.8 XEi-L Automatico	99900000	COP	42000	Automática	Gris	f	\N	Híbrido	TOYOTA COROLLA XE-I HYBRID TP 1800CC 7AB ABS MOD 2023 🚙 Recorrido: 42.000km 🚙 Soat: 24/02/2026 🚙 Tecno: N/A 🚙 Placa: 1️⃣ 🚙 ABS 🚙 Airbags: 7 🚙 Mandos en el timón 🚙 Cámara de reversa 🚙 Sensores 🚙 Dirección: Eléctrica 🚙 Frenos: Disco/Disco 🚙 Faros: LED 🚙 Espejos eléctricos 2 🚙 Tracción: Delantera 🚙 Vidrios eléctricos: 4 🚙 Tapicería: Tela 🚙 Caja: Triptonica 🚙 Color: GRIS CELESTE ...
146	27	2026-11-13	08:03:47	descargado	1.8 XE-i Automatico	102000000	COP	21000	Automática	Blanco	f	\N	Híbrido	Vehículo en excelente estado, peritaje donde desee, recibo vehículo de menor valor
147	28	2026-11-13	08:03:53	descargado	1.8 CVT SEG	115000000	COP	20000	Automática	Plateado	t	\N	Híbrido	El vendedor no incluyó una descripción del producto.
148	29	2026-11-13	08:03:59	descargado	SE-G Automatico	118990000	COP	30000	Automática	Blanco	t	\N	Híbrido	Hermoso Toyota Corolla Sedan Blanco perlado Version mas equipada SEG. Cogineria en cuero, sunroof, todas las ayudas de conduccion, camara trasera y sensores de colision. Hibridacion Full (Consumo combustible promedio en ciudad 70 km/galon) Modelo 2023 con apenas 30.000 km Llantas nuevas (menos de 6 meses)
149	30	2026-11-13	08:04:05	descargado	GR-S 2.0 Deportivo Manual Gasolina	95900000	COP	37000	Automática	Rojo	f	\N	Gasolina	El vendedor no incluyó una descripción del producto.
150	31	2026-11-13	08:04:10	descargado	GR-S 2.0 Deportivo Manual Gasolina	90000000	COP	36000	Automática	Rojo	f	\N	Gasolina	excelente precio poco kilometraje, unico dueño, nunca chocado, seguro todo riesgo AXA, soat hasta agosto 2027, perfecto estado, mod 2023.
151	32	2026-11-13	08:04:16	descargado	SE-G Automatico	104900000	COP	39000	Automática	Rojo	f	\N	Híbrido	Toyota Corolla Híbrido 2023 SEG - Versión full equipo 39.900 km Mantenimientos en concesionario Sin reclamaciones Dos llaves Soat vigente Pasa peritaje Ubicado en ibague
152	33	2026-11-13	08:04:22	descargado	1.8 CVT SEG	88900000	COP	56000	Automática	Gris	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
153	34	2026-11-13	08:04:28	descargado	SE-G Automatico	112900000	COP	34000	Automática	Gris	f	\N	Híbrido	🚙 🚗Toyota Corolla SEG Modelo 2023 Híbrido 34.000km Automático Conineria de cuero #venta #Medellin #autos
154	35	2026-11-13	08:04:33	descargado	1.8 XE-i Automatico	92900000	COP	53000	Automática	Gris	f	\N	Híbrido	Medellin
155	36	2026-11-13	08:04:39	descargado	XEI 2.0 Sedan Automatico CVT	97000000	COP	59000	0	Gris	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
156	37	2026-11-13	08:04:45	descargado	GR-S 2.0 Deportivo Manual Gasolina	127900000	COP	25400	Automática	Blanco	f	\N	Gasolina	Toyota Corolla Cross GR-S 2.0cc - Modelo: 2023 - Kilometraje: 25.400kms - Transmisión: Automática - Tracción: 4x2 - Combustible: Gasolina - Soat: 26/03/2027 - Tecno: 20/02/2028 - Placa Finaliza: 9
157	38	2026-11-13	08:04:52	descargado	1.8 XE-i Automatico	85000000	COP	56879	Automática	Gris	f	\N	Híbrido	Toyota Corolla XEI HIBRIDO 2023 56.879km 1.8cc Automatico Cojineria cuero Vidrios y espejos electricos Mandos en el timon Pantalla tactil Camara reversa Rines de lujo Llantas 70% Soat 24-junio-2027 Tecno 24-junio-2028
158	39	2026-11-13	08:04:59	descargado	1.8 XE-i Automatico	102000000	COP	53400	Automática	Otro	f	\N	Híbrido	¿Buscas confort, tecnología y ahorro? Vendo mi Toyota Corolla XEI Híbrido modelo 2023, una joya de la ingeniería japonesa. Con solo 53.400 km de recorrido. Motor 1.800cc- Automatico - sistema hibrido (Autorecargable) - 7 airbags - frenos ABS - silleteria de cuero - con asistencia y ayudas para la conducción - mandos en el timon - espejos electricos, vidrios electricos - color gris celeste - Pantal...
159	40	2026-11-13	08:05:05	descargado	1.8 CVT SEG	106900000	COP	48000	Automática	Gris	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
160	41	2026-11-13	08:05:10	descargado	1.8	115000000	COP	25700	Automática	Blanco	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
161	42	2026-11-13	08:05:16	descargado	1.8 CVT SEG	108000000	COP	63000	Automática	Plateado	f	\N	Híbrido	Toyota Corolla Seg Hibrido
162	43	2026-11-13	08:05:22	descargado	1.8 XE-i Automatico	113000000	COP	32000	Automática	Gris	f	\N	Híbrido	Toyota Corolla 2024 32.000 Km Perfecto estado 113.000.000 Negociables
163	44	2026-11-13	08:05:28	descargado	1.8 XE-i Automatico	123000000	COP	5000	Automática	Rojo	f	\N	Híbrido	Esperctacular bien cuidado con cojineria en cuero, UNICO DUEÑO full equipo HIBRIDO vendo directamente negociable
164	45	2026-11-13	08:05:34	descargado	1.8 CVT XEI	115000000	COP	29000	Automática	Plateado	f	\N	Híbrido	Pelicula de Seguridad en los vidrios Pernos de seguridad en las llantas
165	46	2026-11-13	08:05:43	descargado	1.8 CVT XEI	106900000	COP	30000	Automática	Blanco	f	\N	Híbrido	Único dueño. Medellín hibrido todo en cocesiy
166	47	2026-11-13	08:05:50	descargado	\N	95900000	COP	33000	Automática	Blanco	f	\N	Híbrido	Toyota Corolla XLI híbrido
167	48	2026-11-13	08:05:55	descargado	\N	145500000	COP	10000	Automática	Gris	f	\N	Híbrido	Camioneta prácticamente nueva. Precio negociable. Es la versión básica aunque lo suficientemente equipada.
168	49	2026-11-13	08:06:01	descargado	1.8 XE-i Automatico	118000000	COP	4151	Automática	Lila	f	\N	Híbrido	Equipado con dirección electroasistida, aire acondicionado, cámara de reversa y sistema de audio con Bluetooth, este Corolla también incluye características de seguridad como airbags y frenos ABS. Su diseño y tecnología lo hacen adecuado para la ciudad y viajes cortos, pelicula de vidrios y turecas de seguridad en las llantas
169	50	2026-11-13	08:06:07	descargado	1.8 CVT SEG	116900000	COP	14000	Automática	Gris	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
170	51	2026-11-13	08:06:13	descargado	1.8 XEi-L Automatico	144000000	COP	15109	Automática	Gris	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
171	52	2026-11-13	08:06:19	descargado	SE-G Automatico	132900000	COP	29149	Automática	Blanco	f	\N	Gasolina	El vendedor no incluyó una descripción del producto.
172	53	2026-11-13	08:06:25	descargado	1.8 CVT SEG	116900000	COP	14000	Automática	Gris	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
173	54	2026-11-13	08:06:31	descargado	1.8 CVT SEG	141900000	COP	25543	Automática	Blanco	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
174	55	2026-11-13	08:06:38	descargado	1.8 CVT SEG	152000000	COP	10200	Automática	Plateado	f	\N	Híbrido	Perfecto estado
175	56	2026-11-13	08:06:46	descargado	1.8 CVT SEG	129900000	COP	9000	Automática	Blanco	f	\N	Híbrido	Vehículo en Excelente estado, documentos al día, impuestos al día. Vendo o permuto por vehículo o motocicleta de menor valor.
176	57	2026-11-13	08:06:52	descargado	1.8 CVT SEG	122000000	COP	26000	Automática	Blanco	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
177	58	2026-11-13	08:06:57	descargado	1.8 XL-i Automatico	105900000	COP	20000	Automática	Blanco	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
178	59	2026-11-13	08:07:03	descargado	1.8	134000000	COP	1600	Automática	Gris	f	\N	Híbrido	Carro casi nuevo Toyota Corolla 1.8 Hev Seg kilometraje 1.600 modelo 2026
179	1	2026-11-14	08:00:51	descargado	1.8 XE-i Automatico	84900000	COP	54984	Automática	Plateado	f	\N	Híbrido	🚗 ¡OPORTUNIDAD! Toyota Corolla Híbrido XEI 2022, en excelente estado, nunca siniestrado según historial. Elegante, cómodo y económico en combustible. Tecnología híbrida, ideal para ciudad y carretera. Placa terminada en 8. 💰 $84.900.000 negociables. ¡Un Toyota que combina confort, ahorro y confiabilidad! Agenda tu visita y conócelo.
180	2	2026-11-14	08:00:57	descargado	1.3 Mecanico	85000000	COP	35000	Mecánica	Gris	f	\N	Gasolina	Vehiculo en perfecto estado, A/C, direccionales habatibles, pernos de seguridad, seguro de direccionales, ventanas contrarobo, mantenimientos en cosecionario, único dueño, placa par.
181	3	2026-11-14	08:01:03	descargado	1.8 CVT SEG	94000000	COP	63000	Automática	Gris	t	\N	Híbrido	VEHICULO EN EXCELENTES CONDICIONES LISTO PARA TRASPASO VERSION FULL SEG 2022 63.000 SUN ROOF TAPICERIA EN CUERO APPLE CAR PLAY
182	4	2026-11-14	08:01:09	descargado	1.8 XE-i Automatico	98500000	COP	40000	Automática	Negro	f	\N	Híbrido	Toyota Corolla Hybrid Black Edition 2022, todos sus mantenimientos en ToyoNorte, al día de impuestos, perfecto estado, tapetes todo tiempo toyota, sin pico y placa, no enchufable, consumo muy bajo, silencioso y potente. Negociable. Soat y técnico hasta 2027. CarPlay, cámara trasera, sensores delanteros y traseros, Venta directa.
183	5	2026-11-14	08:01:15	descargado	\N	115000000	COP	20000	Automática	Blanco	t	\N	Híbrido	SEG Hybrid, full equipo, cuenta con siete airbags, película polarizada, cojinería en cuero, sunroof, no tiene pico y placa, se entrega con la revisión de los 20000 Km, venta directa, único dueño
184	6	2026-11-14	08:01:21	descargado	1.8 XE-i Hybrid Automatico	84990000	COP	84392	Automática	Blanco	f	\N	Híbrido	N/A
185	7	2026-11-14	08:01:27	descargado	1.8 XE-i Automatico	95000000	COP	31800	Automática	Gris	f	\N	Híbrido	Excelente estado como nuevo, sin pico y placa , mtto de 30.000 km recien hecho, unico dueño, todos los mantenimientos realizados en carco, libre de papeles, no tiene pignoraciones.
186	8	2026-11-14	08:01:33	descargado	1.8 CVT XEI	95000000	COP	29000	Secuencial	Blanco	f	\N	Híbrido	Único dueño, perfecto estado, mantenimientos al día
187	9	2026-11-14	08:01:39	descargado	1.8 XE-i Automatico	89000000	COP	82000	Automática	Blanco	f	\N	Híbrido	Toyota Corolla 2022, 100% hibrido 82,000 km. Último mantenimiento realizado el de 80.000 km, llantas nuevas y con todos los mantenimientos directamente con Toyota conforme al libro de la marca. Motor de 1.8 litros y 136 hp, transmisión automática, dirección electroasistida y tracción delantera Autonomía hasta 90Km por galón. Control de estabilidad, sensores de estacionamiento, cámara de revers...
188	10	2026-11-14	08:01:44	descargado	XEI 2.0 Sedan Manual	83990000	COP	27952	Mecánica	Rojo	f	\N	Gasolina	2 llaves manules
278	38	2026-11-15	08:05:21	descargado	1.8 XE-i Automatico	85000000	COP	56879	Automática	Gris	f	\N	Híbrido	Toyota Corolla XEI HIBRIDO 2023 56.879km 1.8cc Automatico Cojineria cuero Vidrios y espejos electricos Mandos en el timon Pantalla tactil Camara reversa Rines de lujo Llantas 70% Soat 24-junio-2027 Tecno 24-junio-2028
189	11	2026-11-14	08:01:50	descargado	1.8 XE-i Automatico	87000000	COP	44000	Automática	Blanco	f	\N	Híbrido	Toyota Corolla híbrido modelo Chery 2022, llantas al 99%, SOAT recién comprado, papeles al día, listo para traspaso inmediato, puede hacerse revisión en CDA sin ningún problema, pasa sin problema, mantenimientos con Toyota Motor y único dueño, perfecto estado del carro.
190	12	2026-11-14	08:01:56	descargado	1.8	119900000	COP	55000	Automática	Blanco	f	\N	Híbrido	Corolla Seg blindaje2 híbrido
191	13	2026-11-14	08:02:02	descargado	1.8 CVT SEG	91900000	COP	68000	Automática	Blanco	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
192	14	2026-11-14	08:02:07	descargado	1.8 XEi-L Automatico	89900000	COP	52050	Automática	Blanco	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
193	121	2026-11-14	08:02:13	descargado	1.8 XEi-L Automatico	89900000	COP	52050	Automática	Blanco	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
194	15	2026-11-14	08:02:19	descargado	1.8 CVT XEI	107900000	COP	72300	Automática	Blanco	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
195	16	2026-11-14	08:02:24	descargado	1.8 CVT SEG	111700000	COP	85000	Automática	Plateado	f	\N	Híbrido	Llantas y Soat comprados en septiembre 2026, excelente estado, unico dueño
196	17	2026-11-14	08:02:30	descargado	1.8 XL-i Automatico	99900000	COP	46000	Automática	Gris	f	\N	Híbrido	Toyota Corolla XLI Hybrid 2023 | Único dueño | 46.000 km | Equipado con accesorios originales de agencia. ⭐ *Equipamiento y extras* * Sistema híbrido 1.8L Toyota, automático E * Llantas y rines originales *de la versión SEG*, instalados de agencia * Polarizado premium. * Tapetes termoformado * Protectores *originales* de retrovisores. * Estribos *originales* de agencia * Interior y exterior en ex...
197	18	2026-11-14	08:02:36	descargado	SE-G Automatico	110000000	COP	23000	Automática	Gris	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
198	19	2026-11-14	08:02:42	descargado	1.8 XL-i Automatico	101000000	COP	1000	Automática	Blanco	f	\N	Híbrido	2023 Toyota Corolla XLI 1.8 Hibrido. KILOMETRAJE es 14
199	20	2026-11-14	08:02:48	descargado	SE-G Automatico	100000000	COP	43000	Automática	Blanco	t	\N	Híbrido	🇨🇴🏁🇯🇵 Toyota Corolla SE-G Hybrid 2.023 ✅️ Listo para Traspaso. ✅ Único Dueño. ✅ 43.000 Km. ✅ Motor 1.8cc Híbrido. ️✅️ Automático. ️✅️ Full Equipo. ✅️ 7 Airbags. ✅️ Sunroof. ✅ Tapicería Cuero. ✅ Polarizado. ✅ Apple CarPlay/ Android Auto. ✅ Mantenimientos en Concesionario. ✅️ Matrícula Bogotá.
200	21	2026-11-14	08:02:54	descargado	1.8 Aut	114000000	COP	36000	Automática	Blanco	f	\N	Híbrido	Toyota Corolla Hibrido Seg Full equipo Modelo 2023 36.000 km Todo el mantenimiento certificado en concesionario
201	22	2026-11-14	08:02:59	descargado	1.8 XL-i Automatico	89900000	COP	22550	Automática	Blanco	f	\N	Híbrido	Híbrido full poco kilometraje, único conductor desde nuevo en trayectos urbanos, pintura con tratamiento porcelanizado, vidrios con película de seguridad, batería de 12v nueva para arranque, libro de mantenimientos original toyota con historial completo, solo en concesionario sus mantenimientos, excelente estado motor, exterior e interior, tapicería en tela, vidrios eléctricos, llave inteligente, ...
202	23	2026-11-14	08:03:05	descargado	SE-G Automatico	99990000	COP	45800	Automática	Gris	f	\N	Gasolina	N/A
203	24	2026-11-14	08:03:11	descargado	1.8 XL-i Automatico	108000000	COP	34083	Automática	Gris	t	\N	Híbrido	Único dueño, accesorios originales.
204	25	2026-11-14	08:03:17	descargado	SE-G Automatico	145000000	COP	30000	Automática	Gris	t	\N	Híbrido	El vendedor no incluyó una descripción del producto.
205	26	2026-11-14	08:03:23	descargado	1.8 XEi-L Automatico	99900000	COP	42000	Automática	Gris	f	\N	Híbrido	TOYOTA COROLLA XE-I HYBRID TP 1800CC 7AB ABS MOD 2023 🚙 Recorrido: 42.000km 🚙 Soat: 24/02/2026 🚙 Tecno: N/A 🚙 Placa: 1️⃣ 🚙 ABS 🚙 Airbags: 7 🚙 Mandos en el timón 🚙 Cámara de reversa 🚙 Sensores 🚙 Dirección: Eléctrica 🚙 Frenos: Disco/Disco 🚙 Faros: LED 🚙 Espejos eléctricos 2 🚙 Tracción: Delantera 🚙 Vidrios eléctricos: 4 🚙 Tapicería: Tela 🚙 Caja: Triptonica 🚙 Color: GRIS CELESTE ...
206	27	2026-11-14	08:03:46	descargado	1.8 XE-i Automatico	102000000	COP	21000	Automática	Blanco	f	\N	Híbrido	Vehículo en excelente estado, peritaje donde desee, recibo vehículo de menor valor
207	28	2026-11-14	08:03:52	descargado	1.8 CVT SEG	115000000	COP	20000	Automática	Plateado	t	\N	Híbrido	El vendedor no incluyó una descripción del producto.
208	29	2026-11-14	08:03:58	descargado	SE-G Automatico	118990000	COP	30000	Automática	Blanco	t	\N	Híbrido	Hermoso Toyota Corolla Sedan Blanco perlado Version mas equipada SEG. Cogineria en cuero, sunroof, todas las ayudas de conduccion, camara trasera y sensores de colision. Hibridacion Full (Consumo combustible promedio en ciudad 70 km/galon) Modelo 2023 con apenas 30.000 km Llantas nuevas (menos de 6 meses)
209	30	2026-11-14	08:04:04	descargado	GR-S 2.0 Deportivo Manual Gasolina	95900000	COP	37000	Automática	Rojo	f	\N	Gasolina	El vendedor no incluyó una descripción del producto.
210	31	2026-11-14	08:04:10	descargado	GR-S 2.0 Deportivo Manual Gasolina	90000000	COP	36000	Automática	Rojo	f	\N	Gasolina	excelente precio poco kilometraje, unico dueño, nunca chocado, seguro todo riesgo AXA, soat hasta agosto 2027, perfecto estado, mod 2023.
211	32	2026-11-14	08:04:16	descargado	SE-G Automatico	104900000	COP	39000	Automática	Rojo	f	\N	Híbrido	Toyota Corolla Híbrido 2023 SEG - Versión full equipo 39.900 km Mantenimientos en concesionario Sin reclamaciones Dos llaves Soat vigente Pasa peritaje Ubicado en ibague
212	33	2026-11-14	08:04:22	descargado	1.8 CVT SEG	88900000	COP	56000	Automática	Gris	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
213	34	2026-11-14	08:04:27	descargado	SE-G Automatico	112900000	COP	34000	Automática	Gris	f	\N	Híbrido	🚙 🚗Toyota Corolla SEG Modelo 2023 Híbrido 34.000km Automático Conineria de cuero #venta #Medellin #autos
214	35	2026-11-14	08:04:34	descargado	1.8 XE-i Automatico	92900000	COP	53000	Automática	Gris	f	\N	Híbrido	Medellin
215	36	2026-11-14	08:04:40	descargado	XEI 2.0 Sedan Automatico CVT	97000000	COP	59000	0	Gris	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
216	37	2026-11-14	08:04:46	descargado	GR-S 2.0 Deportivo Manual Gasolina	127900000	COP	25400	Automática	Blanco	f	\N	Gasolina	Toyota Corolla Cross GR-S 2.0cc - Modelo: 2023 - Kilometraje: 25.400kms - Transmisión: Automática - Tracción: 4x2 - Combustible: Gasolina - Soat: 26/03/2027 - Tecno: 20/02/2028 - Placa Finaliza: 9
217	38	2026-11-14	08:04:52	descargado	1.8 XE-i Automatico	85000000	COP	56879	Automática	Gris	f	\N	Híbrido	Toyota Corolla XEI HIBRIDO 2023 56.879km 1.8cc Automatico Cojineria cuero Vidrios y espejos electricos Mandos en el timon Pantalla tactil Camara reversa Rines de lujo Llantas 70% Soat 24-junio-2027 Tecno 24-junio-2028
218	39	2026-11-14	08:04:58	descargado	1.8 XE-i Automatico	102000000	COP	53400	Automática	Otro	f	\N	Híbrido	¿Buscas confort, tecnología y ahorro? Vendo mi Toyota Corolla XEI Híbrido modelo 2023, una joya de la ingeniería japonesa. Con solo 53.400 km de recorrido. Motor 1.800cc- Automatico - sistema hibrido (Autorecargable) - 7 airbags - frenos ABS - silleteria de cuero - con asistencia y ayudas para la conducción - mandos en el timon - espejos electricos, vidrios electricos - color gris celeste - Pantal...
219	40	2026-11-14	08:05:04	descargado	1.8 CVT SEG	106900000	COP	48000	Automática	Gris	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
220	41	2026-11-14	08:05:09	descargado	1.8	115000000	COP	25700	Automática	Blanco	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
221	42	2026-11-14	08:05:15	descargado	1.8 CVT SEG	108000000	COP	63000	Automática	Plateado	f	\N	Híbrido	Toyota Corolla Seg Hibrido
222	43	2026-11-14	08:05:21	descargado	1.8 XE-i Automatico	113000000	COP	32000	Automática	Gris	f	\N	Híbrido	Toyota Corolla 2024 32.000 Km Perfecto estado 113.000.000 Negociables
223	44	2026-11-14	08:05:26	descargado	1.8 XE-i Automatico	123000000	COP	5000	Automática	Rojo	f	\N	Híbrido	Esperctacular bien cuidado con cojineria en cuero, UNICO DUEÑO full equipo HIBRIDO vendo directamente negociable
224	45	2026-11-14	08:05:32	descargado	1.8 CVT XEI	115000000	COP	29000	Automática	Plateado	f	\N	Híbrido	Pelicula de Seguridad en los vidrios Pernos de seguridad en las llantas
225	46	2026-11-14	08:05:38	descargado	1.8 CVT XEI	106900000	COP	30000	Automática	Blanco	f	\N	Híbrido	Único dueño. Medellín hibrido todo en cocesiy
226	47	2026-11-14	08:05:44	descargado	\N	95900000	COP	33000	Automática	Blanco	f	\N	Híbrido	Toyota Corolla XLI híbrido
227	48	2026-11-14	08:05:49	descargado	\N	145500000	COP	10000	Automática	Gris	f	\N	Híbrido	Camioneta prácticamente nueva. Precio negociable. Es la versión básica aunque lo suficientemente equipada.
228	49	2026-11-14	08:05:55	descargado	1.8 XE-i Automatico	118000000	COP	4151	Automática	Lila	f	\N	Híbrido	Equipado con dirección electroasistida, aire acondicionado, cámara de reversa y sistema de audio con Bluetooth, este Corolla también incluye características de seguridad como airbags y frenos ABS. Su diseño y tecnología lo hacen adecuado para la ciudad y viajes cortos, pelicula de vidrios y turecas de seguridad en las llantas
229	50	2026-11-14	08:06:01	descargado	1.8 CVT SEG	116900000	COP	14000	Automática	Gris	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
230	51	2026-11-14	08:06:07	descargado	1.8 XEi-L Automatico	144000000	COP	15109	Automática	Gris	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
231	52	2026-11-14	08:06:12	descargado	SE-G Automatico	132900000	COP	29149	Automática	Blanco	f	\N	Gasolina	El vendedor no incluyó una descripción del producto.
232	53	2026-11-14	08:06:18	descargado	1.8 CVT SEG	116900000	COP	14000	Automática	Gris	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
233	54	2026-11-14	08:06:24	descargado	1.8 CVT SEG	141900000	COP	25543	Automática	Blanco	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
234	55	2026-11-14	08:06:30	descargado	1.8 CVT SEG	152000000	COP	10200	Automática	Plateado	f	\N	Híbrido	Perfecto estado
235	56	2026-11-14	08:06:36	descargado	1.8 CVT SEG	129900000	COP	9000	Automática	Blanco	f	\N	Híbrido	Vehículo en Excelente estado, documentos al día, impuestos al día. Vendo o permuto por vehículo o motocicleta de menor valor.
236	57	2026-11-14	08:06:42	descargado	1.8 CVT SEG	122000000	COP	26000	Automática	Blanco	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
237	58	2026-11-14	08:06:47	descargado	1.8 XL-i Automatico	105900000	COP	20000	Automática	Blanco	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
238	59	2026-11-14	08:06:53	descargado	1.8	134000000	COP	1600	Automática	Gris	f	\N	Híbrido	Carro casi nuevo Toyota Corolla 1.8 Hev Seg kilometraje 1.600 modelo 2026
239	1	2026-11-15	08:01:29	descargado	1.8 XE-i Automatico	84900000	COP	54984	Automática	Plateado	f	\N	Híbrido	🚗 ¡OPORTUNIDAD! Toyota Corolla Híbrido XEI 2022, en excelente estado, nunca siniestrado según historial. Elegante, cómodo y económico en combustible. Tecnología híbrida, ideal para ciudad y carretera. Placa terminada en 8. 💰 $84.900.000 negociables. ¡Un Toyota que combina confort, ahorro y confiabilidad! Agenda tu visita y conócelo.
240	2	2026-11-15	08:01:36	descargado	1.3 Mecanico	85000000	COP	35000	Mecánica	Gris	f	\N	Gasolina	Vehiculo en perfecto estado, A/C, direccionales habatibles, pernos de seguridad, seguro de direccionales, ventanas contrarobo, mantenimientos en cosecionario, único dueño, placa par.
241	3	2026-11-15	08:01:42	descargado	1.8 CVT SEG	94000000	COP	63000	Automática	Gris	t	\N	Híbrido	VEHICULO EN EXCELENTES CONDICIONES LISTO PARA TRASPASO VERSION FULL SEG 2022 63.000 SUN ROOF TAPICERIA EN CUERO APPLE CAR PLAY
242	4	2026-11-15	08:01:48	descargado	1.8 XE-i Automatico	98500000	COP	40000	Automática	Negro	f	\N	Híbrido	Toyota Corolla Hybrid Black Edition 2022, todos sus mantenimientos en ToyoNorte, al día de impuestos, perfecto estado, tapetes todo tiempo toyota, sin pico y placa, no enchufable, consumo muy bajo, silencioso y potente. Negociable. Soat y técnico hasta 2027. CarPlay, cámara trasera, sensores delanteros y traseros, Venta directa.
243	5	2026-11-15	08:01:54	descargado	\N	115000000	COP	20000	Automática	Blanco	t	\N	Híbrido	SEG Hybrid, full equipo, cuenta con siete airbags, película polarizada, cojinería en cuero, sunroof, no tiene pico y placa, se entrega con la revisión de los 20000 Km, venta directa, único dueño
244	6	2026-11-15	08:01:59	descargado	1.8 XE-i Hybrid Automatico	84990000	COP	84392	Automática	Blanco	f	\N	Híbrido	N/A
245	7	2026-11-15	08:02:05	descargado	1.8 XE-i Automatico	95000000	COP	31800	Automática	Gris	f	\N	Híbrido	Excelente estado como nuevo, sin pico y placa , mtto de 30.000 km recien hecho, unico dueño, todos los mantenimientos realizados en carco, libre de papeles, no tiene pignoraciones.
246	8	2026-11-15	08:02:11	descargado	1.8 CVT XEI	95000000	COP	29000	Secuencial	Blanco	f	\N	Híbrido	Único dueño, perfecto estado, mantenimientos al día
247	9	2026-11-15	08:02:17	descargado	1.8 XE-i Automatico	89000000	COP	82000	Automática	Blanco	f	\N	Híbrido	Toyota Corolla 2022, 100% hibrido 82,000 km. Último mantenimiento realizado el de 80.000 km, llantas nuevas y con todos los mantenimientos directamente con Toyota conforme al libro de la marca. Motor de 1.8 litros y 136 hp, transmisión automática, dirección electroasistida y tracción delantera Autonomía hasta 90Km por galón. Control de estabilidad, sensores de estacionamiento, cámara de revers...
248	10	2026-11-15	08:02:23	descargado	XEI 2.0 Sedan Manual	83990000	COP	27952	Mecánica	Rojo	f	\N	Gasolina	2 llaves manules
249	11	2026-11-15	08:02:29	descargado	1.8 XE-i Automatico	87000000	COP	44000	Automática	Blanco	f	\N	Híbrido	Toyota Corolla híbrido modelo Chery 2022, llantas al 99%, SOAT recién comprado, papeles al día, listo para traspaso inmediato, puede hacerse revisión en CDA sin ningún problema, pasa sin problema, mantenimientos con Toyota Motor y único dueño, perfecto estado del carro.
250	12	2026-11-15	08:02:35	descargado	1.8	119900000	COP	55000	Automática	Blanco	f	\N	Híbrido	Corolla Seg blindaje2 híbrido
251	13	2026-11-15	08:02:41	descargado	1.8 CVT SEG	91900000	COP	68000	Automática	Blanco	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
252	14	2026-11-15	08:02:47	descargado	1.8 XEi-L Automatico	89900000	COP	52050	Automática	Blanco	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
253	121	2026-11-15	08:02:52	descargado	1.8 XEi-L Automatico	89900000	COP	52050	Automática	Blanco	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
254	15	2026-11-15	08:02:58	descargado	1.8 CVT XEI	107900000	COP	72300	Automática	Blanco	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
255	16	2026-11-15	08:03:04	descargado	1.8 CVT SEG	111700000	COP	85000	Automática	Plateado	f	\N	Híbrido	Llantas y Soat comprados en septiembre 2026, excelente estado, unico dueño
256	17	2026-11-15	08:03:10	descargado	1.8 XL-i Automatico	99900000	COP	46000	Automática	Gris	f	\N	Híbrido	Toyota Corolla XLI Hybrid 2023 | Único dueño | 46.000 km | Equipado con accesorios originales de agencia. ⭐ *Equipamiento y extras* * Sistema híbrido 1.8L Toyota, automático E * Llantas y rines originales *de la versión SEG*, instalados de agencia * Polarizado premium. * Tapetes termoformado * Protectores *originales* de retrovisores. * Estribos *originales* de agencia * Interior y exterior en ex...
257	18	2026-11-15	08:03:15	descargado	SE-G Automatico	110000000	COP	23000	Automática	Gris	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
258	19	2026-11-15	08:03:22	descargado	1.8 XL-i Automatico	101000000	COP	1000	Automática	Blanco	f	\N	Híbrido	2023 Toyota Corolla XLI 1.8 Hibrido. KILOMETRAJE es 14
259	20	2026-11-15	08:03:28	descargado	SE-G Automatico	100000000	COP	43000	Automática	Blanco	t	\N	Híbrido	🇨🇴🏁🇯🇵 Toyota Corolla SE-G Hybrid 2.023 ✅️ Listo para Traspaso. ✅ Único Dueño. ✅ 43.000 Km. ✅ Motor 1.8cc Híbrido. ️✅️ Automático. ️✅️ Full Equipo. ✅️ 7 Airbags. ✅️ Sunroof. ✅ Tapicería Cuero. ✅ Polarizado. ✅ Apple CarPlay/ Android Auto. ✅ Mantenimientos en Concesionario. ✅️ Matrícula Bogotá.
260	21	2026-11-15	08:03:34	descargado	1.8 Aut	114000000	COP	36000	Automática	Blanco	f	\N	Híbrido	Toyota Corolla Hibrido Seg Full equipo Modelo 2023 36.000 km Todo el mantenimiento certificado en concesionario
261	22	2026-11-15	08:03:40	descargado	1.8 XL-i Automatico	89900000	COP	22550	Automática	Blanco	f	\N	Híbrido	Híbrido full poco kilometraje, único conductor desde nuevo en trayectos urbanos, pintura con tratamiento porcelanizado, vidrios con película de seguridad, batería de 12v nueva para arranque, libro de mantenimientos original toyota con historial completo, solo en concesionario sus mantenimientos, excelente estado motor, exterior e interior, tapicería en tela, vidrios eléctricos, llave inteligente, ...
262	23	2026-11-15	08:03:46	descargado	SE-G Automatico	99990000	COP	45800	Automática	Gris	f	\N	Gasolina	N/A
263	24	2026-11-15	08:03:51	descargado	1.8 XL-i Automatico	108000000	COP	34083	Automática	Gris	t	\N	Híbrido	Único dueño, accesorios originales.
264	25	2026-11-15	08:03:57	descargado	SE-G Automatico	145000000	COP	30000	Automática	Gris	t	\N	Híbrido	El vendedor no incluyó una descripción del producto.
265	253	2026-11-15	08:04:03	descargado	1.8 XL-i Automatico	89990000	COP	21940	Automática	Blanco	f	\N	Híbrido	A continuación encuentras muchos más detalles de nuestro WCAR: -Dueños 1 -Llaves 1 -Pasajeros 5 -Placa 3 Mosquera -Modelo 2023 -Recorrido 21,940 Km -Soat 31/03/2027 -Transmisión A/T -airbag -Rines de lujo -Luces Exploradoras -vidrios eléctricos -Espejos eléctricos -tipo de radio Original -Comandos en el timón -Cámara de reversa -sensor de reversa -Sensor de luz -Aire acondicionado -tipo de dire...
266	26	2026-11-15	08:04:09	descargado	1.8 XEi-L Automatico	99900000	COP	42000	Automática	Gris	f	\N	Híbrido	TOYOTA COROLLA XE-I HYBRID TP 1800CC 7AB ABS MOD 2023 🚙 Recorrido: 42.000km 🚙 Soat: 24/02/2026 🚙 Tecno: N/A 🚙 Placa: 1️⃣ 🚙 ABS 🚙 Airbags: 7 🚙 Mandos en el timón 🚙 Cámara de reversa 🚙 Sensores 🚙 Dirección: Eléctrica 🚙 Frenos: Disco/Disco 🚙 Faros: LED 🚙 Espejos eléctricos 2 🚙 Tracción: Delantera 🚙 Vidrios eléctricos: 4 🚙 Tapicería: Tela 🚙 Caja: Triptonica 🚙 Color: GRIS CELESTE ...
267	27	2026-11-15	08:04:15	descargado	1.8 XE-i Automatico	102000000	COP	21000	Automática	Blanco	f	\N	Híbrido	Vehículo en excelente estado, peritaje donde desee, recibo vehículo de menor valor
268	28	2026-11-15	08:04:23	descargado	1.8 CVT SEG	115000000	COP	20000	Automática	Plateado	t	\N	Híbrido	El vendedor no incluyó una descripción del producto.
269	29	2026-11-15	08:04:28	descargado	SE-G Automatico	118990000	COP	30000	Automática	Blanco	t	\N	Híbrido	Hermoso Toyota Corolla Sedan Blanco perlado Version mas equipada SEG. Cogineria en cuero, sunroof, todas las ayudas de conduccion, camara trasera y sensores de colision. Hibridacion Full (Consumo combustible promedio en ciudad 70 km/galon) Modelo 2023 con apenas 30.000 km Llantas nuevas (menos de 6 meses)
270	30	2026-11-15	08:04:34	descargado	GR-S 2.0 Deportivo Manual Gasolina	95900000	COP	37000	Automática	Rojo	f	\N	Gasolina	El vendedor no incluyó una descripción del producto.
271	31	2026-11-15	08:04:40	descargado	GR-S 2.0 Deportivo Manual Gasolina	90000000	COP	36000	Automática	Rojo	f	\N	Gasolina	excelente precio poco kilometraje, unico dueño, nunca chocado, seguro todo riesgo AXA, soat hasta agosto 2027, perfecto estado, mod 2023.
272	32	2026-11-15	08:04:46	descargado	SE-G Automatico	104900000	COP	39000	Automática	Rojo	f	\N	Híbrido	Toyota Corolla Híbrido 2023 SEG - Versión full equipo 39.900 km Mantenimientos en concesionario Sin reclamaciones Dos llaves Soat vigente Pasa peritaje Ubicado en ibague
273	33	2026-11-15	08:04:51	descargado	1.8 CVT SEG	88900000	COP	56000	Automática	Gris	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
274	34	2026-11-15	08:04:57	descargado	SE-G Automatico	112900000	COP	34000	Automática	Gris	f	\N	Híbrido	🚙 🚗Toyota Corolla SEG Modelo 2023 Híbrido 34.000km Automático Conineria de cuero #venta #Medellin #autos
275	35	2026-11-15	08:05:03	descargado	1.8 XE-i Automatico	92900000	COP	53000	Automática	Gris	f	\N	Híbrido	Medellin
276	36	2026-11-15	08:05:08	descargado	XEI 2.0 Sedan Automatico CVT	97000000	COP	59000	0	Gris	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
277	37	2026-11-15	08:05:15	descargado	GR-S 2.0 Deportivo Manual Gasolina	127900000	COP	25400	Automática	Blanco	f	\N	Gasolina	Toyota Corolla Cross GR-S 2.0cc - Modelo: 2023 - Kilometraje: 25.400kms - Transmisión: Automática - Tracción: 4x2 - Combustible: Gasolina - Soat: 26/03/2027 - Tecno: 20/02/2028 - Placa Finaliza: 9
279	39	2026-11-15	08:05:26	descargado	1.8 XE-i Automatico	102000000	COP	53400	Automática	Otro	f	\N	Híbrido	¿Buscas confort, tecnología y ahorro? Vendo mi Toyota Corolla XEI Híbrido modelo 2023, una joya de la ingeniería japonesa. Con solo 53.400 km de recorrido. Motor 1.800cc- Automatico - sistema hibrido (Autorecargable) - 7 airbags - frenos ABS - silleteria de cuero - con asistencia y ayudas para la conducción - mandos en el timon - espejos electricos, vidrios electricos - color gris celeste - Pantal...
280	40	2026-11-15	08:05:32	descargado	1.8 CVT SEG	106900000	COP	48000	Automática	Gris	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
281	41	2026-11-15	08:05:38	descargado	1.8	115000000	COP	25700	Automática	Blanco	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
282	42	2026-11-15	08:05:43	descargado	1.8 CVT SEG	108000000	COP	63000	Automática	Plateado	f	\N	Híbrido	Toyota Corolla Seg Hibrido
283	43	2026-11-15	08:05:49	descargado	1.8 XE-i Automatico	113000000	COP	32000	Automática	Gris	f	\N	Híbrido	Toyota Corolla 2024 32.000 Km Perfecto estado 113.000.000 Negociables
284	44	2026-11-15	08:05:56	descargado	1.8 XE-i Automatico	123000000	COP	5000	Automática	Rojo	f	\N	Híbrido	Esperctacular bien cuidado con cojineria en cuero, UNICO DUEÑO full equipo HIBRIDO vendo directamente negociable
285	45	2026-11-15	08:06:02	descargado	1.8 CVT XEI	115000000	COP	29000	Automática	Plateado	f	\N	Híbrido	Pelicula de Seguridad en los vidrios Pernos de seguridad en las llantas
286	46	2026-11-15	08:06:07	descargado	1.8 CVT XEI	106900000	COP	30000	Automática	Blanco	f	\N	Híbrido	Único dueño. Medellín hibrido todo en cocesiy
287	47	2026-11-15	08:06:13	descargado	\N	95900000	COP	33000	Automática	Blanco	f	\N	Híbrido	Toyota Corolla XLI híbrido
288	48	2026-11-15	08:06:19	descargado	\N	145500000	COP	10000	Automática	Gris	f	\N	Híbrido	Camioneta prácticamente nueva. Precio negociable. Es la versión básica aunque lo suficientemente equipada.
289	49	2026-11-15	08:06:25	descargado	1.8 XE-i Automatico	118000000	COP	4151	Automática	Lila	f	\N	Híbrido	Equipado con dirección electroasistida, aire acondicionado, cámara de reversa y sistema de audio con Bluetooth, este Corolla también incluye características de seguridad como airbags y frenos ABS. Su diseño y tecnología lo hacen adecuado para la ciudad y viajes cortos, pelicula de vidrios y turecas de seguridad en las llantas
290	50	2026-11-15	08:06:31	descargado	1.8 CVT SEG	116900000	COP	14000	Automática	Gris	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
291	51	2026-11-15	08:06:37	descargado	1.8 XEi-L Automatico	144000000	COP	15109	Automática	Gris	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
292	52	2026-11-15	08:06:43	descargado	SE-G Automatico	132900000	COP	29149	Automática	Blanco	f	\N	Gasolina	El vendedor no incluyó una descripción del producto.
293	53	2026-11-15	08:06:49	descargado	1.8 CVT SEG	116900000	COP	14000	Automática	Gris	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
294	54	2026-11-15	08:06:54	descargado	1.8 CVT SEG	141900000	COP	25543	Automática	Blanco	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
295	55	2026-11-15	08:07:01	descargado	1.8 CVT SEG	152000000	COP	10200	Automática	Plateado	f	\N	Híbrido	Perfecto estado
296	56	2026-11-15	08:07:07	descargado	1.8 CVT SEG	129900000	COP	9000	Automática	Blanco	f	\N	Híbrido	Vehículo en Excelente estado, documentos al día, impuestos al día. Vendo o permuto por vehículo o motocicleta de menor valor.
297	57	2026-11-15	08:07:13	descargado	1.8 CVT SEG	122000000	COP	26000	Automática	Blanco	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
298	58	2026-11-15	08:07:19	descargado	1.8 XL-i Automatico	105900000	COP	20000	Automática	Blanco	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
299	59	2026-11-15	08:07:25	descargado	1.8	134000000	COP	1600	Automática	Gris	f	\N	Híbrido	Carro casi nuevo Toyota Corolla 1.8 Hev Seg kilometraje 1.600 modelo 2026
\.


--
-- Data for Name: vendedor; Type: TABLE DATA; Schema: public; Owner: carroya_user
--

COPY public.vendedor (id, nombre, departamento) FROM stdin;
1	Teresita Palacio Jimenez	BOGOTA
2	ALVARO OQUENDO ARANA	BOGOTA
3	Laura Natalia Pinzón López	BOGOTA
4	FANOR DAVID	BOGOTA
5	Wilson Hernandez Muñoz	BOGOTA
6	ESCALAUTOS	ESCALAUTOS
7	Diego Martinez	BOGOTA
8	JUAN CARLOS GONZALEZ MEDINA	BOGOTA
9	DAVID MAURICIO Moreno	BOGOTA
10	INVERSIONES METROMOVIL BEV SAS	INVERSIONES METROMOVIL BEV SAS
11	Martin undefined	ANTIOQUIA
12	Leonel David Perez legarda	ANTIOQUIA
16	heriberto vargas	META
17	Andrea Acevedo	ANTIOQUIA
18	Jose Fernando Rodriguez Hernandez	BOGOTA
19	Serkan Ozkan	Bogotá D.C.
20	Andres Roa	BOGOTA
21	Jaime Enrique Monroy	BOGOTA
22	Marcela Acosta	BOGOTA
24	DIEGO PAUCAR	BOGOTA
25	Fernando Torres	BOGOTA
26	Daniela Lopez	BOGOTA
27	Chuss cars	BOGOTA
28	juan carlos granados egea	SANTANDER
29	Luis Guillermo Sinisterra Zafra	VALLE DEL CAUCA
30	Leonel David Perez legarda	NORTE DE SANTANDER
31	Elias Elias	NORTE DE SANTANDER
32	SebasG SebasG	TOLIMA
34	Camilo José Mora Taborda	ANTIOQUIA
35	carlos mario bernal	ANTIOQUIA
36	Casa Fernandez	ANTIOQUIA
37	RCautos medellin	ANTIOQUIA
38	brayan marin	ANTIOQUIA
39	John Osorio	ANTIOQUIA
41	Jose Luis Ocaña Paz	NARINO
42	Edgar Laguna	META
43	Matias Buitrago	BOGOTA
44	CLAUDIO MORENO	BOGOTA
45	Alvaro Ramirez Suarez	BOGOTA
48	Andres Mancera Rojas	BOGOTA
49	Cristina Gonzalez	BOGOTA
55	Felipe M Jaramillo Jacome	BOGOTA
56	Autos Tobias	BOGOTA
57	Gerardo Duque Aristizabal	CALDAS
59	Durley alejandra Calle cardona	ANTIOQUIA
253	WCAR	WCAR
\.


--
-- Name: anuncio_id_seq; Type: SEQUENCE SET; Schema: public; Owner: carroya_user
--

SELECT pg_catalog.setval('public.anuncio_id_seq', 287, true);


--
-- Name: cambio_id_seq; Type: SEQUENCE SET; Schema: public; Owner: carroya_user
--

SELECT pg_catalog.setval('public.cambio_id_seq', 678, true);


--
-- Name: log_ejecucion_id_seq; Type: SEQUENCE SET; Schema: public; Owner: carroya_user
--

SELECT pg_catalog.setval('public.log_ejecucion_id_seq', 20, true);


--
-- Name: observacion_id_seq; Type: SEQUENCE SET; Schema: public; Owner: carroya_user
--

SELECT pg_catalog.setval('public.observacion_id_seq', 299, true);


--
-- Name: vendedor_id_seq; Type: SEQUENCE SET; Schema: public; Owner: carroya_user
--

SELECT pg_catalog.setval('public.vendedor_id_seq', 287, true);


--
-- Name: anuncio anuncio_pkey; Type: CONSTRAINT; Schema: public; Owner: carroya_user
--

ALTER TABLE ONLY public.anuncio
    ADD CONSTRAINT anuncio_pkey PRIMARY KEY (id);


--
-- Name: anuncio anuncio_url_key; Type: CONSTRAINT; Schema: public; Owner: carroya_user
--

ALTER TABLE ONLY public.anuncio
    ADD CONSTRAINT anuncio_url_key UNIQUE (url);


--
-- Name: cambio cambio_anuncio_id_fecha_campo_key; Type: CONSTRAINT; Schema: public; Owner: carroya_user
--

ALTER TABLE ONLY public.cambio
    ADD CONSTRAINT cambio_anuncio_id_fecha_campo_key UNIQUE (anuncio_id, fecha, campo);


--
-- Name: cambio cambio_pkey; Type: CONSTRAINT; Schema: public; Owner: carroya_user
--

ALTER TABLE ONLY public.cambio
    ADD CONSTRAINT cambio_pkey PRIMARY KEY (id);


--
-- Name: log_ejecucion log_ejecucion_pkey; Type: CONSTRAINT; Schema: public; Owner: carroya_user
--

ALTER TABLE ONLY public.log_ejecucion
    ADD CONSTRAINT log_ejecucion_pkey PRIMARY KEY (id);


--
-- Name: log_ejecucion log_ejecucion_run_id_etapa_key; Type: CONSTRAINT; Schema: public; Owner: carroya_user
--

ALTER TABLE ONLY public.log_ejecucion
    ADD CONSTRAINT log_ejecucion_run_id_etapa_key UNIQUE (run_id, etapa);


--
-- Name: observacion observacion_anuncio_id_fecha_key; Type: CONSTRAINT; Schema: public; Owner: carroya_user
--

ALTER TABLE ONLY public.observacion
    ADD CONSTRAINT observacion_anuncio_id_fecha_key UNIQUE (anuncio_id, fecha);


--
-- Name: observacion observacion_pkey; Type: CONSTRAINT; Schema: public; Owner: carroya_user
--

ALTER TABLE ONLY public.observacion
    ADD CONSTRAINT observacion_pkey PRIMARY KEY (id);


--
-- Name: vendedor vendedor_nombre_departamento_key; Type: CONSTRAINT; Schema: public; Owner: carroya_user
--

ALTER TABLE ONLY public.vendedor
    ADD CONSTRAINT vendedor_nombre_departamento_key UNIQUE (nombre, departamento);


--
-- Name: vendedor vendedor_pkey; Type: CONSTRAINT; Schema: public; Owner: carroya_user
--

ALTER TABLE ONLY public.vendedor
    ADD CONSTRAINT vendedor_pkey PRIMARY KEY (id);


--
-- Name: idx_anuncio_año; Type: INDEX; Schema: public; Owner: carroya_user
--

CREATE INDEX "idx_anuncio_año" ON public.anuncio USING btree ("año");


--
-- Name: idx_anuncio_ciudad; Type: INDEX; Schema: public; Owner: carroya_user
--

CREATE INDEX idx_anuncio_ciudad ON public.anuncio USING btree (ciudad);


--
-- Name: idx_anuncio_vend; Type: INDEX; Schema: public; Owner: carroya_user
--

CREATE INDEX idx_anuncio_vend ON public.anuncio USING btree (vendedor_id);


--
-- Name: idx_cambio_anuncio; Type: INDEX; Schema: public; Owner: carroya_user
--

CREATE INDEX idx_cambio_anuncio ON public.cambio USING btree (anuncio_id);


--
-- Name: idx_cambio_fecha; Type: INDEX; Schema: public; Owner: carroya_user
--

CREATE INDEX idx_cambio_fecha ON public.cambio USING btree (fecha DESC);


--
-- Name: idx_log_fecha; Type: INDEX; Schema: public; Owner: carroya_user
--

CREATE INDEX idx_log_fecha ON public.log_ejecucion USING btree (fecha_inicio DESC);


--
-- Name: idx_log_run_id; Type: INDEX; Schema: public; Owner: carroya_user
--

CREATE INDEX idx_log_run_id ON public.log_ejecucion USING btree (run_id);


--
-- Name: idx_obs_anuncio; Type: INDEX; Schema: public; Owner: carroya_user
--

CREATE INDEX idx_obs_anuncio ON public.observacion USING btree (anuncio_id);


--
-- Name: idx_obs_fecha; Type: INDEX; Schema: public; Owner: carroya_user
--

CREATE INDEX idx_obs_fecha ON public.observacion USING btree (fecha DESC);


--
-- Name: idx_obs_precio; Type: INDEX; Schema: public; Owner: carroya_user
--

CREATE INDEX idx_obs_precio ON public.observacion USING btree (precio) WHERE (precio IS NOT NULL);


--
-- Name: anuncio anuncio_vendedor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: carroya_user
--

ALTER TABLE ONLY public.anuncio
    ADD CONSTRAINT anuncio_vendedor_id_fkey FOREIGN KEY (vendedor_id) REFERENCES public.vendedor(id);


--
-- Name: cambio cambio_anuncio_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: carroya_user
--

ALTER TABLE ONLY public.cambio
    ADD CONSTRAINT cambio_anuncio_id_fkey FOREIGN KEY (anuncio_id) REFERENCES public.anuncio(id) ON DELETE CASCADE;


--
-- Name: observacion observacion_anuncio_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: carroya_user
--

ALTER TABLE ONLY public.observacion
    ADD CONSTRAINT observacion_anuncio_id_fkey FOREIGN KEY (anuncio_id) REFERENCES public.anuncio(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict DKVYTabtnyQVUYsAARfV0cRInehgqxKwClILbPStts271smPQzLnuhyI9JtAkZj

