--
-- PostgreSQL database dump
--

\restrict 8m5osTbezQaeesAafmD78a7qSrNYSL1gFPbvL32CCVKb0oy9958k4MEmazPXHjg

-- Dumped from database version 16.15 (Ubuntu 16.15-0ubuntu0.24.04.1)
-- Dumped by pg_dump version 16.15 (Ubuntu 16.15-0ubuntu0.24.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: estado_tipo; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.estado_tipo AS ENUM (
    'sin intentar',
    'descargado',
    'fallido',
    'no_encontrado'
);


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: anuncio; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.anuncio (
    id integer NOT NULL,
    url text NOT NULL,
    marca character varying(50),
    linea character varying(50),
    "año" smallint,
    ciudad character varying(100),
    vendedor_id integer,
    primera_vista date NOT NULL,
    ultima_vista date NOT NULL,
    CONSTRAINT chk_vistas CHECK ((ultima_vista >= primera_vista))
);


--
-- Name: anuncio_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.anuncio_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: anuncio_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.anuncio_id_seq OWNED BY public.anuncio.id;


--
-- Name: cambio; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cambio (
    id integer NOT NULL,
    anuncio_id integer NOT NULL,
    fecha date NOT NULL,
    campo character varying(50) NOT NULL,
    valor_anterior text,
    valor_nuevo text
);


--
-- Name: cambio_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.cambio_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: cambio_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.cambio_id_seq OWNED BY public.cambio.id;


--
-- Name: log_ejecucion; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.log_ejecucion (
    id integer NOT NULL,
    run_id character varying(50) NOT NULL,
    etapa character varying(50) NOT NULL,
    fecha_inicio timestamp with time zone NOT NULL,
    fecha_fin timestamp with time zone,
    duracion_seg numeric(10,2),
    estado character varying(20) DEFAULT 'iniciado'::character varying NOT NULL,
    enlaces_encontrados integer,
    descargas_ok integer,
    descargas_fallidas integer,
    descargas_pendientes integer,
    anuncios_nuevos integer,
    registros_actualizados integer,
    registros_sin_cambio integer,
    no_encontrados integer,
    anuncios_unicos_total integer,
    tamanio_bd_mb numeric(10,2),
    correo_estado character varying(50),
    mensaje text,
    detalle_error text
);


--
-- Name: log_ejecucion_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.log_ejecucion_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: log_ejecucion_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.log_ejecucion_id_seq OWNED BY public.log_ejecucion.id;


--
-- Name: observacion; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.observacion (
    id integer NOT NULL,
    anuncio_id integer NOT NULL,
    fecha date NOT NULL,
    hora time without time zone,
    estado public.estado_tipo NOT NULL,
    version character varying(200),
    precio bigint,
    moneda character(3),
    kilometraje integer,
    transmision character varying(100),
    color character varying(50),
    sunroof boolean,
    error character varying(500),
    combustible character varying(50),
    comentarios text
);


--
-- Name: observacion_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.observacion_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: observacion_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.observacion_id_seq OWNED BY public.observacion.id;


--
-- Name: vendedor; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.vendedor (
    id integer NOT NULL,
    nombre character varying(200) NOT NULL,
    departamento character varying(100)
);


--
-- Name: vendedor_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.vendedor_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: vendedor_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.vendedor_id_seq OWNED BY public.vendedor.id;


--
-- Name: anuncio id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.anuncio ALTER COLUMN id SET DEFAULT nextval('public.anuncio_id_seq'::regclass);


--
-- Name: cambio id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cambio ALTER COLUMN id SET DEFAULT nextval('public.cambio_id_seq'::regclass);


--
-- Name: log_ejecucion id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.log_ejecucion ALTER COLUMN id SET DEFAULT nextval('public.log_ejecucion_id_seq'::regclass);


--
-- Name: observacion id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.observacion ALTER COLUMN id SET DEFAULT nextval('public.observacion_id_seq'::regclass);


--
-- Name: vendedor id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vendedor ALTER COLUMN id SET DEFAULT nextval('public.vendedor_id_seq'::regclass);


--
-- Data for Name: anuncio; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.anuncio (id, url, marca, linea, "año", ciudad, vendedor_id, primera_vista, ultima_vista) FROM stdin;
6	https://www.carroya.com/detalle/usado/toyota/corolla/2022/bogota/86549bd8-c429-4e97-9148-3471bd6d2dd4	Toyota	Corolla	2022	Bogota	6	2026-11-16	2026-11-16
12	https://www.carroya.com/detalle/usado/toyota/corolla/2022/medellin/0dd6cbba-d0f6-4b18-bf83-e499a52c62d7	Toyota	Corolla	2022	Medellin	12	2026-11-16	2026-11-21
13	https://www.carroya.com/detalle/usado/toyota/corolla/2022/medellin/52ed48be-c55b-4ec4-92e0-355650da22cb	Toyota	Corolla	2022	Medellin	12	2026-11-16	2026-11-21
35	https://www.carroya.com/detalle/usado/toyota/corolla/2023/medellin/0141e624-be5a-4634-a6a7-c98066fe48b0	Toyota	Corolla	2023	Medellin	12	2026-11-16	2026-11-21
205	https://www.carroya.com/detalle/usado/toyota/corolla/2023/medellin/197a0580-f2ed-43a7-838b-4bfe61958a03	Toyota	Corolla	2023	Medellin	12	2026-11-19	2026-11-21
42	https://www.carroya.com/detalle/usado/toyota/corolla/2023/medellin/f4f8fae0-5d3f-4a6a-9fdb-7935115337cf	Toyota	Corolla	2023	Medellin	12	2026-11-16	2026-11-21
43	https://www.carroya.com/detalle/usado/toyota/corolla/2023/pasto/58c02917-93f3-4ea8-86c4-e69beb1df4e4	Toyota	Corolla	2023	Pasto	43	2026-11-16	2026-11-21
221	https://www.carroya.com/detalle/usado/toyota/corolla/2025/bogota/1090dea1-1199-46f1-a2c2-5640c9ce1be2	Toyota	Corolla	2025	Bogota	\N	2026-11-19	2026-11-21
24	https://www.carroya.com/detalle/usado/toyota/corolla/2023/bogota/481862b9-ac91-487f-8610-9d7a38bbe404	Toyota	Corolla	2023	Bogota	6	2026-11-16	2026-11-16
32	https://www.carroya.com/detalle/usado/toyota/corolla/2023/cucuta/0130d3ab-61e1-4734-adcf-88ca8306b8e7	Toyota	Corolla	2023	Cucuta	32	2026-11-16	2026-11-21
49	https://www.carroya.com/detalle/usado/toyota/corolla/2024/medellin/f3c47407-556b-436c-a134-a4c1f059e4e6	Toyota	Corolla	2024	Medellin	12	2026-11-16	2026-11-21
55	https://www.carroya.com/detalle/usado/toyota/corolla/2025/medellin/bf713f5c-91fb-4d07-b30b-85b805ef8621	Toyota	Corolla	2025	Medellin	12	2026-11-16	2026-11-21
1	https://www.carroya.com/detalle/usado/toyota/corolla/2022/bogota/1461ca6c-e4fe-4755-ad43-3c3fd0c5767b	Toyota	Corolla	2022	Bogota	1	2026-11-16	2026-11-21
2	https://www.carroya.com/detalle/usado/toyota/corolla/2022/bogota/1da3f26f-493c-4333-a5d1-5f1c60bb0c71	Toyota	Corolla	2022	Bogota	2	2026-11-16	2026-11-21
3	https://www.carroya.com/detalle/usado/toyota/corolla/2022/bogota/3a9bd4a3-73eb-4e3f-9aad-0870cf9cbf4c	Toyota	Corolla	2022	Bogota	3	2026-11-16	2026-11-21
4	https://www.carroya.com/detalle/usado/toyota/corolla/2022/bogota/5a526c41-6c90-4ca6-9c87-7559ae1f1487	Toyota	Corolla	2022	Bogota	4	2026-11-16	2026-11-21
5	https://www.carroya.com/detalle/usado/toyota/corolla/2022/bogota/5c7d6de2-b4ba-4d4d-957d-4e2c74eb20ea	Toyota	Corolla	2022	Bogota	5	2026-11-16	2026-11-21
7	https://www.carroya.com/detalle/usado/toyota/corolla/2022/bogota/a221c1a0-0524-421b-9909-9cfdd33cff72	Toyota	Corolla	2022	Bogota	7	2026-11-16	2026-11-21
8	https://www.carroya.com/detalle/usado/toyota/corolla/2022/bogota/a7b14618-6fb9-4468-a7af-338a3ce4a1d8	Toyota	Corolla	2022	Bogota	8	2026-11-16	2026-11-21
9	https://www.carroya.com/detalle/usado/toyota/corolla/2022/bogota/b2390638-5012-4780-ab68-e1042a8cb21c	Toyota	Corolla	2022	Bogota	9	2026-11-16	2026-11-21
10	https://www.carroya.com/detalle/usado/toyota/corolla/2022/bogota/d0444b8b-5a5a-4dbd-b41f-0a7a9a8535d4	Toyota	Corolla	2022	Bogota	10	2026-11-16	2026-11-21
11	https://www.carroya.com/detalle/usado/toyota/corolla/2022/envigado/a2ee3a3d-ff63-46fb-95db-4d4e97ad13d1	Toyota	Corolla	2022	Envigado	11	2026-11-16	2026-11-21
14	https://www.carroya.com/detalle/usado/toyota/corolla/2022/medellin/ab582ec2-55aa-46d3-b746-761b17b061ce	Toyota	Corolla	2022	Medellin	12	2026-11-16	2026-11-21
15	https://www.carroya.com/detalle/usado/toyota/corolla/2022/medellin/d368e25e-dde2-4ea1-8566-33c66d39995f	Toyota	Corolla	2022	Medellin	12	2026-11-16	2026-11-21
16	https://www.carroya.com/detalle/usado/toyota/corolla/2022/medellin/df0e4b7c-a81b-41d2-993f-41d93c28578d	Toyota	Corolla	2022	Medellin	12	2026-11-16	2026-11-21
17	https://www.carroya.com/detalle/usado/toyota/corolla/2022/villavicencio/d1bf9d95-155f-4610-ab51-e93207c59ff7	Toyota	Corolla	2022	Villavicencio	17	2026-11-16	2026-11-21
18	https://www.carroya.com/detalle/usado/toyota/corolla/2023/bello/1e6fb3a5-7462-484d-a70a-976ae9722eb9	Toyota	Corolla	2023	Bello	18	2026-11-16	2026-11-21
19	https://www.carroya.com/detalle/usado/toyota/corolla/2023/bogota/02f40a46-bcc5-4be3-aa80-829171fed051	Toyota	Corolla	2023	Bogota	19	2026-11-16	2026-11-21
20	https://www.carroya.com/detalle/usado/toyota/corolla/2023/bogota/2052530	Toyota	Corolla	2023	Bogota	20	2026-11-16	2026-11-21
23	https://www.carroya.com/detalle/usado/toyota/corolla/2023/bogota/3b4f3f24-b0aa-485c-8d24-4185bc8632e5	Toyota	Corolla	2023	Bogota	23	2026-11-16	2026-11-21
25	https://www.carroya.com/detalle/usado/toyota/corolla/2023/bogota/8f6a5497-902a-4fe7-ba03-6a4eec3f8eac	Toyota	Corolla	2023	Bogota	25	2026-11-16	2026-11-21
26	https://www.carroya.com/detalle/usado/toyota/corolla/2023/bogota/a4df1180-e1dd-4f68-8970-b728279b8727	Toyota	Corolla	2023	Bogota	26	2026-11-16	2026-11-21
28	https://www.carroya.com/detalle/usado/toyota/corolla/2023/bogota/b2019d5c-93c3-4b48-9c50-2fe84e67fc4e	Toyota	Corolla	2023	Bogota	28	2026-11-16	2026-11-21
29	https://www.carroya.com/detalle/usado/toyota/corolla/2023/bogota/c6245bd1-3989-4d88-ad94-83889ac79168	Toyota	Corolla	2023	Bogota	29	2026-11-16	2026-11-21
30	https://www.carroya.com/detalle/usado/toyota/corolla/2023/bucaramanga/2d84cf8e-88c8-4c63-9e37-e6b08fc65a53	Toyota	Corolla	2023	Bucaramanga	30	2026-11-16	2026-11-21
31	https://www.carroya.com/detalle/usado/toyota/corolla/2023/cali/14805f43-bdb0-4eaf-a097-48c3c52552e6	Toyota	Corolla	2023	Cali	31	2026-11-16	2026-11-21
33	https://www.carroya.com/detalle/usado/toyota/corolla/2023/cucuta/1b75da25-57a0-4e58-87ca-bc2d86bb76eb	Toyota	Corolla	2023	Cucuta	33	2026-11-16	2026-11-21
34	https://www.carroya.com/detalle/usado/toyota/corolla/2023/ibague/453991fd-06d3-4579-bedc-8d7c66036242	Toyota	Corolla	2023	Ibague	34	2026-11-16	2026-11-21
146	https://www.carroya.com/detalle/usado/toyota/corolla/2023/itagui/50361b03-d60f-47eb-aa78-cd09772f4438	Toyota	Corolla	2023	Itagui	146	2026-11-18	2026-11-21
36	https://www.carroya.com/detalle/usado/toyota/corolla/2023/medellin/4def931a-817d-4261-8c3a-2af7936d1c18	Toyota	Corolla	2023	Medellin	36	2026-11-16	2026-11-21
38	https://www.carroya.com/detalle/usado/toyota/corolla/2023/medellin/5b670144-eb1b-4da4-89af-502fcfabc230	Toyota	Corolla	2023	Medellin	38	2026-11-16	2026-11-21
27	https://www.carroya.com/detalle/usado/toyota/corolla/2023/bogota/b177a2ee-8b5a-429f-9cff-1895067df51c	Toyota	Corolla	2023	Bogota	27	2026-11-16	2026-11-18
21	https://www.carroya.com/detalle/usado/toyota/corolla/2023/bogota/2bafe1ea-7132-471b-bbe4-442eeeed8d4f	Toyota	Corolla	2023	Bogota	21	2026-11-16	2026-11-20
22	https://www.carroya.com/detalle/usado/toyota/corolla/2023/bogota/307925c3-bf14-4821-8444-71e986578727	Toyota	Corolla	2023	Bogota	22	2026-11-16	2026-11-20
39	https://www.carroya.com/detalle/usado/toyota/corolla/2023/medellin/ac2a946d-48cc-4cd7-9414-ef914a66c590	Toyota	Corolla	2023	Medellin	39	2026-11-16	2026-11-21
40	https://www.carroya.com/detalle/usado/toyota/corolla/2023/medellin/ae957bf0-5948-4eaf-8d6e-1cc430d803ce	Toyota	Corolla	2023	Medellin	40	2026-11-16	2026-11-21
41	https://www.carroya.com/detalle/usado/toyota/corolla/2023/medellin/cad4c5ed-a78f-4830-88f5-932d07300dfb	Toyota	Corolla	2023	Medellin	41	2026-11-16	2026-11-21
37	https://www.carroya.com/detalle/usado/toyota/corolla/2023/medellin/53f370b3-0d3a-4ce2-ae04-6438daa7e25b	Toyota	Corolla	2023	Medellin	37	2026-11-16	2026-11-20
58	https://www.carroya.com/detalle/usado/toyota/corolla/2026/bogota/c2fce922-3287-48e1-9825-fd2eaca87be9	Toyota	Corolla	2026	Bogota	58	2026-11-16	2026-11-21
59	https://www.carroya.com/detalle/usado/toyota/corolla/2026/manizales/9e1a58d5-aab2-43c3-b75f-3dedbafc1e2a	Toyota	Corolla	2026	Manizales	59	2026-11-16	2026-11-21
60	https://www.carroya.com/detalle/usado/toyota/corolla/2026/medellin/51cc66ef-19cc-476a-a536-8f0a76b9730d	Toyota	Corolla	2026	Medellin	12	2026-11-16	2026-11-21
61	https://www.carroya.com/detalle/usado/toyota/corolla/2026/medellin/549fc674-53ee-45e4-81f6-eb7de5f42b2f	Toyota	Corolla	2026	Medellin	61	2026-11-16	2026-11-21
53	https://www.carroya.com/detalle/usado/toyota/corolla/2025/medellin/15a5278c-d3c2-4d4a-b8f5-7a108fc05d21	Toyota	Corolla	2025	Medellin	12	2026-11-16	2026-11-20
44	https://www.carroya.com/detalle/usado/toyota/corolla/2023/villavicencio/8a254de4-9bd0-471a-91e0-2a000ceca247	Toyota	Corolla	2023	Villavicencio	44	2026-11-16	2026-11-21
45	https://www.carroya.com/detalle/usado/toyota/corolla/2024/bogota/262ad6cb-7331-43df-aa0b-6ca8e3ada138	Toyota	Corolla	2024	Bogota	45	2026-11-16	2026-11-21
46	https://www.carroya.com/detalle/usado/toyota/corolla/2024/bogota/687a1665-7e7a-4fff-97c9-41ddcfd0161b	Toyota	Corolla	2024	Bogota	46	2026-11-16	2026-11-21
47	https://www.carroya.com/detalle/usado/toyota/corolla/2024/bogota/eb667dfd-9f08-48c3-afc1-9545291be6d3	Toyota	Corolla	2024	Bogota	47	2026-11-16	2026-11-21
48	https://www.carroya.com/detalle/usado/toyota/corolla/2024/medellin/889d2f0f-661b-4462-aad1-4515bf7891a7	Toyota	Corolla	2024	Medellin	37	2026-11-16	2026-11-21
50	https://www.carroya.com/detalle/usado/toyota/corolla/2025/bogota/0634dca5-40ca-42d5-9bd7-8e3e25cf0f7e	Toyota	Corolla	2025	Bogota	50	2026-11-16	2026-11-21
51	https://www.carroya.com/detalle/usado/toyota/corolla/2025/bogota/a4c60092-f782-486f-98cb-5e7e5b22b847	Toyota	Corolla	2025	Bogota	51	2026-11-16	2026-11-21
52	https://www.carroya.com/detalle/usado/toyota/corolla/2025/medellin/05c982ce-4072-40e8-8c2f-c9a679820e78	Toyota	Corolla	2025	Medellin	12	2026-11-16	2026-11-21
54	https://www.carroya.com/detalle/usado/toyota/corolla/2025/medellin/78810763-bc26-46ec-b5f0-f1261a415460	Toyota	Corolla	2025	Medellin	12	2026-11-16	2026-11-21
56	https://www.carroya.com/detalle/usado/toyota/corolla/2025/medellin/bfbadc33-f663-4001-96a4-fbf57851f800	Toyota	Corolla	2025	Medellin	12	2026-11-16	2026-11-21
57	https://www.carroya.com/detalle/usado/toyota/corolla/2026/bogota/a3b6c8b4-299b-409c-8e69-1f5df600e9cb	Toyota	Corolla	2026	Bogota	57	2026-11-16	2026-11-21
\.


--
-- Data for Name: cambio; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cambio (id, anuncio_id, fecha, campo, valor_anterior, valor_nuevo) FROM stdin;
\.


--
-- Data for Name: log_ejecucion; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.log_ejecucion (id, run_id, etapa, fecha_inicio, fecha_fin, duracion_seg, estado, enlaces_encontrados, descargas_ok, descargas_fallidas, descargas_pendientes, anuncios_nuevos, registros_actualizados, registros_sin_cambio, no_encontrados, anuncios_unicos_total, tamanio_bd_mb, correo_estado, mensaje, detalle_error) FROM stdin;
1	2026-11-16	scraper	2026-11-16 08:00:01.415099-05	2026-11-16 08:07:07.998467-05	426.58	ok	61	61	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N
2	2026-11-16	loader	2026-11-16 08:07:08.121409-05	2026-11-16 08:07:08.190201-05	0.07	ok	\N	\N	\N	\N	61	0	0	0	61	8.06	\N	\N	\N
3	2026-11-16	analisis	2026-11-16 08:07:08.648036-05	2026-11-16 08:07:09.032755-05	0.38	ok	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	fecha=2026-11-16 n_dia=61 evaluados=54 gangas=5 gangas_nuevas=5 insuficientes=7	\N
4	2026-11-16	correo	2026-11-16 11:00:05.121496-05	2026-11-16 11:00:05.123295-05	0.00	ok	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	enviado	Corolla 16/11/2026 · Proceso completo · 5 posible(s) ganga(s) nueva(s)	\N
5	2026-11-17	scraper	2026-11-17 08:00:02.131597-05	2026-11-17 08:07:37.789817-05	455.66	ok	53	53	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N
6	2026-11-17	loader	2026-11-17 08:07:37.909319-05	2026-11-17 08:07:38.000498-05	0.09	ok	\N	\N	\N	\N	0	53	0	8	61	8.17	\N	\N	\N
7	2026-11-17	analisis	2026-11-17 08:07:38.465605-05	2026-11-17 08:07:38.830477-05	0.36	ok	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	fecha=2026-11-17 n_dia=53 evaluados=47 gangas=4 gangas_nuevas=0 insuficientes=6	\N
8	2026-11-17	correo	2026-11-17 11:00:06.353535-05	2026-11-17 11:00:06.355267-05	0.00	ok	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	enviado	Corolla 17/11/2026 · Proceso completo · 0 posible(s) ganga(s) nueva(s)	\N
9	2026-11-18	scraper	2026-11-18 08:00:01.367445-05	2026-11-18 08:06:34.077357-05	392.71	ok	57	57	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N
10	2026-11-18	loader	2026-11-18 08:06:34.201559-05	2026-11-18 08:06:34.300841-05	0.10	ok	\N	\N	\N	\N	1	56	0	5	62	8.24	\N	\N	\N
11	2026-11-18	analisis	2026-11-18 08:06:34.762637-05	2026-11-18 08:06:35.141537-05	0.38	ok	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	fecha=2026-11-18 n_dia=57 evaluados=51 gangas=6 gangas_nuevas=1 insuficientes=6	\N
12	2026-11-18	correo	2026-11-18 11:00:05.058822-05	2026-11-18 11:00:05.060644-05	0.00	ok	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	enviado	Corolla 18/11/2026 · Proceso completo · 1 posible(s) ganga(s) nueva(s)	\N
13	2026-11-19	scraper	2026-11-19 08:00:02.069664-05	2026-11-19 08:08:04.666007-05	482.60	ok	61	61	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N
14	2026-11-19	loader	2026-11-19 08:08:04.793462-05	2026-11-19 08:08:04.893583-05	0.10	ok	\N	\N	\N	\N	2	59	0	3	64	8.30	\N	\N	\N
15	2026-11-19	analisis	2026-11-19 08:08:05.355756-05	2026-11-19 08:08:05.740178-05	0.38	ok	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	fecha=2026-11-19 n_dia=61 evaluados=54 gangas=6 gangas_nuevas=1 insuficientes=7	\N
16	2026-11-19	correo	2026-11-19 11:00:06.033433-05	2026-11-19 11:00:06.035677-05	0.00	ok	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	enviado	Corolla 19/11/2026 · Proceso completo · 1 posible(s) ganga(s) nueva(s)	\N
17	2026-11-20	scraper	2026-11-20 08:00:02.048098-05	2026-11-20 08:07:03.560397-05	421.51	ok	55	55	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N
18	2026-11-20	loader	2026-11-20 08:07:03.685491-05	2026-11-20 08:07:03.778047-05	0.09	ok	\N	\N	\N	\N	0	55	0	9	64	8.36	\N	\N	\N
19	2026-11-20	analisis	2026-11-20 08:07:04.239488-05	2026-11-20 08:07:04.608332-05	0.37	ok	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	fecha=2026-11-20 n_dia=55 evaluados=50 gangas=5 gangas_nuevas=0 insuficientes=5	\N
20	2026-11-20	correo	2026-11-20 11:00:05.748512-05	2026-11-20 11:00:05.750355-05	0.00	ok	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	enviado	Corolla 20/11/2026 · Proceso completo · 0 posible(s) ganga(s) nueva(s)	\N
21	2026-11-21	scraper	2026-11-21 08:00:01.76335-05	2026-11-21 08:07:46.186611-05	464.42	ok	57	57	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N
22	2026-11-21	loader	2026-11-21 08:07:46.310596-05	2026-11-21 08:07:46.406166-05	0.10	ok	\N	\N	\N	\N	0	57	0	7	64	8.40	\N	\N	\N
23	2026-11-21	analisis	2026-11-21 08:07:46.873659-05	2026-11-21 08:07:47.243598-05	0.37	ok	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	fecha=2026-11-21 n_dia=57 evaluados=50 gangas=6 gangas_nuevas=0 insuficientes=7	\N
24	2026-11-21	correo	2026-11-21 11:00:05.47988-05	2026-11-21 11:00:05.4816-05	0.00	ok	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	enviado	Corolla 21/11/2026 · Proceso completo · 0 posible(s) ganga(s) nueva(s)	\N
\.


--
-- Data for Name: observacion; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.observacion (id, anuncio_id, fecha, hora, estado, version, precio, moneda, kilometraje, transmision, color, sunroof, error, combustible, comentarios) FROM stdin;
1	1	2026-11-16	08:01:00	descargado	1.8 XE-i Automatico	84900000	COP	54984	Automática	Plateado	f	\N	Híbrido	🚗 ¡OPORTUNIDAD! Toyota Corolla Híbrido XEI 2022, en excelente estado, nunca siniestrado según historial. Elegante, cómodo y económico en combustible. Tecnología híbrida, ideal para ciudad y carretera. Placa terminada en 8. 💰 $84.900.000 negociables. ¡Un Toyota que combina confort, ahorro y confiabilidad! Agenda tu visita y conócelo.
2	2	2026-11-16	08:01:06	descargado	1.3 Mecanico	85000000	COP	35000	Mecánica	Gris	f	\N	Gasolina	Vehiculo en perfecto estado, A/C, direccionales habatibles, pernos de seguridad, seguro de direccionales, ventanas contrarobo, mantenimientos en cosecionario, único dueño, placa par.
3	3	2026-11-16	08:01:13	descargado	1.8 CVT SEG	94000000	COP	63000	Automática	Gris	t	\N	Híbrido	VEHICULO EN EXCELENTES CONDICIONES LISTO PARA TRASPASO VERSION FULL SEG 2022 63.000 SUN ROOF TAPICERIA EN CUERO APPLE CAR PLAY
4	4	2026-11-16	08:01:19	descargado	1.8 XE-i Automatico	98500000	COP	40000	Automática	Negro	f	\N	Híbrido	Toyota Corolla Hybrid Black Edition 2022, todos sus mantenimientos en ToyoNorte, al día de impuestos, perfecto estado, tapetes todo tiempo toyota, sin pico y placa, no enchufable, consumo muy bajo, silencioso y potente. Negociable. Soat y técnico hasta 2027. CarPlay, cámara trasera, sensores delanteros y traseros, Venta directa.
5	5	2026-11-16	08:01:24	descargado	\N	115000000	COP	20000	Automática	Blanco	t	\N	Híbrido	SEG Hybrid, full equipo, cuenta con siete airbags, película polarizada, cojinería en cuero, sunroof, no tiene pico y placa, se entrega con la revisión de los 20000 Km, venta directa, único dueño
6	6	2026-11-16	08:01:30	descargado	1.8 XE-i Hybrid Automatico	84990000	COP	84392	Automática	Blanco	f	\N	Híbrido	N/A
7	7	2026-11-16	08:01:36	descargado	1.8 XE-i Automatico	95000000	COP	31800	Automática	Gris	f	\N	Híbrido	Excelente estado como nuevo, sin pico y placa , mtto de 30.000 km recien hecho, unico dueño, todos los mantenimientos realizados en carco, libre de papeles, no tiene pignoraciones.
8	8	2026-11-16	08:01:42	descargado	1.8 CVT XEI	95000000	COP	29000	Secuencial	Blanco	f	\N	Híbrido	Único dueño, perfecto estado, mantenimientos al día
9	9	2026-11-16	08:01:48	descargado	1.8 XE-i Automatico	89000000	COP	82000	Automática	Blanco	f	\N	Híbrido	Toyota Corolla 2022, 100% hibrido 82,000 km. Último mantenimiento realizado el de 80.000 km, llantas nuevas y con todos los mantenimientos directamente con Toyota conforme al libro de la marca. Motor de 1.8 litros y 136 hp, transmisión automática, dirección electroasistida y tracción delantera Autonomía hasta 90Km por galón. Control de estabilidad, sensores de estacionamiento, cámara de revers...
10	10	2026-11-16	08:01:54	descargado	XEI 2.0 Sedan Manual	83990000	COP	27952	Mecánica	Rojo	f	\N	Gasolina	2 llaves manules
11	11	2026-11-16	08:01:59	descargado	1.8 XE-i Automatico	87000000	COP	44000	Automática	Blanco	f	\N	Híbrido	Toyota Corolla híbrido modelo Chery 2022, llantas al 99%, SOAT recién comprado, papeles al día, listo para traspaso inmediato, puede hacerse revisión en CDA sin ningún problema, pasa sin problema, mantenimientos con Toyota Motor y único dueño, perfecto estado del carro.
12	12	2026-11-16	08:02:05	descargado	1.8	119900000	COP	55000	Automática	Blanco	f	\N	Híbrido	Corolla Seg blindaje2 híbrido
13	13	2026-11-16	08:02:11	descargado	1.8 CVT SEG	91900000	COP	68000	Automática	Blanco	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
14	14	2026-11-16	08:02:17	descargado	1.8 XEi-L Automatico	89900000	COP	52050	Automática	Blanco	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
15	15	2026-11-16	08:02:23	descargado	1.8 XEi-L Automatico	89900000	COP	52050	Automática	Blanco	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
16	16	2026-11-16	08:02:31	descargado	1.8 CVT XEI	107900000	COP	72300	Automática	Blanco	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
17	17	2026-11-16	08:02:36	descargado	1.8 CVT SEG	111700000	COP	85000	Automática	Plateado	f	\N	Híbrido	Llantas y Soat comprados en septiembre 2026, excelente estado, unico dueño
18	18	2026-11-16	08:02:42	descargado	1.8 XL-i Automatico	99900000	COP	46000	Automática	Gris	f	\N	Híbrido	Toyota Corolla XLI Hybrid 2023 | Único dueño | 46.000 km | Equipado con accesorios originales de agencia. ⭐ *Equipamiento y extras* * Sistema híbrido 1.8L Toyota, automático E * Llantas y rines originales *de la versión SEG*, instalados de agencia * Polarizado premium. * Tapetes termoformado * Protectores *originales* de retrovisores. * Estribos *originales* de agencia * Interior y exterior en ex...
19	19	2026-11-16	08:02:48	descargado	SE-G Automatico	110000000	COP	23000	Automática	Gris	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
20	20	2026-11-16	08:02:54	descargado	1.8 XL-i Automatico	101000000	COP	1000	Automática	Blanco	f	\N	Híbrido	2023 Toyota Corolla XLI 1.8 Hibrido. KILOMETRAJE es 14
21	21	2026-11-16	08:03:00	descargado	SE-G Automatico	100000000	COP	43000	Automática	Blanco	t	\N	Híbrido	🇨🇴🏁🇯🇵 Toyota Corolla SE-G Hybrid 2.023 ✅️ Listo para Traspaso. ✅ Único Dueño. ✅ 43.000 Km. ✅ Motor 1.8cc Híbrido. ️✅️ Automático. ️✅️ Full Equipo. ✅️ 7 Airbags. ✅️ Sunroof. ✅ Tapicería Cuero. ✅ Polarizado. ✅ Apple CarPlay/ Android Auto. ✅ Mantenimientos en Concesionario. ✅️ Matrícula Bogotá.
22	22	2026-11-16	08:03:06	descargado	1.8 Aut	114000000	COP	36000	Automática	Blanco	f	\N	Híbrido	Toyota Corolla Hibrido Seg Full equipo Modelo 2023 36.000 km Todo el mantenimiento certificado en concesionario
23	23	2026-11-16	08:03:12	descargado	1.8 XL-i Automatico	89900000	COP	22550	Automática	Blanco	f	\N	Híbrido	Híbrido full poco kilometraje, único conductor desde nuevo en trayectos urbanos, pintura con tratamiento porcelanizado, vidrios con película de seguridad, batería de 12v nueva para arranque, libro de mantenimientos original toyota con historial completo, solo en concesionario sus mantenimientos, excelente estado motor, exterior e interior, tapicería en tela, vidrios eléctricos, llave inteligente, ...
24	24	2026-11-16	08:03:18	descargado	SE-G Automatico	99990000	COP	45800	Automática	Gris	f	\N	Gasolina	N/A
25	25	2026-11-16	08:03:24	descargado	1.8 XL-i Automatico	108000000	COP	34083	Automática	Gris	t	\N	Híbrido	Único dueño, accesorios originales.
26	26	2026-11-16	08:03:30	descargado	SE-G Automatico	145000000	COP	30000	Automática	Gris	t	\N	Híbrido	El vendedor no incluyó una descripción del producto.
27	27	2026-11-16	08:03:35	descargado	1.8 XL-i Automatico	89990000	COP	21940	Automática	Blanco	f	\N	Híbrido	A continuación encuentras muchos más detalles de nuestro WCAR: -Dueños 1 -Llaves 1 -Pasajeros 5 -Placa 3 Mosquera -Modelo 2023 -Recorrido 21,940 Km -Soat 31/03/2027 -Transmisión A/T -airbag -Rines de lujo -Luces Exploradoras -vidrios eléctricos -Espejos eléctricos -tipo de radio Original -Comandos en el timón -Cámara de reversa -sensor de reversa -Sensor de luz -Aire acondicionado -tipo de dire...
61	61	2026-11-16	08:07:01	descargado	1.8	134000000	COP	1600	Automática	Gris	f	\N	Híbrido	Carro casi nuevo Toyota Corolla 1.8 Hev Seg kilometraje 1.600 modelo 2026
28	28	2026-11-16	08:03:41	descargado	1.8 XEi-L Automatico	99900000	COP	42000	Automática	Gris	f	\N	Híbrido	TOYOTA COROLLA XE-I HYBRID TP 1800CC 7AB ABS MOD 2023 🚙 Recorrido: 42.000km 🚙 Soat: 24/02/2026 🚙 Tecno: N/A 🚙 Placa: 1️⃣ 🚙 ABS 🚙 Airbags: 7 🚙 Mandos en el timón 🚙 Cámara de reversa 🚙 Sensores 🚙 Dirección: Eléctrica 🚙 Frenos: Disco/Disco 🚙 Faros: LED 🚙 Espejos eléctricos 2 🚙 Tracción: Delantera 🚙 Vidrios eléctricos: 4 🚙 Tapicería: Tela 🚙 Caja: Triptonica 🚙 Color: GRIS CELESTE ...
29	29	2026-11-16	08:03:47	descargado	1.8 XE-i Automatico	102000000	COP	21000	Automática	Blanco	f	\N	Híbrido	Vehículo en excelente estado, peritaje donde desee, recibo vehículo de menor valor
30	30	2026-11-16	08:03:53	descargado	1.8 CVT SEG	115000000	COP	20000	Automática	Plateado	t	\N	Híbrido	El vendedor no incluyó una descripción del producto.
31	31	2026-11-16	08:03:59	descargado	SE-G Automatico	118990000	COP	30000	Automática	Blanco	t	\N	Híbrido	Hermoso Toyota Corolla Sedan Blanco perlado Version mas equipada SEG. Cogineria en cuero, sunroof, todas las ayudas de conduccion, camara trasera y sensores de colision. Hibridacion Full (Consumo combustible promedio en ciudad 70 km/galon) Modelo 2023 con apenas 30.000 km Llantas nuevas (menos de 6 meses)
32	32	2026-11-16	08:04:04	descargado	GR-S 2.0 Deportivo Manual Gasolina	95900000	COP	37000	Automática	Rojo	f	\N	Gasolina	El vendedor no incluyó una descripción del producto.
33	33	2026-11-16	08:04:10	descargado	GR-S 2.0 Deportivo Manual Gasolina	90000000	COP	36000	Automática	Rojo	f	\N	Gasolina	excelente precio poco kilometraje, unico dueño, nunca chocado, seguro todo riesgo AXA, soat hasta agosto 2027, perfecto estado, mod 2023.
34	34	2026-11-16	08:04:16	descargado	SE-G Automatico	104900000	COP	39000	Automática	Rojo	f	\N	Híbrido	Toyota Corolla Híbrido 2023 SEG - Versión full equipo 39.900 km Mantenimientos en concesionario Sin reclamaciones Dos llaves Soat vigente Pasa peritaje Ubicado en ibague
35	35	2026-11-16	08:04:22	descargado	1.8 CVT SEG	88900000	COP	56000	Automática	Gris	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
36	36	2026-11-16	08:04:27	descargado	SE-G Automatico	112900000	COP	34000	Automática	Gris	f	\N	Híbrido	🚙 🚗Toyota Corolla SEG Modelo 2023 Híbrido 34.000km Automático Conineria de cuero #venta #Medellin #autos
37	37	2026-11-16	08:04:33	descargado	1.8 XE-i Automatico	92900000	COP	53000	Automática	Gris	f	\N	Híbrido	Medellin
38	38	2026-11-16	08:04:39	descargado	XEI 2.0 Sedan Automatico CVT	97000000	COP	59000	0	Gris	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
39	39	2026-11-16	08:04:47	descargado	GR-S 2.0 Deportivo Manual Gasolina	127900000	COP	25400	Automática	Blanco	f	\N	Gasolina	Toyota Corolla Cross GR-S 2.0cc - Modelo: 2023 - Kilometraje: 25.400kms - Transmisión: Automática - Tracción: 4x2 - Combustible: Gasolina - Soat: 26/03/2027 - Tecno: 20/02/2028 - Placa Finaliza: 9
40	40	2026-11-16	08:04:53	descargado	1.8 XE-i Automatico	85000000	COP	56879	Automática	Gris	f	\N	Híbrido	Toyota Corolla XEI HIBRIDO 2023 56.879km 1.8cc Automatico Cojineria cuero Vidrios y espejos electricos Mandos en el timon Pantalla tactil Camara reversa Rines de lujo Llantas 70% Soat 24-junio-2027 Tecno 24-junio-2028
41	41	2026-11-16	08:04:59	descargado	1.8 XE-i Automatico	102000000	COP	53400	Automática	Otro	f	\N	Híbrido	¿Buscas confort, tecnología y ahorro? Vendo mi Toyota Corolla XEI Híbrido modelo 2023, una joya de la ingeniería japonesa. Con solo 53.400 km de recorrido. Motor 1.800cc- Automatico - sistema hibrido (Autorecargable) - 7 airbags - frenos ABS - silleteria de cuero - con asistencia y ayudas para la conducción - mandos en el timon - espejos electricos, vidrios electricos - color gris celeste - Pantal...
42	42	2026-11-16	08:05:05	descargado	1.8 CVT SEG	106900000	COP	48000	Automática	Gris	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
43	43	2026-11-16	08:05:10	descargado	1.8	115000000	COP	25700	Automática	Blanco	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
44	44	2026-11-16	08:05:16	descargado	1.8 CVT SEG	108000000	COP	63000	Automática	Plateado	f	\N	Híbrido	Toyota Corolla Seg Hibrido
45	45	2026-11-16	08:05:22	descargado	1.8 XE-i Automatico	113000000	COP	32000	Automática	Gris	f	\N	Híbrido	Toyota Corolla 2024 32.000 Km Perfecto estado 113.000.000 Negociables
46	46	2026-11-16	08:05:28	descargado	1.8 XE-i Automatico	123000000	COP	5000	Automática	Rojo	f	\N	Híbrido	Esperctacular bien cuidado con cojineria en cuero, UNICO DUEÑO full equipo HIBRIDO vendo directamente negociable
47	47	2026-11-16	08:05:34	descargado	1.8 CVT XEI	115000000	COP	29000	Automática	Plateado	f	\N	Híbrido	Pelicula de Seguridad en los vidrios Pernos de seguridad en las llantas
48	48	2026-11-16	08:05:40	descargado	1.8 CVT XEI	106900000	COP	30000	Automática	Blanco	f	\N	Híbrido	Único dueño. Medellín hibrido todo en cocesiy
49	49	2026-11-16	08:05:45	descargado	\N	95900000	COP	33000	Automática	Blanco	f	\N	Híbrido	Toyota Corolla XLI híbrido
50	50	2026-11-16	08:05:51	descargado	\N	145500000	COP	10000	Automática	Gris	f	\N	Híbrido	Camioneta prácticamente nueva. Precio negociable. Es la versión básica aunque lo suficientemente equipada.
51	51	2026-11-16	08:05:57	descargado	1.8 XE-i Automatico	118000000	COP	4151	Automática	Lila	f	\N	Híbrido	Equipado con dirección electroasistida, aire acondicionado, cámara de reversa y sistema de audio con Bluetooth, este Corolla también incluye características de seguridad como airbags y frenos ABS. Su diseño y tecnología lo hacen adecuado para la ciudad y viajes cortos, pelicula de vidrios y turecas de seguridad en las llantas
52	52	2026-11-16	08:06:03	descargado	1.8 CVT SEG	116900000	COP	14000	Automática	Gris	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
53	53	2026-11-16	08:06:10	descargado	1.8 XEi-L Automatico	144000000	COP	15109	Automática	Gris	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
54	54	2026-11-16	08:06:16	descargado	SE-G Automatico	132900000	COP	29149	Automática	Blanco	f	\N	Gasolina	El vendedor no incluyó una descripción del producto.
55	55	2026-11-16	08:06:21	descargado	1.8 CVT SEG	116900000	COP	14000	Automática	Gris	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
56	56	2026-11-16	08:06:27	descargado	1.8 CVT SEG	141900000	COP	25543	Automática	Blanco	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
57	57	2026-11-16	08:06:34	descargado	1.8 CVT SEG	152000000	COP	10200	Automática	Plateado	f	\N	Híbrido	Perfecto estado
58	58	2026-11-16	08:06:39	descargado	1.8 CVT SEG	129900000	COP	9000	Automática	Blanco	f	\N	Híbrido	Vehículo en Excelente estado, documentos al día, impuestos al día. Vendo o permuto por vehículo o motocicleta de menor valor.
59	59	2026-11-16	08:06:45	descargado	1.8 CVT SEG	122000000	COP	26000	Automática	Blanco	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
60	60	2026-11-16	08:06:52	descargado	1.8 XL-i Automatico	105900000	COP	20000	Automática	Blanco	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
62	1	2026-11-17	08:01:50	descargado	1.8 XE-i Automatico	84900000	COP	54984	Automática	Plateado	f	\N	Híbrido	🚗 ¡OPORTUNIDAD! Toyota Corolla Híbrido XEI 2022, en excelente estado, nunca siniestrado según historial. Elegante, cómodo y económico en combustible. Tecnología híbrida, ideal para ciudad y carretera. Placa terminada en 8. 💰 $84.900.000 negociables. ¡Un Toyota que combina confort, ahorro y confiabilidad! Agenda tu visita y conócelo.
63	2	2026-11-17	08:01:57	descargado	1.3 Mecanico	85000000	COP	35000	Mecánica	Gris	f	\N	Gasolina	Vehiculo en perfecto estado, A/C, direccionales habatibles, pernos de seguridad, seguro de direccionales, ventanas contrarobo, mantenimientos en cosecionario, único dueño, placa par.
64	3	2026-11-17	08:02:03	descargado	1.8 CVT SEG	94000000	COP	63000	Automática	Gris	t	\N	Híbrido	VEHICULO EN EXCELENTES CONDICIONES LISTO PARA TRASPASO VERSION FULL SEG 2022 63.000 SUN ROOF TAPICERIA EN CUERO APPLE CAR PLAY
65	4	2026-11-17	08:02:09	descargado	1.8 XE-i Automatico	98500000	COP	40000	Automática	Negro	f	\N	Híbrido	Toyota Corolla Hybrid Black Edition 2022, todos sus mantenimientos en ToyoNorte, al día de impuestos, perfecto estado, tapetes todo tiempo toyota, sin pico y placa, no enchufable, consumo muy bajo, silencioso y potente. Negociable. Soat y técnico hasta 2027. CarPlay, cámara trasera, sensores delanteros y traseros, Venta directa.
66	5	2026-11-17	08:02:15	descargado	\N	115000000	COP	20000	Automática	Blanco	t	\N	Híbrido	SEG Hybrid, full equipo, cuenta con siete airbags, película polarizada, cojinería en cuero, sunroof, no tiene pico y placa, se entrega con la revisión de los 20000 Km, venta directa, único dueño
67	7	2026-11-17	08:02:21	descargado	1.8 XE-i Automatico	95000000	COP	31800	Automática	Gris	f	\N	Híbrido	Excelente estado como nuevo, sin pico y placa , mtto de 30.000 km recien hecho, unico dueño, todos los mantenimientos realizados en carco, libre de papeles, no tiene pignoraciones.
68	8	2026-11-17	08:02:27	descargado	1.8 CVT XEI	95000000	COP	29000	Secuencial	Blanco	f	\N	Híbrido	Único dueño, perfecto estado, mantenimientos al día
69	9	2026-11-17	08:02:33	descargado	1.8 XE-i Automatico	89000000	COP	82000	Automática	Blanco	f	\N	Híbrido	Toyota Corolla 2022, 100% hibrido 82,000 km. Último mantenimiento realizado el de 80.000 km, llantas nuevas y con todos los mantenimientos directamente con Toyota conforme al libro de la marca. Motor de 1.8 litros y 136 hp, transmisión automática, dirección electroasistida y tracción delantera Autonomía hasta 90Km por galón. Control de estabilidad, sensores de estacionamiento, cámara de revers...
70	10	2026-11-17	08:02:39	descargado	XEI 2.0 Sedan Manual	83990000	COP	27952	Mecánica	Rojo	f	\N	Gasolina	2 llaves manules
71	11	2026-11-17	08:02:45	descargado	1.8 XE-i Automatico	87000000	COP	44000	Automática	Blanco	f	\N	Híbrido	Toyota Corolla híbrido modelo Chery 2022, llantas al 99%, SOAT recién comprado, papeles al día, listo para traspaso inmediato, puede hacerse revisión en CDA sin ningún problema, pasa sin problema, mantenimientos con Toyota Motor y único dueño, perfecto estado del carro.
72	14	2026-11-17	08:02:51	descargado	1.8 XEi-L Automatico	89900000	COP	52050	Automática	Blanco	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
73	15	2026-11-17	08:02:59	descargado	1.8 XEi-L Automatico	89900000	COP	52050	Automática	Blanco	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
74	16	2026-11-17	08:03:05	descargado	1.8 CVT XEI	107900000	COP	72300	Automática	Blanco	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
75	17	2026-11-17	08:03:11	descargado	1.8 CVT SEG	111700000	COP	85000	Automática	Plateado	f	\N	Híbrido	Llantas y Soat comprados en septiembre 2026, excelente estado, unico dueño
76	18	2026-11-17	08:03:16	descargado	1.8 XL-i Automatico	99900000	COP	46000	Automática	Gris	f	\N	Híbrido	Toyota Corolla XLI Hybrid 2023 | Único dueño | 46.000 km | Equipado con accesorios originales de agencia. ⭐ *Equipamiento y extras* * Sistema híbrido 1.8L Toyota, automático E * Llantas y rines originales *de la versión SEG*, instalados de agencia * Polarizado premium. * Tapetes termoformado * Protectores *originales* de retrovisores. * Estribos *originales* de agencia * Interior y exterior en ex...
77	19	2026-11-17	08:03:22	descargado	SE-G Automatico	110000000	COP	23000	Automática	Gris	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
78	20	2026-11-17	08:03:28	descargado	1.8 XL-i Automatico	101000000	COP	1000	Automática	Blanco	f	\N	Híbrido	2023 Toyota Corolla XLI 1.8 Hibrido. KILOMETRAJE es 14
79	21	2026-11-17	08:03:34	descargado	SE-G Automatico	100000000	COP	43000	Automática	Blanco	t	\N	Híbrido	🇨🇴🏁🇯🇵 Toyota Corolla SE-G Hybrid 2.023 ✅️ Listo para Traspaso. ✅ Único Dueño. ✅ 43.000 Km. ✅ Motor 1.8cc Híbrido. ️✅️ Automático. ️✅️ Full Equipo. ✅️ 7 Airbags. ✅️ Sunroof. ✅ Tapicería Cuero. ✅ Polarizado. ✅ Apple CarPlay/ Android Auto. ✅ Mantenimientos en Concesionario. ✅️ Matrícula Bogotá.
80	22	2026-11-17	08:03:39	descargado	1.8 Aut	114000000	COP	36000	Automática	Blanco	f	\N	Híbrido	Toyota Corolla Hibrido Seg Full equipo Modelo 2023 36.000 km Todo el mantenimiento certificado en concesionario
81	23	2026-11-17	08:03:45	descargado	1.8 XL-i Automatico	89900000	COP	22550	Automática	Blanco	f	\N	Híbrido	Híbrido full poco kilometraje, único conductor desde nuevo en trayectos urbanos, pintura con tratamiento porcelanizado, vidrios con película de seguridad, batería de 12v nueva para arranque, libro de mantenimientos original toyota con historial completo, solo en concesionario sus mantenimientos, excelente estado motor, exterior e interior, tapicería en tela, vidrios eléctricos, llave inteligente, ...
82	25	2026-11-17	08:03:51	descargado	1.8 XL-i Automatico	108000000	COP	34083	Automática	Gris	t	\N	Híbrido	Único dueño, accesorios originales.
83	26	2026-11-17	08:03:56	descargado	SE-G Automatico	145000000	COP	30000	Automática	Gris	t	\N	Híbrido	El vendedor no incluyó una descripción del producto.
84	27	2026-11-17	08:04:02	descargado	1.8 XL-i Automatico	89990000	COP	21940	Automática	Blanco	f	\N	Híbrido	A continuación encuentras muchos más detalles de nuestro WCAR: -Dueños 1 -Llaves 1 -Pasajeros 5 -Placa 3 Mosquera -Modelo 2023 -Recorrido 21,940 Km -Soat 31/03/2027 -Transmisión A/T -airbag -Rines de lujo -Luces Exploradoras -vidrios eléctricos -Espejos eléctricos -tipo de radio Original -Comandos en el timón -Cámara de reversa -sensor de reversa -Sensor de luz -Aire acondicionado -tipo de dire...
85	28	2026-11-17	08:04:08	descargado	1.8 XEi-L Automatico	99900000	COP	42000	Automática	Gris	f	\N	Híbrido	TOYOTA COROLLA XE-I HYBRID TP 1800CC 7AB ABS MOD 2023 🚙 Recorrido: 42.000km 🚙 Soat: 24/02/2026 🚙 Tecno: N/A 🚙 Placa: 1️⃣ 🚙 ABS 🚙 Airbags: 7 🚙 Mandos en el timón 🚙 Cámara de reversa 🚙 Sensores 🚙 Dirección: Eléctrica 🚙 Frenos: Disco/Disco 🚙 Faros: LED 🚙 Espejos eléctricos 2 🚙 Tracción: Delantera 🚙 Vidrios eléctricos: 4 🚙 Tapicería: Tela 🚙 Caja: Triptonica 🚙 Color: GRIS CELESTE ...
86	29	2026-11-17	08:04:14	descargado	1.8 XE-i Automatico	102000000	COP	21000	Automática	Blanco	f	\N	Híbrido	Vehículo en excelente estado, peritaje donde desee, recibo vehículo de menor valor
87	30	2026-11-17	08:04:20	descargado	1.8 CVT SEG	115000000	COP	20000	Automática	Plateado	t	\N	Híbrido	El vendedor no incluyó una descripción del producto.
88	31	2026-11-17	08:04:26	descargado	SE-G Automatico	118990000	COP	30000	Automática	Blanco	t	\N	Híbrido	Hermoso Toyota Corolla Sedan Blanco perlado Version mas equipada SEG. Cogineria en cuero, sunroof, todas las ayudas de conduccion, camara trasera y sensores de colision. Hibridacion Full (Consumo combustible promedio en ciudad 70 km/galon) Modelo 2023 con apenas 30.000 km Llantas nuevas (menos de 6 meses)
89	32	2026-11-17	08:04:49	descargado	GR-S 2.0 Deportivo Manual Gasolina	95900000	COP	37000	Automática	Rojo	f	\N	Gasolina	El vendedor no incluyó una descripción del producto.
90	33	2026-11-17	08:04:55	descargado	GR-S 2.0 Deportivo Manual Gasolina	90000000	COP	36000	Automática	Rojo	f	\N	Gasolina	excelente precio poco kilometraje, unico dueño, nunca chocado, seguro todo riesgo AXA, soat hasta agosto 2027, perfecto estado, mod 2023.
91	34	2026-11-17	08:05:01	descargado	SE-G Automatico	104900000	COP	39000	Automática	Rojo	f	\N	Híbrido	Toyota Corolla Híbrido 2023 SEG - Versión full equipo 39.900 km Mantenimientos en concesionario Sin reclamaciones Dos llaves Soat vigente Pasa peritaje Ubicado en ibague
92	36	2026-11-17	08:05:07	descargado	SE-G Automatico	112900000	COP	34000	Automática	Gris	f	\N	Híbrido	🚙 🚗Toyota Corolla SEG Modelo 2023 Híbrido 34.000km Automático Conineria de cuero #venta #Medellin #autos
93	37	2026-11-17	08:05:12	descargado	1.8 XE-i Automatico	92900000	COP	53000	Automática	Gris	f	\N	Híbrido	Medellin
94	38	2026-11-17	08:05:18	descargado	XEI 2.0 Sedan Automatico CVT	97000000	COP	59000	0	Gris	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
95	39	2026-11-17	08:05:24	descargado	GR-S 2.0 Deportivo Manual Gasolina	127900000	COP	25400	Automática	Blanco	f	\N	Gasolina	Toyota Corolla Cross GR-S 2.0cc - Modelo: 2023 - Kilometraje: 25.400kms - Transmisión: Automática - Tracción: 4x2 - Combustible: Gasolina - Soat: 26/03/2027 - Tecno: 20/02/2028 - Placa Finaliza: 9
96	40	2026-11-17	08:05:30	descargado	1.8 XE-i Automatico	85000000	COP	56879	Automática	Gris	f	\N	Híbrido	Toyota Corolla XEI HIBRIDO 2023 56.879km 1.8cc Automatico Cojineria cuero Vidrios y espejos electricos Mandos en el timon Pantalla tactil Camara reversa Rines de lujo Llantas 70% Soat 24-junio-2027 Tecno 24-junio-2028
97	41	2026-11-17	08:05:35	descargado	1.8 XE-i Automatico	102000000	COP	53400	Automática	Otro	f	\N	Híbrido	¿Buscas confort, tecnología y ahorro? Vendo mi Toyota Corolla XEI Híbrido modelo 2023, una joya de la ingeniería japonesa. Con solo 53.400 km de recorrido. Motor 1.800cc- Automatico - sistema hibrido (Autorecargable) - 7 airbags - frenos ABS - silleteria de cuero - con asistencia y ayudas para la conducción - mandos en el timon - espejos electricos, vidrios electricos - color gris celeste - Pantal...
98	43	2026-11-17	08:05:41	descargado	1.8	115000000	COP	25700	Automática	Blanco	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
99	44	2026-11-17	08:05:47	descargado	1.8 CVT SEG	108000000	COP	63000	Automática	Plateado	f	\N	Híbrido	Toyota Corolla Seg Hibrido
100	45	2026-11-17	08:05:53	descargado	1.8 XE-i Automatico	113000000	COP	32000	Automática	Gris	f	\N	Híbrido	Toyota Corolla 2024 32.000 Km Perfecto estado 113.000.000 Negociables
101	46	2026-11-17	08:05:58	descargado	1.8 XE-i Automatico	123000000	COP	5000	Automática	Rojo	f	\N	Híbrido	Esperctacular bien cuidado con cojineria en cuero, UNICO DUEÑO full equipo HIBRIDO vendo directamente negociable
102	47	2026-11-17	08:06:04	descargado	1.8 CVT XEI	115000000	COP	29000	Automática	Plateado	f	\N	Híbrido	Pelicula de Seguridad en los vidrios Pernos de seguridad en las llantas
103	48	2026-11-17	08:06:10	descargado	1.8 CVT XEI	106900000	COP	30000	Automática	Blanco	f	\N	Híbrido	Único dueño. Medellín hibrido todo en cocesiy
104	50	2026-11-17	08:06:16	descargado	\N	145500000	COP	10000	Automática	Gris	f	\N	Híbrido	Camioneta prácticamente nueva. Precio negociable. Es la versión básica aunque lo suficientemente equipada.
105	51	2026-11-17	08:06:21	descargado	1.8 XE-i Automatico	118000000	COP	4151	Automática	Lila	f	\N	Híbrido	Equipado con dirección electroasistida, aire acondicionado, cámara de reversa y sistema de audio con Bluetooth, este Corolla también incluye características de seguridad como airbags y frenos ABS. Su diseño y tecnología lo hacen adecuado para la ciudad y viajes cortos, pelicula de vidrios y turecas de seguridad en las llantas
106	52	2026-11-17	08:06:28	descargado	1.8 CVT SEG	116900000	COP	14000	Automática	Gris	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
107	53	2026-11-17	08:06:33	descargado	1.8 XEi-L Automatico	144000000	COP	15109	Automática	Gris	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
108	54	2026-11-17	08:06:39	descargado	SE-G Automatico	132900000	COP	29149	Automática	Blanco	f	\N	Gasolina	El vendedor no incluyó una descripción del producto.
109	56	2026-11-17	08:06:45	descargado	1.8 CVT SEG	141900000	COP	25543	Automática	Blanco	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
110	57	2026-11-17	08:06:51	descargado	1.8 CVT SEG	152000000	COP	10200	Automática	Plateado	f	\N	Híbrido	Perfecto estado
111	58	2026-11-17	08:06:56	descargado	1.8 CVT SEG	129900000	COP	9000	Automática	Blanco	f	\N	Híbrido	Vehículo en Excelente estado, documentos al día, impuestos al día. Vendo o permuto por vehículo o motocicleta de menor valor.
112	59	2026-11-17	08:07:02	descargado	1.8 CVT SEG	122000000	COP	26000	Automática	Blanco	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
113	60	2026-11-17	08:07:08	descargado	1.8 XL-i Automatico	105900000	COP	20000	Automática	Blanco	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
114	61	2026-11-17	08:07:14	descargado	1.8	134000000	COP	1600	Automática	Gris	f	\N	Híbrido	Carro casi nuevo Toyota Corolla 1.8 Hev Seg kilometraje 1.600 modelo 2026
115	6	2026-11-17	\N	no_encontrado	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
116	12	2026-11-17	\N	no_encontrado	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
117	13	2026-11-17	\N	no_encontrado	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
118	24	2026-11-17	\N	no_encontrado	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
119	35	2026-11-17	\N	no_encontrado	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
120	42	2026-11-17	\N	no_encontrado	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
121	49	2026-11-17	\N	no_encontrado	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
122	55	2026-11-17	\N	no_encontrado	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
123	1	2026-11-18	08:00:52	descargado	1.8 XE-i Automatico	84900000	COP	54984	Automática	Plateado	f	\N	Híbrido	🚗 ¡OPORTUNIDAD! Toyota Corolla Híbrido XEI 2022, en excelente estado, nunca siniestrado según historial. Elegante, cómodo y económico en combustible. Tecnología híbrida, ideal para ciudad y carretera. Placa terminada en 8. 💰 $84.900.000 negociables. ¡Un Toyota que combina confort, ahorro y confiabilidad! Agenda tu visita y conócelo.
124	2	2026-11-18	08:00:59	descargado	1.3 Mecanico	85000000	COP	35000	Mecánica	Gris	f	\N	Gasolina	Vehiculo en perfecto estado, A/C, direccionales habatibles, pernos de seguridad, seguro de direccionales, ventanas contrarobo, mantenimientos en cosecionario, único dueño, placa par.
125	3	2026-11-18	08:01:07	descargado	1.8 CVT SEG	94000000	COP	63000	Automática	Gris	t	\N	Híbrido	VEHICULO EN EXCELENTES CONDICIONES LISTO PARA TRASPASO VERSION FULL SEG 2022 63.000 SUN ROOF TAPICERIA EN CUERO APPLE CAR PLAY
126	4	2026-11-18	08:01:12	descargado	1.8 XE-i Automatico	98500000	COP	40000	Automática	Negro	f	\N	Híbrido	Toyota Corolla Hybrid Black Edition 2022, todos sus mantenimientos en ToyoNorte, al día de impuestos, perfecto estado, tapetes todo tiempo toyota, sin pico y placa, no enchufable, consumo muy bajo, silencioso y potente. Negociable. Soat y técnico hasta 2027. CarPlay, cámara trasera, sensores delanteros y traseros, Venta directa.
127	5	2026-11-18	08:01:18	descargado	\N	115000000	COP	20000	Automática	Blanco	t	\N	Híbrido	SEG Hybrid, full equipo, cuenta con siete airbags, película polarizada, cojinería en cuero, sunroof, no tiene pico y placa, se entrega con la revisión de los 20000 Km, venta directa, único dueño
128	7	2026-11-18	08:01:24	descargado	1.8 XE-i Automatico	95000000	COP	31800	Automática	Gris	f	\N	Híbrido	Excelente estado como nuevo, sin pico y placa , mtto de 30.000 km recien hecho, unico dueño, todos los mantenimientos realizados en carco, libre de papeles, no tiene pignoraciones.
129	8	2026-11-18	08:01:30	descargado	1.8 CVT XEI	95000000	COP	29000	Secuencial	Blanco	f	\N	Híbrido	Único dueño, perfecto estado, mantenimientos al día
130	9	2026-11-18	08:01:36	descargado	1.8 XE-i Automatico	89000000	COP	82000	Automática	Blanco	f	\N	Híbrido	Toyota Corolla 2022, 100% hibrido 82,000 km. Último mantenimiento realizado el de 80.000 km, llantas nuevas y con todos los mantenimientos directamente con Toyota conforme al libro de la marca. Motor de 1.8 litros y 136 hp, transmisión automática, dirección electroasistida y tracción delantera Autonomía hasta 90Km por galón. Control de estabilidad, sensores de estacionamiento, cámara de revers...
131	10	2026-11-18	08:01:41	descargado	XEI 2.0 Sedan Manual	83990000	COP	27952	Mecánica	Rojo	f	\N	Gasolina	2 llaves manules
132	11	2026-11-18	08:01:48	descargado	1.8 XE-i Automatico	87000000	COP	44000	Automática	Blanco	f	\N	Híbrido	Toyota Corolla híbrido modelo Chery 2022, llantas al 99%, SOAT recién comprado, papeles al día, listo para traspaso inmediato, puede hacerse revisión en CDA sin ningún problema, pasa sin problema, mantenimientos con Toyota Motor y único dueño, perfecto estado del carro.
133	12	2026-11-18	08:01:54	descargado	1.8	119900000	COP	55000	Automática	Blanco	f	\N	Híbrido	Corolla Seg blindaje2 híbrido
134	13	2026-11-18	08:01:59	descargado	1.8 CVT SEG	91900000	COP	68000	Automática	Blanco	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
135	14	2026-11-18	08:02:06	descargado	1.8 XEi-L Automatico	89900000	COP	52050	Automática	Blanco	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
136	15	2026-11-18	08:02:12	descargado	1.8 XEi-L Automatico	89900000	COP	52050	Automática	Blanco	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
137	16	2026-11-18	08:02:17	descargado	1.8 CVT XEI	107900000	COP	72300	Automática	Blanco	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
138	17	2026-11-18	08:02:23	descargado	1.8 CVT SEG	111700000	COP	85000	Automática	Plateado	f	\N	Híbrido	Llantas y Soat comprados en septiembre 2026, excelente estado, unico dueño
139	18	2026-11-18	08:02:29	descargado	1.8 XL-i Automatico	99900000	COP	46000	Automática	Gris	f	\N	Híbrido	Toyota Corolla XLI Hybrid 2023 | Único dueño | 46.000 km | Equipado con accesorios originales de agencia. ⭐ *Equipamiento y extras* * Sistema híbrido 1.8L Toyota, automático E * Llantas y rines originales *de la versión SEG*, instalados de agencia * Polarizado premium. * Tapetes termoformado * Protectores *originales* de retrovisores. * Estribos *originales* de agencia * Interior y exterior en ex...
140	19	2026-11-18	08:02:35	descargado	SE-G Automatico	110000000	COP	23000	Automática	Gris	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
141	20	2026-11-18	08:02:40	descargado	1.8 XL-i Automatico	101000000	COP	1000	Automática	Blanco	f	\N	Híbrido	2023 Toyota Corolla XLI 1.8 Hibrido. KILOMETRAJE es 14
142	21	2026-11-18	08:02:46	descargado	SE-G Automatico	100000000	COP	43000	Automática	Blanco	t	\N	Híbrido	🇨🇴🏁🇯🇵 Toyota Corolla SE-G Hybrid 2.023 ✅️ Listo para Traspaso. ✅ Único Dueño. ✅ 43.000 Km. ✅ Motor 1.8cc Híbrido. ️✅️ Automático. ️✅️ Full Equipo. ✅️ 7 Airbags. ✅️ Sunroof. ✅ Tapicería Cuero. ✅ Polarizado. ✅ Apple CarPlay/ Android Auto. ✅ Mantenimientos en Concesionario. ✅️ Matrícula Bogotá.
143	22	2026-11-18	08:02:52	descargado	1.8 Aut	114000000	COP	36000	Automática	Blanco	f	\N	Híbrido	Toyota Corolla Hibrido Seg Full equipo Modelo 2023 36.000 km Todo el mantenimiento certificado en concesionario
144	23	2026-11-18	08:02:58	descargado	1.8 XL-i Automatico	89900000	COP	22550	Automática	Blanco	f	\N	Híbrido	Híbrido full poco kilometraje, único conductor desde nuevo en trayectos urbanos, pintura con tratamiento porcelanizado, vidrios con película de seguridad, batería de 12v nueva para arranque, libro de mantenimientos original toyota con historial completo, solo en concesionario sus mantenimientos, excelente estado motor, exterior e interior, tapicería en tela, vidrios eléctricos, llave inteligente, ...
145	25	2026-11-18	08:03:04	descargado	1.8 XL-i Automatico	108000000	COP	34083	Automática	Gris	t	\N	Híbrido	Único dueño, accesorios originales.
146	26	2026-11-18	08:03:10	descargado	SE-G Automatico	145000000	COP	30000	Automática	Gris	t	\N	Híbrido	El vendedor no incluyó una descripción del producto.
147	27	2026-11-18	08:03:15	descargado	1.8 XL-i Automatico	89990000	COP	21940	Automática	Blanco	f	\N	Híbrido	A continuación encuentras muchos más detalles de nuestro WCAR: -Dueños 1 -Llaves 1 -Pasajeros 5 -Placa 3 Mosquera -Modelo 2023 -Recorrido 21,940 Km -Soat 31/03/2027 -Transmisión A/T -airbag -Rines de lujo -Luces Exploradoras -vidrios eléctricos -Espejos eléctricos -tipo de radio Original -Comandos en el timón -Cámara de reversa -sensor de reversa -Sensor de luz -Aire acondicionado -tipo de dire...
148	28	2026-11-18	08:03:21	descargado	1.8 XEi-L Automatico	99900000	COP	42000	Automática	Gris	f	\N	Híbrido	TOYOTA COROLLA XE-I HYBRID TP 1800CC 7AB ABS MOD 2023 🚙 Recorrido: 42.000km 🚙 Soat: 24/02/2026 🚙 Tecno: N/A 🚙 Placa: 1️⃣ 🚙 ABS 🚙 Airbags: 7 🚙 Mandos en el timón 🚙 Cámara de reversa 🚙 Sensores 🚙 Dirección: Eléctrica 🚙 Frenos: Disco/Disco 🚙 Faros: LED 🚙 Espejos eléctricos 2 🚙 Tracción: Delantera 🚙 Vidrios eléctricos: 4 🚙 Tapicería: Tela 🚙 Caja: Triptonica 🚙 Color: GRIS CELESTE ...
149	29	2026-11-18	08:03:27	descargado	1.8 XE-i Automatico	102000000	COP	21000	Automática	Blanco	f	\N	Híbrido	Vehículo en excelente estado, peritaje donde desee, recibo vehículo de menor valor
150	30	2026-11-18	08:03:33	descargado	1.8 CVT SEG	115000000	COP	20000	Automática	Plateado	t	\N	Híbrido	El vendedor no incluyó una descripción del producto.
213	32	2026-11-19	08:04:47	descargado	GR-S 2.0 Deportivo Manual Gasolina	95900000	COP	37000	Automática	Rojo	f	\N	Gasolina	El vendedor no incluyó una descripción del producto.
151	31	2026-11-18	08:03:39	descargado	SE-G Automatico	118990000	COP	30000	Automática	Blanco	t	\N	Híbrido	Hermoso Toyota Corolla Sedan Blanco perlado Version mas equipada SEG. Cogineria en cuero, sunroof, todas las ayudas de conduccion, camara trasera y sensores de colision. Hibridacion Full (Consumo combustible promedio en ciudad 70 km/galon) Modelo 2023 con apenas 30.000 km Llantas nuevas (menos de 6 meses)
152	33	2026-11-18	08:03:45	descargado	GR-S 2.0 Deportivo Manual Gasolina	90000000	COP	36000	Automática	Rojo	f	\N	Gasolina	excelente precio poco kilometraje, unico dueño, nunca chocado, seguro todo riesgo AXA, soat hasta agosto 2027, perfecto estado, mod 2023.
153	34	2026-11-18	08:03:50	descargado	SE-G Automatico	104900000	COP	39000	Automática	Rojo	f	\N	Híbrido	Toyota Corolla Híbrido 2023 SEG - Versión full equipo 39.900 km Mantenimientos en concesionario Sin reclamaciones Dos llaves Soat vigente Pasa peritaje Ubicado en ibague
154	146	2026-11-18	08:03:56	descargado	SE-G Automatico	91000000	COP	85000	Secuencial	Plateado	f	\N	Híbrido	VENDO TOYOTA COROLLA 2023 HYBRID SE-G 85000 kms LLANTAS NUEVAS YOKOHAMA MANTENIMIENTOS PAGOS HASTA LOS 95' km VEHICULO EN GARANTÍA!!! TODOS LOS SERVICIOS AL DÍA Y EN YOKOMOTOR. PASTAS TRASERAS NUEVAS!!! PASA PERITAJE ESTA ASEGURADO. Información WhatsApp
155	35	2026-11-18	08:04:02	descargado	1.8 CVT SEG	88900000	COP	56000	Automática	Gris	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
156	36	2026-11-18	08:04:08	descargado	SE-G Automatico	112900000	COP	34000	Automática	Gris	f	\N	Híbrido	🚙 🚗Toyota Corolla SEG Modelo 2023 Híbrido 34.000km Automático Conineria de cuero #venta #Medellin #autos
157	37	2026-11-18	08:04:14	descargado	1.8 XE-i Automatico	92900000	COP	53000	Automática	Gris	f	\N	Híbrido	Medellin
158	38	2026-11-18	08:04:19	descargado	XEI 2.0 Sedan Automatico CVT	97000000	COP	59000	0	Gris	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
159	39	2026-11-18	08:04:25	descargado	GR-S 2.0 Deportivo Manual Gasolina	127900000	COP	25400	Automática	Blanco	f	\N	Gasolina	Toyota Corolla Cross GR-S 2.0cc - Modelo: 2023 - Kilometraje: 25.400kms - Transmisión: Automática - Tracción: 4x2 - Combustible: Gasolina - Soat: 26/03/2027 - Tecno: 20/02/2028 - Placa Finaliza: 9
160	40	2026-11-18	08:04:31	descargado	1.8 XE-i Automatico	85000000	COP	56879	Automática	Gris	f	\N	Híbrido	Toyota Corolla XEI HIBRIDO 2023 56.879km 1.8cc Automatico Cojineria cuero Vidrios y espejos electricos Mandos en el timon Pantalla tactil Camara reversa Rines de lujo Llantas 70% Soat 24-junio-2027 Tecno 24-junio-2028
161	41	2026-11-18	08:04:37	descargado	1.8 XE-i Automatico	102000000	COP	53400	Automática	Otro	f	\N	Híbrido	¿Buscas confort, tecnología y ahorro? Vendo mi Toyota Corolla XEI Híbrido modelo 2023, una joya de la ingeniería japonesa. Con solo 53.400 km de recorrido. Motor 1.800cc- Automatico - sistema hibrido (Autorecargable) - 7 airbags - frenos ABS - silleteria de cuero - con asistencia y ayudas para la conducción - mandos en el timon - espejos electricos, vidrios electricos - color gris celeste - Pantal...
162	42	2026-11-18	08:04:43	descargado	1.8 CVT SEG	106900000	COP	48000	Automática	Gris	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
163	43	2026-11-18	08:04:48	descargado	1.8	115000000	COP	25700	Automática	Blanco	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
164	44	2026-11-18	08:04:56	descargado	1.8 CVT SEG	108000000	COP	63000	Automática	Plateado	f	\N	Híbrido	Toyota Corolla Seg Hibrido
165	45	2026-11-18	08:05:02	descargado	1.8 XE-i Automatico	113000000	COP	32000	Automática	Gris	f	\N	Híbrido	Toyota Corolla 2024 32.000 Km Perfecto estado 113.000.000 Negociables
166	46	2026-11-18	08:05:09	descargado	1.8 XE-i Automatico	123000000	COP	5000	Automática	Rojo	f	\N	Híbrido	Esperctacular bien cuidado con cojineria en cuero, UNICO DUEÑO full equipo HIBRIDO vendo directamente negociable
167	47	2026-11-18	08:05:15	descargado	1.8 CVT XEI	115000000	COP	29000	Automática	Plateado	f	\N	Híbrido	Pelicula de Seguridad en los vidrios Pernos de seguridad en las llantas
168	48	2026-11-18	08:05:21	descargado	1.8 CVT XEI	106900000	COP	30000	Automática	Blanco	f	\N	Híbrido	Único dueño. Medellín hibrido todo en cocesiy
169	50	2026-11-18	08:05:26	descargado	\N	145500000	COP	10000	Automática	Gris	f	\N	Híbrido	Camioneta prácticamente nueva. Precio negociable. Es la versión básica aunque lo suficientemente equipada.
170	51	2026-11-18	08:05:33	descargado	1.8 XE-i Automatico	118000000	COP	4151	Automática	Lila	f	\N	Híbrido	Equipado con dirección electroasistida, aire acondicionado, cámara de reversa y sistema de audio con Bluetooth, este Corolla también incluye características de seguridad como airbags y frenos ABS. Su diseño y tecnología lo hacen adecuado para la ciudad y viajes cortos, pelicula de vidrios y turecas de seguridad en las llantas
171	52	2026-11-18	08:05:39	descargado	1.8 CVT SEG	116900000	COP	14000	Automática	Gris	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
172	53	2026-11-18	08:05:44	descargado	1.8 XEi-L Automatico	144000000	COP	15109	Automática	Gris	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
173	54	2026-11-18	08:05:51	descargado	SE-G Automatico	132900000	COP	29149	Automática	Blanco	f	\N	Gasolina	El vendedor no incluyó una descripción del producto.
174	56	2026-11-18	08:05:57	descargado	1.8 CVT SEG	141900000	COP	25543	Automática	Blanco	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
175	57	2026-11-18	08:06:03	descargado	1.8 CVT SEG	152000000	COP	10200	Automática	Plateado	f	\N	Híbrido	Perfecto estado
176	58	2026-11-18	08:06:10	descargado	1.8 CVT SEG	129900000	COP	9000	Automática	Blanco	f	\N	Híbrido	Vehículo en Excelente estado, documentos al día, impuestos al día. Vendo o permuto por vehículo o motocicleta de menor valor.
177	59	2026-11-18	08:06:16	descargado	1.8 CVT SEG	122000000	COP	26000	Automática	Blanco	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
178	60	2026-11-18	08:06:21	descargado	1.8 XL-i Automatico	105900000	COP	20000	Automática	Blanco	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
179	61	2026-11-18	08:06:27	descargado	1.8	134000000	COP	1600	Automática	Gris	f	\N	Híbrido	Carro casi nuevo Toyota Corolla 1.8 Hev Seg kilometraje 1.600 modelo 2026
180	6	2026-11-18	\N	no_encontrado	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
181	24	2026-11-18	\N	no_encontrado	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
182	49	2026-11-18	\N	no_encontrado	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
183	55	2026-11-18	\N	no_encontrado	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
184	32	2026-11-18	\N	no_encontrado	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
185	1	2026-11-19	08:01:57	descargado	1.8 XE-i Automatico	84900000	COP	54984	Automática	Plateado	f	\N	Híbrido	🚗 ¡OPORTUNIDAD! Toyota Corolla Híbrido XEI 2022, en excelente estado, nunca siniestrado según historial. Elegante, cómodo y económico en combustible. Tecnología híbrida, ideal para ciudad y carretera. Placa terminada en 8. 💰 $84.900.000 negociables. ¡Un Toyota que combina confort, ahorro y confiabilidad! Agenda tu visita y conócelo.
186	2	2026-11-19	08:02:03	descargado	1.3 Mecanico	85000000	COP	35000	Mecánica	Gris	f	\N	Gasolina	Vehiculo en perfecto estado, A/C, direccionales habatibles, pernos de seguridad, seguro de direccionales, ventanas contrarobo, mantenimientos en cosecionario, único dueño, placa par.
187	3	2026-11-19	08:02:09	descargado	1.8 CVT SEG	94000000	COP	63000	Automática	Gris	t	\N	Híbrido	VEHICULO EN EXCELENTES CONDICIONES LISTO PARA TRASPASO VERSION FULL SEG 2022 63.000 SUN ROOF TAPICERIA EN CUERO APPLE CAR PLAY
188	4	2026-11-19	08:02:16	descargado	1.8 XE-i Automatico	98500000	COP	40000	Automática	Negro	f	\N	Híbrido	Toyota Corolla Hybrid Black Edition 2022, todos sus mantenimientos en ToyoNorte, al día de impuestos, perfecto estado, tapetes todo tiempo toyota, sin pico y placa, no enchufable, consumo muy bajo, silencioso y potente. Negociable. Soat y técnico hasta 2027. CarPlay, cámara trasera, sensores delanteros y traseros, Venta directa.
189	5	2026-11-19	08:02:22	descargado	\N	115000000	COP	20000	Automática	Blanco	t	\N	Híbrido	SEG Hybrid, full equipo, cuenta con siete airbags, película polarizada, cojinería en cuero, sunroof, no tiene pico y placa, se entrega con la revisión de los 20000 Km, venta directa, único dueño
190	7	2026-11-19	08:02:28	descargado	1.8 XE-i Automatico	95000000	COP	31800	Automática	Gris	f	\N	Híbrido	Excelente estado como nuevo, sin pico y placa , mtto de 30.000 km recien hecho, unico dueño, todos los mantenimientos realizados en carco, libre de papeles, no tiene pignoraciones.
191	8	2026-11-19	08:02:33	descargado	1.8 CVT XEI	95000000	COP	29000	Secuencial	Blanco	f	\N	Híbrido	Único dueño, perfecto estado, mantenimientos al día
192	9	2026-11-19	08:02:39	descargado	1.8 XE-i Automatico	89000000	COP	82000	Automática	Blanco	f	\N	Híbrido	Toyota Corolla 2022, 100% hibrido 82,000 km. Último mantenimiento realizado el de 80.000 km, llantas nuevas y con todos los mantenimientos directamente con Toyota conforme al libro de la marca. Motor de 1.8 litros y 136 hp, transmisión automática, dirección electroasistida y tracción delantera Autonomía hasta 90Km por galón. Control de estabilidad, sensores de estacionamiento, cámara de revers...
193	10	2026-11-19	08:02:45	descargado	XEI 2.0 Sedan Manual	83990000	COP	27952	Mecánica	Rojo	f	\N	Gasolina	2 llaves manules
194	11	2026-11-19	08:02:52	descargado	1.8 XE-i Automatico	87000000	COP	44000	Automática	Blanco	f	\N	Híbrido	Toyota Corolla híbrido modelo Chery 2022, llantas al 99%, SOAT recién comprado, papeles al día, listo para traspaso inmediato, puede hacerse revisión en CDA sin ningún problema, pasa sin problema, mantenimientos con Toyota Motor y único dueño, perfecto estado del carro.
195	12	2026-11-19	08:02:58	descargado	1.8	119900000	COP	55000	Automática	Blanco	f	\N	Híbrido	Corolla Seg blindaje2 híbrido
196	13	2026-11-19	08:03:04	descargado	1.8 CVT SEG	91900000	COP	68000	Automática	Blanco	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
197	14	2026-11-19	08:03:10	descargado	1.8 XEi-L Automatico	89900000	COP	52050	Automática	Blanco	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
198	15	2026-11-19	08:03:16	descargado	1.8 XEi-L Automatico	89900000	COP	52050	Automática	Blanco	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
199	16	2026-11-19	08:03:22	descargado	1.8 CVT XEI	107900000	COP	72300	Automática	Blanco	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
200	17	2026-11-19	08:03:31	descargado	1.8 CVT SEG	111700000	COP	85000	Automática	Plateado	f	\N	Híbrido	Llantas y Soat comprados en septiembre 2026, excelente estado, unico dueño
201	18	2026-11-19	08:03:37	descargado	1.8 XL-i Automatico	99900000	COP	46000	Automática	Gris	f	\N	Híbrido	Toyota Corolla XLI Hybrid 2023 | Único dueño | 46.000 km | Equipado con accesorios originales de agencia. ⭐ *Equipamiento y extras* * Sistema híbrido 1.8L Toyota, automático E * Llantas y rines originales *de la versión SEG*, instalados de agencia * Polarizado premium. * Tapetes termoformado * Protectores *originales* de retrovisores. * Estribos *originales* de agencia * Interior y exterior en ex...
202	19	2026-11-19	08:03:42	descargado	SE-G Automatico	110000000	COP	23000	Automática	Gris	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
203	20	2026-11-19	08:03:49	descargado	1.8 XL-i Automatico	101000000	COP	1000	Automática	Blanco	f	\N	Híbrido	2023 Toyota Corolla XLI 1.8 Hibrido. KILOMETRAJE es 14
204	21	2026-11-19	08:03:55	descargado	SE-G Automatico	100000000	COP	43000	Automática	Blanco	t	\N	Híbrido	🇨🇴🏁🇯🇵 Toyota Corolla SE-G Hybrid 2.023 ✅️ Listo para Traspaso. ✅ Único Dueño. ✅ 43.000 Km. ✅ Motor 1.8cc Híbrido. ️✅️ Automático. ️✅️ Full Equipo. ✅️ 7 Airbags. ✅️ Sunroof. ✅ Tapicería Cuero. ✅ Polarizado. ✅ Apple CarPlay/ Android Auto. ✅ Mantenimientos en Concesionario. ✅️ Matrícula Bogotá.
205	22	2026-11-19	08:04:00	descargado	1.8 Aut	114000000	COP	36000	Automática	Blanco	f	\N	Híbrido	Toyota Corolla Hibrido Seg Full equipo Modelo 2023 36.000 km Todo el mantenimiento certificado en concesionario
206	23	2026-11-19	08:04:06	descargado	1.8 XL-i Automatico	89900000	COP	22550	Automática	Blanco	f	\N	Híbrido	Híbrido full poco kilometraje, único conductor desde nuevo en trayectos urbanos, pintura con tratamiento porcelanizado, vidrios con película de seguridad, batería de 12v nueva para arranque, libro de mantenimientos original toyota con historial completo, solo en concesionario sus mantenimientos, excelente estado motor, exterior e interior, tapicería en tela, vidrios eléctricos, llave inteligente, ...
207	25	2026-11-19	08:04:12	descargado	1.8 XL-i Automatico	108000000	COP	34083	Automática	Gris	t	\N	Híbrido	Único dueño, accesorios originales.
208	26	2026-11-19	08:04:18	descargado	SE-G Automatico	145000000	COP	30000	Automática	Gris	t	\N	Híbrido	El vendedor no incluyó una descripción del producto.
209	28	2026-11-19	08:04:24	descargado	1.8 XEi-L Automatico	99900000	COP	42000	Automática	Gris	f	\N	Híbrido	TOYOTA COROLLA XE-I HYBRID TP 1800CC 7AB ABS MOD 2023 🚙 Recorrido: 42.000km 🚙 Soat: 24/02/2026 🚙 Tecno: N/A 🚙 Placa: 1️⃣ 🚙 ABS 🚙 Airbags: 7 🚙 Mandos en el timón 🚙 Cámara de reversa 🚙 Sensores 🚙 Dirección: Eléctrica 🚙 Frenos: Disco/Disco 🚙 Faros: LED 🚙 Espejos eléctricos 2 🚙 Tracción: Delantera 🚙 Vidrios eléctricos: 4 🚙 Tapicería: Tela 🚙 Caja: Triptonica 🚙 Color: GRIS CELESTE ...
210	29	2026-11-19	08:04:30	descargado	1.8 XE-i Automatico	102000000	COP	21000	Automática	Blanco	f	\N	Híbrido	Vehículo en excelente estado, peritaje donde desee, recibo vehículo de menor valor
211	30	2026-11-19	08:04:36	descargado	1.8 CVT SEG	115000000	COP	20000	Automática	Plateado	t	\N	Híbrido	El vendedor no incluyó una descripción del producto.
212	31	2026-11-19	08:04:42	descargado	SE-G Automatico	118990000	COP	30000	Automática	Blanco	t	\N	Híbrido	Hermoso Toyota Corolla Sedan Blanco perlado Version mas equipada SEG. Cogineria en cuero, sunroof, todas las ayudas de conduccion, camara trasera y sensores de colision. Hibridacion Full (Consumo combustible promedio en ciudad 70 km/galon) Modelo 2023 con apenas 30.000 km Llantas nuevas (menos de 6 meses)
214	33	2026-11-19	08:04:53	descargado	GR-S 2.0 Deportivo Manual Gasolina	90000000	COP	36000	Automática	Rojo	f	\N	Gasolina	excelente precio poco kilometraje, unico dueño, nunca chocado, seguro todo riesgo AXA, soat hasta agosto 2027, perfecto estado, mod 2023.
215	34	2026-11-19	08:04:59	descargado	SE-G Automatico	104900000	COP	39000	Automática	Rojo	f	\N	Híbrido	Toyota Corolla Híbrido 2023 SEG - Versión full equipo 39.900 km Mantenimientos en concesionario Sin reclamaciones Dos llaves Soat vigente Pasa peritaje Ubicado en ibague
216	146	2026-11-19	08:05:05	descargado	SE-G Automatico	91000000	COP	85000	Secuencial	Plateado	f	\N	Híbrido	VENDO TOYOTA COROLLA 2023 HYBRID SE-G 85000 kms LLANTAS NUEVAS YOKOHAMA MANTENIMIENTOS PAGOS HASTA LOS 95' km VEHICULO EN GARANTÍA!!! TODOS LOS SERVICIOS AL DÍA Y EN YOKOMOTOR. PASTAS TRASERAS NUEVAS!!! PASA PERITAJE ESTA ASEGURADO. Información WhatsApp
217	35	2026-11-19	08:05:11	descargado	1.8 CVT SEG	88900000	COP	56000	Automática	Gris	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
218	205	2026-11-19	08:05:16	descargado	SE-G Automatico	95900000	COP	85000	Automática	Gris	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
219	36	2026-11-19	08:05:22	descargado	SE-G Automatico	112900000	COP	34000	Automática	Gris	f	\N	Híbrido	🚙 🚗Toyota Corolla SEG Modelo 2023 Híbrido 34.000km Automático Conineria de cuero #venta #Medellin #autos
220	37	2026-11-19	08:05:29	descargado	1.8 XE-i Automatico	92900000	COP	53000	Automática	Gris	f	\N	Híbrido	Medellin
221	38	2026-11-19	08:05:35	descargado	XEI 2.0 Sedan Automatico CVT	97000000	COP	59000	0	Gris	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
222	39	2026-11-19	08:05:41	descargado	GR-S 2.0 Deportivo Manual Gasolina	127900000	COP	25400	Automática	Blanco	f	\N	Gasolina	Toyota Corolla Cross GR-S 2.0cc - Modelo: 2023 - Kilometraje: 25.400kms - Transmisión: Automática - Tracción: 4x2 - Combustible: Gasolina - Soat: 26/03/2027 - Tecno: 20/02/2028 - Placa Finaliza: 9
223	40	2026-11-19	08:05:47	descargado	1.8 XE-i Automatico	85000000	COP	56879	Automática	Gris	f	\N	Híbrido	Toyota Corolla XEI HIBRIDO 2023 56.879km 1.8cc Automatico Cojineria cuero Vidrios y espejos electricos Mandos en el timon Pantalla tactil Camara reversa Rines de lujo Llantas 70% Soat 24-junio-2027 Tecno 24-junio-2028
224	41	2026-11-19	08:05:53	descargado	1.8 XE-i Automatico	102000000	COP	53400	Automática	Otro	f	\N	Híbrido	¿Buscas confort, tecnología y ahorro? Vendo mi Toyota Corolla XEI Híbrido modelo 2023, una joya de la ingeniería japonesa. Con solo 53.400 km de recorrido. Motor 1.800cc- Automatico - sistema hibrido (Autorecargable) - 7 airbags - frenos ABS - silleteria de cuero - con asistencia y ayudas para la conducción - mandos en el timon - espejos electricos, vidrios electricos - color gris celeste - Pantal...
225	42	2026-11-19	08:05:59	descargado	1.8 CVT SEG	106900000	COP	48000	Automática	Gris	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
226	43	2026-11-19	08:06:04	descargado	1.8	115000000	COP	25700	Automática	Blanco	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
227	44	2026-11-19	08:06:10	descargado	1.8 CVT SEG	108000000	COP	63000	Automática	Plateado	f	\N	Híbrido	Toyota Corolla Seg Hibrido
228	45	2026-11-19	08:06:16	descargado	1.8 XE-i Automatico	113000000	COP	32000	Automática	Gris	f	\N	Híbrido	Toyota Corolla 2024 32.000 Km Perfecto estado 113.000.000 Negociables
229	46	2026-11-19	08:06:22	descargado	1.8 XE-i Automatico	123000000	COP	5000	Automática	Rojo	f	\N	Híbrido	Esperctacular bien cuidado con cojineria en cuero, UNICO DUEÑO full equipo HIBRIDO vendo directamente negociable
230	47	2026-11-19	08:06:28	descargado	1.8 CVT XEI	115000000	COP	29000	Automática	Plateado	f	\N	Híbrido	Pelicula de Seguridad en los vidrios Pernos de seguridad en las llantas
231	48	2026-11-19	08:06:34	descargado	1.8 CVT XEI	106900000	COP	30000	Automática	Blanco	f	\N	Híbrido	Único dueño. Medellín hibrido todo en cocesiy
232	49	2026-11-19	08:06:40	descargado	\N	95900000	COP	33000	Automática	Blanco	f	\N	Híbrido	Toyota Corolla XLI híbrido
233	50	2026-11-19	08:06:46	descargado	\N	145500000	COP	10000	Automática	Gris	f	\N	Híbrido	Camioneta prácticamente nueva. Precio negociable. Es la versión básica aunque lo suficientemente equipada.
234	221	2026-11-19	08:06:52	descargado	1.8 XEi-L Automatico	110000000	COP	4269	Automática	Gris	f	\N	Híbrido	-Vencimiento Soat: 03/02/2027 -Vencimiento Tecno: 03/02/2030 -Prenda a banco: No -Siniestros o reclamaciones: No
235	51	2026-11-19	08:06:58	descargado	1.8 XE-i Automatico	118000000	COP	4151	Automática	Lila	f	\N	Híbrido	Equipado con dirección electroasistida, aire acondicionado, cámara de reversa y sistema de audio con Bluetooth, este Corolla también incluye características de seguridad como airbags y frenos ABS. Su diseño y tecnología lo hacen adecuado para la ciudad y viajes cortos, pelicula de vidrios y turecas de seguridad en las llantas
236	52	2026-11-19	08:07:04	descargado	1.8 CVT SEG	116900000	COP	14000	Automática	Gris	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
237	53	2026-11-19	08:07:10	descargado	1.8 XEi-L Automatico	144000000	COP	15109	Automática	Gris	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
238	54	2026-11-19	08:07:16	descargado	SE-G Automatico	132900000	COP	29149	Automática	Blanco	f	\N	Gasolina	El vendedor no incluyó una descripción del producto.
239	55	2026-11-19	08:07:22	descargado	1.8 CVT SEG	116900000	COP	14000	Automática	Gris	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
240	56	2026-11-19	08:07:28	descargado	1.8 CVT SEG	141900000	COP	25543	Automática	Blanco	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
241	57	2026-11-19	08:07:34	descargado	1.8 CVT SEG	152000000	COP	10200	Automática	Plateado	f	\N	Híbrido	Perfecto estado
242	58	2026-11-19	08:07:39	descargado	1.8 CVT SEG	129900000	COP	9000	Automática	Blanco	f	\N	Híbrido	Vehículo en Excelente estado, documentos al día, impuestos al día. Vendo o permuto por vehículo o motocicleta de menor valor.
243	59	2026-11-19	08:07:46	descargado	1.8 CVT SEG	122000000	COP	26000	Automática	Blanco	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
244	60	2026-11-19	08:07:52	descargado	1.8 XL-i Automatico	105900000	COP	20000	Automática	Blanco	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
245	61	2026-11-19	08:07:58	descargado	1.8	134000000	COP	1600	Automática	Gris	f	\N	Híbrido	Carro casi nuevo Toyota Corolla 1.8 Hev Seg kilometraje 1.600 modelo 2026
246	6	2026-11-19	\N	no_encontrado	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
247	24	2026-11-19	\N	no_encontrado	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
248	27	2026-11-19	\N	no_encontrado	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
249	1	2026-11-20	08:01:28	descargado	1.8 XE-i Automatico	84900000	COP	54984	Automática	Plateado	f	\N	Híbrido	🚗 ¡OPORTUNIDAD! Toyota Corolla Híbrido XEI 2022, en excelente estado, nunca siniestrado según historial. Elegante, cómodo y económico en combustible. Tecnología híbrida, ideal para ciudad y carretera. Placa terminada en 8. 💰 $84.900.000 negociables. ¡Un Toyota que combina confort, ahorro y confiabilidad! Agenda tu visita y conócelo.
250	2	2026-11-20	08:01:34	descargado	1.3 Mecanico	85000000	COP	35000	Mecánica	Gris	f	\N	Gasolina	Vehiculo en perfecto estado, A/C, direccionales habatibles, pernos de seguridad, seguro de direccionales, ventanas contrarobo, mantenimientos en cosecionario, único dueño, placa par.
251	3	2026-11-20	08:01:41	descargado	1.8 CVT SEG	94000000	COP	63000	Automática	Gris	t	\N	Híbrido	VEHICULO EN EXCELENTES CONDICIONES LISTO PARA TRASPASO VERSION FULL SEG 2022 63.000 SUN ROOF TAPICERIA EN CUERO APPLE CAR PLAY
252	4	2026-11-20	08:01:55	descargado	1.8 XE-i Automatico	98500000	COP	40000	Automática	Negro	f	\N	Híbrido	Toyota Corolla Hybrid Black Edition 2022, todos sus mantenimientos en ToyoNorte, al día de impuestos, perfecto estado, tapetes todo tiempo toyota, sin pico y placa, no enchufable, consumo muy bajo, silencioso y potente. Negociable. Soat y técnico hasta 2027. CarPlay, cámara trasera, sensores delanteros y traseros, Venta directa.
253	5	2026-11-20	08:02:01	descargado	\N	115000000	COP	20000	Automática	Blanco	t	\N	Híbrido	SEG Hybrid, full equipo, cuenta con siete airbags, película polarizada, cojinería en cuero, sunroof, no tiene pico y placa, se entrega con la revisión de los 20000 Km, venta directa, único dueño
254	7	2026-11-20	08:02:07	descargado	1.8 XE-i Automatico	95000000	COP	31800	Automática	Gris	f	\N	Híbrido	Excelente estado como nuevo, sin pico y placa , mtto de 30.000 km recien hecho, unico dueño, todos los mantenimientos realizados en carco, libre de papeles, no tiene pignoraciones.
255	8	2026-11-20	08:02:12	descargado	1.8 CVT XEI	95000000	COP	29000	Secuencial	Blanco	f	\N	Híbrido	Único dueño, perfecto estado, mantenimientos al día
256	9	2026-11-20	08:02:18	descargado	1.8 XE-i Automatico	89000000	COP	82000	Automática	Blanco	f	\N	Híbrido	Toyota Corolla 2022, 100% hibrido 82,000 km. Último mantenimiento realizado el de 80.000 km, llantas nuevas y con todos los mantenimientos directamente con Toyota conforme al libro de la marca. Motor de 1.8 litros y 136 hp, transmisión automática, dirección electroasistida y tracción delantera Autonomía hasta 90Km por galón. Control de estabilidad, sensores de estacionamiento, cámara de revers...
257	10	2026-11-20	08:02:24	descargado	XEI 2.0 Sedan Manual	83990000	COP	27952	Mecánica	Rojo	f	\N	Gasolina	2 llaves manules
258	11	2026-11-20	08:02:30	descargado	1.8 XE-i Automatico	87000000	COP	44000	Automática	Blanco	f	\N	Híbrido	Toyota Corolla híbrido modelo Chery 2022, llantas al 99%, SOAT recién comprado, papeles al día, listo para traspaso inmediato, puede hacerse revisión en CDA sin ningún problema, pasa sin problema, mantenimientos con Toyota Motor y único dueño, perfecto estado del carro.
259	13	2026-11-20	08:02:36	descargado	1.8 CVT SEG	91900000	COP	68000	Automática	Blanco	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
260	14	2026-11-20	08:02:42	descargado	1.8 XEi-L Automatico	89900000	COP	52050	Automática	Blanco	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
261	15	2026-11-20	08:02:48	descargado	1.8 XEi-L Automatico	89900000	COP	52050	Automática	Blanco	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
262	16	2026-11-20	08:02:53	descargado	1.8 CVT XEI	107900000	COP	72300	Automática	Blanco	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
263	17	2026-11-20	08:02:59	descargado	1.8 CVT SEG	111700000	COP	85000	Automática	Plateado	f	\N	Híbrido	Llantas y Soat comprados en septiembre 2026, excelente estado, unico dueño
264	18	2026-11-20	08:03:05	descargado	1.8 XL-i Automatico	99900000	COP	46000	Automática	Gris	f	\N	Híbrido	Toyota Corolla XLI Hybrid 2023 | Único dueño | 46.000 km | Equipado con accesorios originales de agencia. ⭐ *Equipamiento y extras* * Sistema híbrido 1.8L Toyota, automático E * Llantas y rines originales *de la versión SEG*, instalados de agencia * Polarizado premium. * Tapetes termoformado * Protectores *originales* de retrovisores. * Estribos *originales* de agencia * Interior y exterior en ex...
265	19	2026-11-20	08:03:11	descargado	SE-G Automatico	110000000	COP	23000	Automática	Gris	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
266	20	2026-11-20	08:03:16	descargado	1.8 XL-i Automatico	101000000	COP	1000	Automática	Blanco	f	\N	Híbrido	2023 Toyota Corolla XLI 1.8 Hibrido. KILOMETRAJE es 14
267	21	2026-11-20	08:03:22	descargado	SE-G Automatico	100000000	COP	43000	Automática	Blanco	t	\N	Híbrido	🇨🇴🏁🇯🇵 Toyota Corolla SE-G Hybrid 2.023 ✅️ Listo para Traspaso. ✅ Único Dueño. ✅ 43.000 Km. ✅ Motor 1.8cc Híbrido. ️✅️ Automático. ️✅️ Full Equipo. ✅️ 7 Airbags. ✅️ Sunroof. ✅ Tapicería Cuero. ✅ Polarizado. ✅ Apple CarPlay/ Android Auto. ✅ Mantenimientos en Concesionario. ✅️ Matrícula Bogotá.
268	22	2026-11-20	08:03:28	descargado	1.8 Aut	114000000	COP	36000	Automática	Blanco	f	\N	Híbrido	Toyota Corolla Hibrido Seg Full equipo Modelo 2023 36.000 km Todo el mantenimiento certificado en concesionario
269	23	2026-11-20	08:03:34	descargado	1.8 XL-i Automatico	89900000	COP	22550	Automática	Blanco	f	\N	Híbrido	Híbrido full poco kilometraje, único conductor desde nuevo en trayectos urbanos, pintura con tratamiento porcelanizado, vidrios con película de seguridad, batería de 12v nueva para arranque, libro de mantenimientos original toyota con historial completo, solo en concesionario sus mantenimientos, excelente estado motor, exterior e interior, tapicería en tela, vidrios eléctricos, llave inteligente, ...
270	25	2026-11-20	08:03:39	descargado	1.8 XL-i Automatico	108000000	COP	34083	Automática	Gris	t	\N	Híbrido	Único dueño, accesorios originales.
271	26	2026-11-20	08:03:45	descargado	SE-G Automatico	145000000	COP	30000	Automática	Gris	t	\N	Híbrido	El vendedor no incluyó una descripción del producto.
272	28	2026-11-20	08:03:51	descargado	1.8 XEi-L Automatico	99900000	COP	42000	Automática	Gris	f	\N	Híbrido	TOYOTA COROLLA XE-I HYBRID TP 1800CC 7AB ABS MOD 2023 🚙 Recorrido: 42.000km 🚙 Soat: 24/02/2026 🚙 Tecno: N/A 🚙 Placa: 1️⃣ 🚙 ABS 🚙 Airbags: 7 🚙 Mandos en el timón 🚙 Cámara de reversa 🚙 Sensores 🚙 Dirección: Eléctrica 🚙 Frenos: Disco/Disco 🚙 Faros: LED 🚙 Espejos eléctricos 2 🚙 Tracción: Delantera 🚙 Vidrios eléctricos: 4 🚙 Tapicería: Tela 🚙 Caja: Triptonica 🚙 Color: GRIS CELESTE ...
273	29	2026-11-20	08:03:56	descargado	1.8 XE-i Automatico	102000000	COP	21000	Automática	Blanco	f	\N	Híbrido	Vehículo en excelente estado, peritaje donde desee, recibo vehículo de menor valor
274	30	2026-11-20	08:04:02	descargado	1.8 CVT SEG	115000000	COP	20000	Automática	Plateado	t	\N	Híbrido	El vendedor no incluyó una descripción del producto.
275	31	2026-11-20	08:04:08	descargado	SE-G Automatico	118990000	COP	30000	Automática	Blanco	t	\N	Híbrido	Hermoso Toyota Corolla Sedan Blanco perlado Version mas equipada SEG. Cogineria en cuero, sunroof, todas las ayudas de conduccion, camara trasera y sensores de colision. Hibridacion Full (Consumo combustible promedio en ciudad 70 km/galon) Modelo 2023 con apenas 30.000 km Llantas nuevas (menos de 6 meses)
276	33	2026-11-20	08:04:14	descargado	GR-S 2.0 Deportivo Manual Gasolina	90000000	COP	36000	Automática	Rojo	f	\N	Gasolina	excelente precio poco kilometraje, unico dueño, nunca chocado, seguro todo riesgo AXA, soat hasta agosto 2027, perfecto estado, mod 2023.
277	34	2026-11-20	08:04:20	descargado	SE-G Automatico	104900000	COP	39000	Automática	Rojo	f	\N	Híbrido	Toyota Corolla Híbrido 2023 SEG - Versión full equipo 39.900 km Mantenimientos en concesionario Sin reclamaciones Dos llaves Soat vigente Pasa peritaje Ubicado en ibague
278	146	2026-11-20	08:04:25	descargado	SE-G Automatico	91000000	COP	85000	Secuencial	Plateado	f	\N	Híbrido	VENDO TOYOTA COROLLA 2023 HYBRID SE-G 85000 kms LLANTAS NUEVAS YOKOHAMA MANTENIMIENTOS PAGOS HASTA LOS 95' km VEHICULO EN GARANTÍA!!! TODOS LOS SERVICIOS AL DÍA Y EN YOKOMOTOR. PASTAS TRASERAS NUEVAS!!! PASA PERITAJE ESTA ASEGURADO. Información WhatsApp
279	205	2026-11-20	08:04:31	descargado	SE-G Automatico	95900000	COP	85000	Automática	Gris	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
280	36	2026-11-20	08:04:37	descargado	SE-G Automatico	112900000	COP	34000	Automática	Gris	f	\N	Híbrido	🚙 🚗Toyota Corolla SEG Modelo 2023 Híbrido 34.000km Automático Conineria de cuero #venta #Medellin #autos
281	37	2026-11-20	08:04:46	descargado	1.8 XE-i Automatico	92900000	COP	53000	Automática	Gris	f	\N	Híbrido	Medellin
282	38	2026-11-20	08:04:52	descargado	XEI 2.0 Sedan Automatico CVT	97000000	COP	59000	0	Gris	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
283	39	2026-11-20	08:04:57	descargado	GR-S 2.0 Deportivo Manual Gasolina	127900000	COP	25400	Automática	Blanco	f	\N	Gasolina	Toyota Corolla Cross GR-S 2.0cc - Modelo: 2023 - Kilometraje: 25.400kms - Transmisión: Automática - Tracción: 4x2 - Combustible: Gasolina - Soat: 26/03/2027 - Tecno: 20/02/2028 - Placa Finaliza: 9
284	40	2026-11-20	08:05:03	descargado	1.8 XE-i Automatico	85000000	COP	56879	Automática	Gris	f	\N	Híbrido	Toyota Corolla XEI HIBRIDO 2023 56.879km 1.8cc Automatico Cojineria cuero Vidrios y espejos electricos Mandos en el timon Pantalla tactil Camara reversa Rines de lujo Llantas 70% Soat 24-junio-2027 Tecno 24-junio-2028
285	41	2026-11-20	08:05:09	descargado	1.8 XE-i Automatico	102000000	COP	53400	Automática	Otro	f	\N	Híbrido	¿Buscas confort, tecnología y ahorro? Vendo mi Toyota Corolla XEI Híbrido modelo 2023, una joya de la ingeniería japonesa. Con solo 53.400 km de recorrido. Motor 1.800cc- Automatico - sistema hibrido (Autorecargable) - 7 airbags - frenos ABS - silleteria de cuero - con asistencia y ayudas para la conducción - mandos en el timon - espejos electricos, vidrios electricos - color gris celeste - Pantal...
286	42	2026-11-20	08:05:15	descargado	1.8 CVT SEG	106900000	COP	48000	Automática	Gris	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
287	43	2026-11-20	08:05:20	descargado	1.8	115000000	COP	25700	Automática	Blanco	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
288	44	2026-11-20	08:05:26	descargado	1.8 CVT SEG	108000000	COP	63000	Automática	Plateado	f	\N	Híbrido	Toyota Corolla Seg Hibrido
289	45	2026-11-20	08:05:32	descargado	1.8 XE-i Automatico	113000000	COP	32000	Automática	Gris	f	\N	Híbrido	Toyota Corolla 2024 32.000 Km Perfecto estado 113.000.000 Negociables
290	46	2026-11-20	08:05:38	descargado	1.8 XE-i Automatico	123000000	COP	5000	Automática	Rojo	f	\N	Híbrido	Esperctacular bien cuidado con cojineria en cuero, UNICO DUEÑO full equipo HIBRIDO vendo directamente negociable
291	47	2026-11-20	08:05:43	descargado	1.8 CVT XEI	115000000	COP	29000	Automática	Plateado	f	\N	Híbrido	Pelicula de Seguridad en los vidrios Pernos de seguridad en las llantas
292	48	2026-11-20	08:05:49	descargado	1.8 CVT XEI	106900000	COP	30000	Automática	Blanco	f	\N	Híbrido	Único dueño. Medellín hibrido todo en cocesiy
293	50	2026-11-20	08:05:55	descargado	\N	145500000	COP	10000	Automática	Gris	f	\N	Híbrido	Camioneta prácticamente nueva. Precio negociable. Es la versión básica aunque lo suficientemente equipada.
294	221	2026-11-20	08:06:01	descargado	1.8 XEi-L Automatico	110000000	COP	4269	Automática	Gris	f	\N	Híbrido	-Vencimiento Soat: 03/02/2027 -Vencimiento Tecno: 03/02/2030 -Prenda a banco: No -Siniestros o reclamaciones: No
295	51	2026-11-20	08:06:07	descargado	1.8 XE-i Automatico	118000000	COP	4151	Automática	Lila	f	\N	Híbrido	Equipado con dirección electroasistida, aire acondicionado, cámara de reversa y sistema de audio con Bluetooth, este Corolla también incluye características de seguridad como airbags y frenos ABS. Su diseño y tecnología lo hacen adecuado para la ciudad y viajes cortos, pelicula de vidrios y turecas de seguridad en las llantas
296	53	2026-11-20	08:06:12	descargado	1.8 XEi-L Automatico	144000000	COP	15109	Automática	Gris	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
297	54	2026-11-20	08:06:18	descargado	SE-G Automatico	132900000	COP	29149	Automática	Blanco	f	\N	Gasolina	El vendedor no incluyó una descripción del producto.
298	56	2026-11-20	08:06:24	descargado	1.8 CVT SEG	141900000	COP	25543	Automática	Blanco	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
299	57	2026-11-20	08:06:30	descargado	1.8 CVT SEG	152000000	COP	10200	Automática	Plateado	f	\N	Híbrido	Perfecto estado
300	58	2026-11-20	08:06:38	descargado	1.8 CVT SEG	129900000	COP	9000	Automática	Blanco	f	\N	Híbrido	Vehículo en Excelente estado, documentos al día, impuestos al día. Vendo o permuto por vehículo o motocicleta de menor valor.
301	59	2026-11-20	08:06:45	descargado	1.8 CVT SEG	122000000	COP	26000	Automática	Blanco	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
302	60	2026-11-20	08:06:51	descargado	1.8 XL-i Automatico	105900000	COP	20000	Automática	Blanco	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
303	61	2026-11-20	08:06:57	descargado	1.8	134000000	COP	1600	Automática	Gris	f	\N	Híbrido	Carro casi nuevo Toyota Corolla 1.8 Hev Seg kilometraje 1.600 modelo 2026
304	12	2026-11-20	\N	no_encontrado	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
305	35	2026-11-20	\N	no_encontrado	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
306	6	2026-11-20	\N	no_encontrado	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
307	24	2026-11-20	\N	no_encontrado	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
308	32	2026-11-20	\N	no_encontrado	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
309	49	2026-11-20	\N	no_encontrado	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
310	55	2026-11-20	\N	no_encontrado	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
311	27	2026-11-20	\N	no_encontrado	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
312	52	2026-11-20	\N	no_encontrado	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
313	1	2026-11-21	08:01:25	descargado	1.8 XE-i Automatico	84900000	COP	54984	Automática	Plateado	f	\N	Híbrido	🚗 ¡OPORTUNIDAD! Toyota Corolla Híbrido XEI 2022, en excelente estado, nunca siniestrado según historial. Elegante, cómodo y económico en combustible. Tecnología híbrida, ideal para ciudad y carretera. Placa terminada en 8. 💰 $84.900.000 negociables. ¡Un Toyota que combina confort, ahorro y confiabilidad! Agenda tu visita y conócelo.
314	2	2026-11-21	08:01:32	descargado	1.3 Mecanico	85000000	COP	35000	Mecánica	Gris	f	\N	Gasolina	Vehiculo en perfecto estado, A/C, direccionales habatibles, pernos de seguridad, seguro de direccionales, ventanas contrarobo, mantenimientos en cosecionario, único dueño, placa par.
315	3	2026-11-21	08:01:38	descargado	1.8 CVT SEG	94000000	COP	63000	Automática	Gris	t	\N	Híbrido	VEHICULO EN EXCELENTES CONDICIONES LISTO PARA TRASPASO VERSION FULL SEG 2022 63.000 SUN ROOF TAPICERIA EN CUERO APPLE CAR PLAY
316	4	2026-11-21	08:01:44	descargado	1.8 XE-i Automatico	98500000	COP	40000	Automática	Negro	f	\N	Híbrido	Toyota Corolla Hybrid Black Edition 2022, todos sus mantenimientos en ToyoNorte, al día de impuestos, perfecto estado, tapetes todo tiempo toyota, sin pico y placa, no enchufable, consumo muy bajo, silencioso y potente. Negociable. Soat y técnico hasta 2027. CarPlay, cámara trasera, sensores delanteros y traseros, Venta directa.
317	5	2026-11-21	08:01:50	descargado	\N	115000000	COP	20000	Automática	Blanco	t	\N	Híbrido	SEG Hybrid, full equipo, cuenta con siete airbags, película polarizada, cojinería en cuero, sunroof, no tiene pico y placa, se entrega con la revisión de los 20000 Km, venta directa, único dueño
318	7	2026-11-21	08:01:56	descargado	1.8 XE-i Automatico	95000000	COP	31800	Automática	Gris	f	\N	Híbrido	Excelente estado como nuevo, sin pico y placa , mtto de 30.000 km recien hecho, unico dueño, todos los mantenimientos realizados en carco, libre de papeles, no tiene pignoraciones.
319	8	2026-11-21	08:02:02	descargado	1.8 CVT XEI	95000000	COP	29000	Secuencial	Blanco	f	\N	Híbrido	Único dueño, perfecto estado, mantenimientos al día
320	9	2026-11-21	08:02:08	descargado	1.8 XE-i Automatico	89000000	COP	82000	Automática	Blanco	f	\N	Híbrido	Toyota Corolla 2022, 100% hibrido 82,000 km. Último mantenimiento realizado el de 80.000 km, llantas nuevas y con todos los mantenimientos directamente con Toyota conforme al libro de la marca. Motor de 1.8 litros y 136 hp, transmisión automática, dirección electroasistida y tracción delantera Autonomía hasta 90Km por galón. Control de estabilidad, sensores de estacionamiento, cámara de revers...
321	10	2026-11-21	08:02:14	descargado	XEI 2.0 Sedan Manual	83990000	COP	27952	Mecánica	Rojo	f	\N	Gasolina	2 llaves manules
322	11	2026-11-21	08:02:21	descargado	1.8 XE-i Automatico	87000000	COP	44000	Automática	Blanco	f	\N	Híbrido	Toyota Corolla híbrido modelo Chery 2022, llantas al 99%, SOAT recién comprado, papeles al día, listo para traspaso inmediato, puede hacerse revisión en CDA sin ningún problema, pasa sin problema, mantenimientos con Toyota Motor y único dueño, perfecto estado del carro.
323	12	2026-11-21	08:02:27	descargado	1.8	119900000	COP	55000	Automática	Blanco	f	\N	Híbrido	Corolla Seg blindaje2 híbrido
324	13	2026-11-21	08:02:33	descargado	1.8 CVT SEG	91900000	COP	68000	Automática	Blanco	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
325	14	2026-11-21	08:02:38	descargado	1.8 XEi-L Automatico	89900000	COP	52050	Automática	Blanco	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
326	15	2026-11-21	08:03:02	descargado	1.8 XEi-L Automatico	89900000	COP	52050	Automática	Blanco	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
327	16	2026-11-21	08:03:08	descargado	1.8 CVT XEI	107900000	COP	72300	Automática	Blanco	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
328	17	2026-11-21	08:03:14	descargado	1.8 CVT SEG	111700000	COP	85000	Automática	Plateado	f	\N	Híbrido	Llantas y Soat comprados en septiembre 2026, excelente estado, unico dueño
329	18	2026-11-21	08:03:20	descargado	1.8 XL-i Automatico	99900000	COP	46000	Automática	Gris	f	\N	Híbrido	Toyota Corolla XLI Hybrid 2023 | Único dueño | 46.000 km | Equipado con accesorios originales de agencia. ⭐ *Equipamiento y extras* * Sistema híbrido 1.8L Toyota, automático E * Llantas y rines originales *de la versión SEG*, instalados de agencia * Polarizado premium. * Tapetes termoformado * Protectores *originales* de retrovisores. * Estribos *originales* de agencia * Interior y exterior en ex...
330	19	2026-11-21	08:03:26	descargado	SE-G Automatico	110000000	COP	23000	Automática	Gris	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
331	20	2026-11-21	08:03:32	descargado	1.8 XL-i Automatico	101000000	COP	1000	Automática	Blanco	f	\N	Híbrido	2023 Toyota Corolla XLI 1.8 Hibrido. KILOMETRAJE es 14
332	23	2026-11-21	08:03:37	descargado	1.8 XL-i Automatico	89900000	COP	22550	Automática	Blanco	f	\N	Híbrido	Híbrido full poco kilometraje, único conductor desde nuevo en trayectos urbanos, pintura con tratamiento porcelanizado, vidrios con película de seguridad, batería de 12v nueva para arranque, libro de mantenimientos original toyota con historial completo, solo en concesionario sus mantenimientos, excelente estado motor, exterior e interior, tapicería en tela, vidrios eléctricos, llave inteligente, ...
333	25	2026-11-21	08:03:43	descargado	1.8 XL-i Automatico	108000000	COP	34083	Automática	Gris	t	\N	Híbrido	Único dueño, accesorios originales.
334	26	2026-11-21	08:03:49	descargado	SE-G Automatico	145000000	COP	30000	Automática	Gris	t	\N	Híbrido	El vendedor no incluyó una descripción del producto.
335	28	2026-11-21	08:03:55	descargado	1.8 XEi-L Automatico	99900000	COP	42000	Automática	Gris	f	\N	Híbrido	TOYOTA COROLLA XE-I HYBRID TP 1800CC 7AB ABS MOD 2023 🚙 Recorrido: 42.000km 🚙 Soat: 24/02/2026 🚙 Tecno: N/A 🚙 Placa: 1️⃣ 🚙 ABS 🚙 Airbags: 7 🚙 Mandos en el timón 🚙 Cámara de reversa 🚙 Sensores 🚙 Dirección: Eléctrica 🚙 Frenos: Disco/Disco 🚙 Faros: LED 🚙 Espejos eléctricos 2 🚙 Tracción: Delantera 🚙 Vidrios eléctricos: 4 🚙 Tapicería: Tela 🚙 Caja: Triptonica 🚙 Color: GRIS CELESTE ...
336	29	2026-11-21	08:04:01	descargado	1.8 XE-i Automatico	102000000	COP	21000	Automática	Blanco	f	\N	Híbrido	Vehículo en excelente estado, peritaje donde desee, recibo vehículo de menor valor
337	30	2026-11-21	08:04:06	descargado	1.8 CVT SEG	115000000	COP	20000	Automática	Plateado	t	\N	Híbrido	El vendedor no incluyó una descripción del producto.
338	31	2026-11-21	08:04:12	descargado	SE-G Automatico	118990000	COP	30000	Automática	Blanco	t	\N	Híbrido	Hermoso Toyota Corolla Sedan Blanco perlado Version mas equipada SEG. Cogineria en cuero, sunroof, todas las ayudas de conduccion, camara trasera y sensores de colision. Hibridacion Full (Consumo combustible promedio en ciudad 70 km/galon) Modelo 2023 con apenas 30.000 km Llantas nuevas (menos de 6 meses)
339	32	2026-11-21	08:04:18	descargado	GR-S 2.0 Deportivo Manual Gasolina	95900000	COP	37000	Automática	Rojo	f	\N	Gasolina	El vendedor no incluyó una descripción del producto.
340	33	2026-11-21	08:04:24	descargado	GR-S 2.0 Deportivo Manual Gasolina	90000000	COP	36000	Automática	Rojo	f	\N	Gasolina	excelente precio poco kilometraje, unico dueño, nunca chocado, seguro todo riesgo AXA, soat hasta agosto 2027, perfecto estado, mod 2023.
341	34	2026-11-21	08:04:30	descargado	SE-G Automatico	104900000	COP	39000	Automática	Rojo	f	\N	Híbrido	Toyota Corolla Híbrido 2023 SEG - Versión full equipo 39.900 km Mantenimientos en concesionario Sin reclamaciones Dos llaves Soat vigente Pasa peritaje Ubicado en ibague
342	146	2026-11-21	08:04:40	descargado	SE-G Automatico	91000000	COP	85000	Secuencial	Plateado	f	\N	Híbrido	VENDO TOYOTA COROLLA 2023 HYBRID SE-G 85000 kms LLANTAS NUEVAS YOKOHAMA MANTENIMIENTOS PAGOS HASTA LOS 95' km VEHICULO EN GARANTÍA!!! TODOS LOS SERVICIOS AL DÍA Y EN YOKOMOTOR. PASTAS TRASERAS NUEVAS!!! PASA PERITAJE ESTA ASEGURADO. Información WhatsApp
343	35	2026-11-21	08:04:46	descargado	1.8 CVT SEG	88900000	COP	56000	Automática	Gris	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
344	205	2026-11-21	08:04:51	descargado	SE-G Automatico	95900000	COP	85000	Automática	Gris	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
345	36	2026-11-21	08:04:57	descargado	SE-G Automatico	112900000	COP	34000	Automática	Gris	f	\N	Híbrido	🚙 🚗Toyota Corolla SEG Modelo 2023 Híbrido 34.000km Automático Conineria de cuero #venta #Medellin #autos
346	38	2026-11-21	08:05:03	descargado	XEI 2.0 Sedan Automatico CVT	97000000	COP	59000	0	Gris	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
347	39	2026-11-21	08:05:09	descargado	GR-S 2.0 Deportivo Manual Gasolina	127900000	COP	25400	Automática	Blanco	f	\N	Gasolina	Toyota Corolla Cross GR-S 2.0cc - Modelo: 2023 - Kilometraje: 25.400kms - Transmisión: Automática - Tracción: 4x2 - Combustible: Gasolina - Soat: 26/03/2027 - Tecno: 20/02/2028 - Placa Finaliza: 9
348	40	2026-11-21	08:05:15	descargado	1.8 XE-i Automatico	85000000	COP	56879	Automática	Gris	f	\N	Híbrido	Toyota Corolla XEI HIBRIDO 2023 56.879km 1.8cc Automatico Cojineria cuero Vidrios y espejos electricos Mandos en el timon Pantalla tactil Camara reversa Rines de lujo Llantas 70% Soat 24-junio-2027 Tecno 24-junio-2028
349	41	2026-11-21	08:05:20	descargado	1.8 XE-i Automatico	102000000	COP	53400	Automática	Otro	f	\N	Híbrido	¿Buscas confort, tecnología y ahorro? Vendo mi Toyota Corolla XEI Híbrido modelo 2023, una joya de la ingeniería japonesa. Con solo 53.400 km de recorrido. Motor 1.800cc- Automatico - sistema hibrido (Autorecargable) - 7 airbags - frenos ABS - silleteria de cuero - con asistencia y ayudas para la conducción - mandos en el timon - espejos electricos, vidrios electricos - color gris celeste - Pantal...
350	42	2026-11-21	08:05:26	descargado	1.8 CVT SEG	106900000	COP	48000	Automática	Gris	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
351	43	2026-11-21	08:05:32	descargado	1.8	115000000	COP	25700	Automática	Blanco	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
352	44	2026-11-21	08:05:38	descargado	1.8 CVT SEG	108000000	COP	63000	Automática	Plateado	f	\N	Híbrido	Toyota Corolla Seg Hibrido
353	45	2026-11-21	08:05:44	descargado	1.8 XE-i Automatico	113000000	COP	32000	Automática	Gris	f	\N	Híbrido	Toyota Corolla 2024 32.000 Km Perfecto estado 113.000.000 Negociables
354	46	2026-11-21	08:05:50	descargado	1.8 XE-i Automatico	123000000	COP	5000	Automática	Rojo	f	\N	Híbrido	Esperctacular bien cuidado con cojineria en cuero, UNICO DUEÑO full equipo HIBRIDO vendo directamente negociable
355	47	2026-11-21	08:05:56	descargado	1.8 CVT XEI	115000000	COP	29000	Automática	Plateado	f	\N	Híbrido	Pelicula de Seguridad en los vidrios Pernos de seguridad en las llantas
356	48	2026-11-21	08:06:01	descargado	1.8 CVT XEI	106900000	COP	30000	Automática	Blanco	f	\N	Híbrido	Único dueño. Medellín hibrido todo en cocesiy
357	49	2026-11-21	08:06:07	descargado	\N	95900000	COP	33000	Automática	Blanco	f	\N	Híbrido	Toyota Corolla XLI híbrido
358	50	2026-11-21	08:06:13	descargado	\N	145500000	COP	10000	Automática	Gris	f	\N	Híbrido	Camioneta prácticamente nueva. Precio negociable. Es la versión básica aunque lo suficientemente equipada.
359	221	2026-11-21	08:06:19	descargado	1.8 XEi-L Automatico	110000000	COP	4269	Automática	Gris	f	\N	Híbrido	-Vencimiento Soat: 03/02/2027 -Vencimiento Tecno: 03/02/2030 -Prenda a banco: No -Siniestros o reclamaciones: No
360	51	2026-11-21	08:06:29	descargado	1.8 XE-i Automatico	118000000	COP	4151	Automática	Lila	f	\N	Híbrido	Equipado con dirección electroasistida, aire acondicionado, cámara de reversa y sistema de audio con Bluetooth, este Corolla también incluye características de seguridad como airbags y frenos ABS. Su diseño y tecnología lo hacen adecuado para la ciudad y viajes cortos, pelicula de vidrios y turecas de seguridad en las llantas
361	52	2026-11-21	08:06:35	descargado	1.8 CVT SEG	116900000	COP	14000	Automática	Gris	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
362	54	2026-11-21	08:06:41	descargado	SE-G Automatico	132900000	COP	29149	Automática	Blanco	f	\N	Gasolina	El vendedor no incluyó una descripción del producto.
363	55	2026-11-21	08:06:47	descargado	1.8 CVT SEG	116900000	COP	14000	Automática	Gris	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
364	56	2026-11-21	08:06:52	descargado	1.8 CVT SEG	141900000	COP	25543	Automática	Blanco	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
365	57	2026-11-21	08:06:58	descargado	1.8 CVT SEG	152000000	COP	10200	Automática	Plateado	f	\N	Híbrido	Perfecto estado
366	58	2026-11-21	08:07:04	descargado	1.8 CVT SEG	129900000	COP	9000	Automática	Blanco	f	\N	Híbrido	Vehículo en Excelente estado, documentos al día, impuestos al día. Vendo o permuto por vehículo o motocicleta de menor valor.
367	59	2026-11-21	08:07:28	descargado	1.8 CVT SEG	122000000	COP	26000	Automática	Blanco	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
368	60	2026-11-21	08:07:34	descargado	1.8 XL-i Automatico	105900000	COP	20000	Automática	Blanco	f	\N	Híbrido	El vendedor no incluyó una descripción del producto.
369	61	2026-11-21	08:07:40	descargado	1.8	134000000	COP	1600	Automática	Gris	f	\N	Híbrido	Carro casi nuevo Toyota Corolla 1.8 Hev Seg kilometraje 1.600 modelo 2026
370	6	2026-11-21	\N	no_encontrado	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
371	24	2026-11-21	\N	no_encontrado	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
372	27	2026-11-21	\N	no_encontrado	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
373	21	2026-11-21	\N	no_encontrado	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
374	22	2026-11-21	\N	no_encontrado	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
375	37	2026-11-21	\N	no_encontrado	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
376	53	2026-11-21	\N	no_encontrado	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
\.


--
-- Data for Name: vendedor; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.vendedor (id, nombre, departamento) FROM stdin;
1	Teresita Palacio Jimenez	BOGOTA
2	ALVARO OQUENDO ARANA	BOGOTA
3	Laura Natalia Pinzón López	BOGOTA
4	FANOR DAVID	BOGOTA
5	Wilson Hernandez Muñoz	BOGOTA
6	ESCALAUTOS	ESCALAUTOS
7	Diego Martinez	BOGOTA
8	JUAN CARLOS GONZALEZ MEDINA	BOGOTA
9	DAVID MAURICIO Moreno	BOGOTA
10	INVERSIONES METROMOVIL BEV SAS	INVERSIONES METROMOVIL BEV SAS
11	Martin undefined	ANTIOQUIA
12	Leonel David Perez legarda	ANTIOQUIA
17	heriberto vargas	META
18	Andrea Acevedo	ANTIOQUIA
19	Jose Fernando Rodriguez Hernandez	BOGOTA
20	Serkan Ozkan	Bogotá D.C.
21	Andres Roa	BOGOTA
22	Jaime Enrique Monroy	BOGOTA
23	Marcela Acosta	BOGOTA
25	DIEGO PAUCAR	BOGOTA
26	Fernando Torres	BOGOTA
27	WCAR	WCAR
28	Daniela Lopez	BOGOTA
29	Chuss cars	BOGOTA
30	juan carlos granados egea	SANTANDER
31	Luis Guillermo Sinisterra Zafra	VALLE DEL CAUCA
32	Leonel David Perez legarda	NORTE DE SANTANDER
33	Elias Elias	NORTE DE SANTANDER
34	SebasG SebasG	TOLIMA
36	Camilo José Mora Taborda	ANTIOQUIA
37	carlos mario bernal	ANTIOQUIA
38	Casa Fernandez	ANTIOQUIA
39	RCautos medellin	ANTIOQUIA
40	brayan marin	ANTIOQUIA
41	John Osorio	ANTIOQUIA
43	Jose Luis Ocaña Paz	NARINO
44	Edgar Laguna	META
45	Matias Buitrago	BOGOTA
46	CLAUDIO MORENO	BOGOTA
47	Alvaro Ramirez Suarez	BOGOTA
50	Andres Mancera Rojas	BOGOTA
51	Cristina Gonzalez	BOGOTA
57	Felipe M Jaramillo Jacome	BOGOTA
58	Autos Tobias	BOGOTA
59	Gerardo Duque Aristizabal	CALDAS
61	Durley alejandra Calle cardona	ANTIOQUIA
146	Juan Alejandro undefined	ANTIOQUIA
\.


--
-- Name: anuncio_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.anuncio_id_seq', 344, true);


--
-- Name: cambio_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.cambio_id_seq', 840, true);


--
-- Name: log_ejecucion_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.log_ejecucion_id_seq', 24, true);


--
-- Name: observacion_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.observacion_id_seq', 376, true);


--
-- Name: vendedor_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.vendedor_id_seq', 341, true);


--
-- Name: anuncio anuncio_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.anuncio
    ADD CONSTRAINT anuncio_pkey PRIMARY KEY (id);


--
-- Name: anuncio anuncio_url_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.anuncio
    ADD CONSTRAINT anuncio_url_key UNIQUE (url);


--
-- Name: cambio cambio_anuncio_id_fecha_campo_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cambio
    ADD CONSTRAINT cambio_anuncio_id_fecha_campo_key UNIQUE (anuncio_id, fecha, campo);


--
-- Name: cambio cambio_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cambio
    ADD CONSTRAINT cambio_pkey PRIMARY KEY (id);


--
-- Name: log_ejecucion log_ejecucion_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.log_ejecucion
    ADD CONSTRAINT log_ejecucion_pkey PRIMARY KEY (id);


--
-- Name: log_ejecucion log_ejecucion_run_id_etapa_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.log_ejecucion
    ADD CONSTRAINT log_ejecucion_run_id_etapa_key UNIQUE (run_id, etapa);


--
-- Name: observacion observacion_anuncio_id_fecha_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.observacion
    ADD CONSTRAINT observacion_anuncio_id_fecha_key UNIQUE (anuncio_id, fecha);


--
-- Name: observacion observacion_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.observacion
    ADD CONSTRAINT observacion_pkey PRIMARY KEY (id);


--
-- Name: vendedor vendedor_nombre_departamento_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vendedor
    ADD CONSTRAINT vendedor_nombre_departamento_key UNIQUE (nombre, departamento);


--
-- Name: vendedor vendedor_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vendedor
    ADD CONSTRAINT vendedor_pkey PRIMARY KEY (id);


--
-- Name: idx_anuncio_año; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "idx_anuncio_año" ON public.anuncio USING btree ("año");


--
-- Name: idx_anuncio_ciudad; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_anuncio_ciudad ON public.anuncio USING btree (ciudad);


--
-- Name: idx_anuncio_vend; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_anuncio_vend ON public.anuncio USING btree (vendedor_id);


--
-- Name: idx_cambio_anuncio; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_cambio_anuncio ON public.cambio USING btree (anuncio_id);


--
-- Name: idx_cambio_fecha; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_cambio_fecha ON public.cambio USING btree (fecha DESC);


--
-- Name: idx_log_fecha; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_log_fecha ON public.log_ejecucion USING btree (fecha_inicio DESC);


--
-- Name: idx_log_run_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_log_run_id ON public.log_ejecucion USING btree (run_id);


--
-- Name: idx_obs_anuncio; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_obs_anuncio ON public.observacion USING btree (anuncio_id);


--
-- Name: idx_obs_fecha; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_obs_fecha ON public.observacion USING btree (fecha DESC);


--
-- Name: idx_obs_precio; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_obs_precio ON public.observacion USING btree (precio) WHERE (precio IS NOT NULL);


--
-- Name: anuncio anuncio_vendedor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.anuncio
    ADD CONSTRAINT anuncio_vendedor_id_fkey FOREIGN KEY (vendedor_id) REFERENCES public.vendedor(id);


--
-- Name: cambio cambio_anuncio_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cambio
    ADD CONSTRAINT cambio_anuncio_id_fkey FOREIGN KEY (anuncio_id) REFERENCES public.anuncio(id) ON DELETE CASCADE;


--
-- Name: observacion observacion_anuncio_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.observacion
    ADD CONSTRAINT observacion_anuncio_id_fkey FOREIGN KEY (anuncio_id) REFERENCES public.anuncio(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict 8m5osTbezQaeesAafmD78a7qSrNYSL1gFPbvL32CCVKb0oy9958k4MEmazPXHjg

